package exsample;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;

public class Base {

    public boolean uploadRequest(){
        //request.setCharacterEncoding("UTF-8");
        DataOutputStream outputStream = null;
        String lineEnd = "\r\n";
        String twoHyphens = "--";
        String boundary =  "*****"+ UUID.randomUUID().toString()+"*****";
        final int maxBufferSize = 1024*1024*3;
        String filename = null;
      //  Map<String, String> textdata  = new HashMap<String, String>();

        String path = "C:/doc_test/test0000001.zip";
        String filePath = null;
        File f = new File(path);
        if(!f.exists()){
            return false;
        }
        filename = f.getName();
        filePath = f.getAbsolutePath();


        //入力ファイルを開く
        InputStream fileInputStream;
        try {
            fileInputStream = new FileInputStream(filePath);;
            //ファイル情報をBASE64に変換する。
            byte[] beforeByte = IOUtils.toByteArray(fileInputStream);
            byte[] encodeByte = Base64.encodeBase64(beforeByte);
            fileInputStream =  new ByteArrayInputStream(encodeByte);

            // POST先のURL設定
            //URL url = new URL("https://XXXX/api/upload/putW6BP0170File");
            URL url = new URL("http://localhost2/php_test/rest/test/post.php");

            // 接続用HttpURLConnectionオブジェクト作成
            HttpURLConnection connection = (HttpURLConnection)url.openConnection();

            // 出力できるようにする
            connection.setDoOutput(true);

            // キャッシュを使わないように設定
            connection.setUseCaches(false);

            // リクエストメソッドをPOSTに設定
            connection.setRequestMethod("POST");
            connection.setRequestProperty("User-Agent", "@IT java-tips URLConnection");

            //HTTP/1.1 でサポートされた持続接続機能が使用できることを宣言する
            connection.setRequestProperty("Connection", "Keep-Alive");

            // マルチパートデータとして複数のデータを送ることを宣言する
            connection.setRequestProperty("Accept-Language", "jp");
            connection.setRequestProperty("Content-Type", "multipart/mixed;boundary=" + boundary + ";charset=utf-8");

            //dataの設定
            outputStream = new DataOutputStream(connection.getOutputStream());
            outputStream.writeBytes(twoHyphens + boundary + lineEnd);
            outputStream.writeBytes("Content-Disposition: form-data; name=\"" + "data" + "\"; filename=\"" + filename +"\"" + lineEnd);
            outputStream.writeBytes("Content-Type: application/octet-stream;charset=utf-8" + lineEnd);
            outputStream.writeBytes("Content-Transfer-Encoding: binary" + lineEnd);
            outputStream.writeBytes(lineEnd);

            //ファイル出力ストリーム生成
            int bytesAvailable = fileInputStream.available();
            int bufferSize = Math.min(bytesAvailable, maxBufferSize);
         //   FileOutputStream fos = new FileOutputStream(filePath);

            byte[] buffer = new byte[bufferSize];
            int bytesRead = fileInputStream.read(buffer, 0, bufferSize);
            while(bytesRead > 0) {
                outputStream.write(buffer, 0, bufferSize);
                bytesAvailable = fileInputStream.available();
                bufferSize = Math.min(bytesAvailable, maxBufferSize);
                bytesRead = fileInputStream.read(buffer, 0, bufferSize);
            }
            outputStream.writeBytes(lineEnd);

            //useridの設定
            outputStream.writeBytes(twoHyphens + boundary + lineEnd);
            outputStream.writeBytes("Content-Disposition: form-data; name=\"" + "userid" + "\"" + lineEnd);
            outputStream.writeBytes("Content-Type: text/plain;charset=utf-8"+lineEnd);
            outputStream.writeBytes(lineEnd);
            outputStream.writeBytes(URLEncoder.encode("XXXXUSR","UTF-8"));
            outputStream.writeBytes(lineEnd);

            //passwordの設定
            outputStream.writeBytes(twoHyphens + boundary + lineEnd);
            outputStream.writeBytes("Content-Disposition: form-data; name=\"" + "password" + "\"" + lineEnd);
            outputStream.writeBytes("Content-Type: text/plain;charset=utf-8"+lineEnd);
            outputStream.writeBytes(lineEnd);
            outputStream.writeBytes(URLEncoder.encode("XXXXPASS","UTF-8"));
            outputStream.writeBytes(lineEnd);

            //messageidの設定
            outputStream.writeBytes(twoHyphens + boundary + lineEnd);
            outputStream.writeBytes("Content-Disposition: form-data; name=\"" + "messageid" + "\"" + lineEnd);
            outputStream.writeBytes("Content-Type: text/plain;charset=utf-8"+lineEnd);
            outputStream.writeBytes(lineEnd);
            outputStream.writeBytes(URLEncoder.encode("XXXXMESSAGE","UTF-8"));
            outputStream.writeBytes(lineEnd);

            //timestampの設定
            outputStream.writeBytes(twoHyphens + boundary + lineEnd);
            outputStream.writeBytes("Content-Disposition: form-data; name=\"" + "timestamp" + "\"" + lineEnd);
            outputStream.writeBytes("Content-Type: text/plain;charset=utf-8"+lineEnd);
            outputStream.writeBytes(lineEnd);
            outputStream.writeBytes(URLEncoder.encode("20140112","UTF-8"));
            outputStream.writeBytes(lineEnd);

            outputStream.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);
            outputStream.close();

            // 入力ストリーム作成してPOSTのレスポンス取得
            BufferedReader bufferReader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF8"));
            Map headers = connection.getHeaderFields();

            // レスポンス確認用画面html組み立て
            StringBuffer sb = new StringBuffer();
            sb.append("TEST -------------\n\n");
            sb.append("Response\n");
            sb.append("Result code:" + headers.get("resultcode"));
            sb.append("\n\n-------------\n\n");

            bufferReader.close();

            System.out.println(new String(sb));
            Set b = headers.keySet();
            for (Object object : b) {
                System.out.println(object);
                System.out.println(headers.get(object));

            }
            // 接続用HttpURLConnection切断
            connection.disconnect();
            // 出力ストリーム作成
            //PrintWriter outPut = response.getWriter();
            // 画面html出力
            //outPut.println(new String(sb));
            //outPut.close();
           // outPutPrintWriter(new String(sb),"C:/Users/hideo/Desktop/doc_test/doc_test","result.html");

            try {
                fileInputStream.close();
                outputStream.flush();
                outputStream.close();
                connection.disconnect();
            } catch (Exception e) {
                    e.printStackTrace();

            }
        } catch (Exception e1) {
            e1.printStackTrace();
        }

        return true;
    }

    public static void outPutPrintWriter(String text, String outPath, String fileName){
        try {
            File f = new File(outPath+"/"+fileName);
            if(!f.exists()){
                //フォルダがない場合は、フォルダを作成します
                File parent = f.getParentFile();
                if (!parent.exists()) {
                    //フォルダがない場合、全ての親フォルダを作成します
                    parent.mkdirs();
                }

                //出力先を作成する
                FileWriter fw = new FileWriter(f, false);
                PrintWriter pw = new PrintWriter(new BufferedWriter(fw));

                //内容を指定する
                pw.print(text);

                //ファイルに書き出す
                pw.close();

                //終了メッセージを画面に出力する
                System.out.println("出力が完了しました。");

            }

        } catch (IOException ex) {
            //例外時処理
            ex.printStackTrace();
        }
    }

}
