<?php

function perse($buffer)
{
    $status = array();
    $temp = explode("\r\n\r\n", $buffer);
    $buffer_header = array_shift($temp);
    $entity_body = implode("\r\n\r\n", $temp);
    $temp_line = explode("\r\n", $buffer_header);
    $line_no = 0;
    foreach ($temp_line as $line_contents) {
        if ($line_no == 0) {
            $temp_status = explode(" ", $line_contents);
            $status["HTTP-Version"] = $temp_status[0];
            $status["Status"] = $temp_status[1];
            $status["Message"] = $temp_status[2];
        } else {
            $temp_status = explode(":", $line_contents);
            $field_name = array_shift($temp_status);
            $status[$field_name] = ltrim(implode(":", $temp_status));
        }
        $line_no ++;
    }
    $status["Body"] = $entity_body;
    return $status;
}

function save()
{

    $date = new DateTime();
    $d = $date->format('Ymd_His');
    $file = "est_post_" . $d . ".txt";
    $myfile = @fopen($file, "a");
    if (!$myfile === false) {
        @flock($myfile, LOCK_EX);

        fputs($myfile, PHP_EOL . "start ----" . PHP_EOL . PHP_EOL);
        fputs($myfile, PHP_EOL . "post1 start ----" . PHP_EOL . PHP_EOL);

        $headers = apache_request_headers();
        foreach ($headers as $header => $value) {
            fputs($myfile, "$header: $value" . PHP_EOL);
        }
        fputs($myfile, PHP_EOL . "post1 end ----" . PHP_EOL . PHP_EOL);


        fputs($myfile, PHP_EOL . "header read ----" . PHP_EOL . PHP_EOL);

        //$stdin = fopen('php://input', 'r');
        //while (!feof($stdin)) {
          //  fputs($myfile, fgets($stdin, 1024));
        //}
        //fclose($stdin);

        $STR = file_get_contents('php://input');
        $POST = perse($STR);
        /*
        if ( preg_match('@^(?:[^=&]*=[^=&]*(?:&[^=&]*=[^=&]*)*)?$@',$STR,$matches) !== 0 ) {
         // Log::trace($NAME,'Query format');
          parse_str($STR,$POST);
          fputs($myfile, $STR);
             fputs($myfile, "uyyy n ----" . PHP_EOL);
        }else{
         // Log::trace($NAME,'Not Query format');
          $POST=$STR;
          fputs($myfile, $STR);
             fputs($myfile, "nnn n ----" . PHP_EOL);
        }
        */


/*

        foreach ($POST as $key => $value) {

                fputs($myfile, $key . " : " . $value . PHP_EOL);
        }
 */
        /*
        function a ($str){
           $data = explode("=",$str);
           if(!$data===false){
              $strs = array();
              $strs = array($data[0], $data[1]);
              return $strs;
           }
           return null;
        }

        $POST2 = array();
        foreach ($POST as $key => $value) {

            if($key === "Content-Disposition"){
                fputs($myfile, $key . " : " . $value . PHP_EOL);
                fputs($myfile, PHP_EOL . "Content-Disposition" . PHP_EOL);
                $value_array = explode(";",str_replace(array(" ","\""),"",$value));
                foreach ($value_array as $v) {
                    $temp = a($v);
                    if(!$temp === false){
                        $POST2[] = $temp;
                    }
                    fputs($myfile, $k . " : " . $v . PHP_EOL);
                }

                fputs($myfile, PHP_EOL);
            }else{
                fputs($myfile, $key . " : " . $value . PHP_EOL);
            }

        }
        */

        foreach ($POST as $key => $value) {
            fputs($myfile, $key . " : " . $value . PHP_EOL);
            if ($key === "Body") {
                $v = explode(PHP_EOL, $value);
                fputs($myfile, PHP_EOL);
                fputs($myfile, "AAAAAAAAaaaaa" . PHP_EOL);
                fputs($myfile, $v[0] . PHP_EOL);
                fputs($myfile, "AAAAAaaaaa" . PHP_EOL);
                fputs($myfile, PHP_EOL);


                $dec = base64_decode($v[0]);
                  fputs($myfile, strlen($dec) . PHP_EOL);
                  fputs($myfile, $dec . PHP_EOL);
                $file_zip = "post_" . $d . ".zip";
                $file_zip_f = @fopen($file_zip, "w");
                if (!$file_zip_f === false) {
                    @flock($file_zip_f, LOCK_EX);
                    fputs($file_zip_f, $dec);
                    fclose($file_zip_f);
                }
                /*
                if(move_uploaded_file($dec, $file_zip)){
                  fputs($myfile, "OK" . PHP_EOL);
                }else{
                  fputs($myfile, "NG" . PHP_EOL);
                }
                */
            }
        }

        fputs($myfile, PHP_EOL . "header end ----" . PHP_EOL);
        fputs($myfile, PHP_EOL . "end ////" . PHP_EOL);
        fputs($myfile, PHP_EOL);
        fclose($myfile);
    }
    return true;
}



    $result = save();

header('HTTP/1.1 200 ');
header('resultcode:data');

print "AAAAAAAAAAAA";
