function loadChart(mId, obj) {
    var elm = document.getElementById(mId);
    if (elm == null) {
        return null;
    }

    var ch = Highcharts.chart(elm, obj);
    return ch;

}