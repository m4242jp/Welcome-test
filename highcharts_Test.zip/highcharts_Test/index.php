<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>Highcharts Example</title>

		<style type="text/css">
#container {
	min-width: 310px;
	max-width: 800px;
	height: 400px;
	margin: 0 auto
}
		</style>
        <link rel="stylesheet" type="text/css" href="code/css/highcharts.css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"       type="text/javascript"></script>
<script src="code/js/highcharts.js"></script>
<script src="code/js/modules/exporting.js"></script>
<script src="fff.js"></script>
	</head>
	<body>

<?php
 $legend = array("layout" => "vertical","align" => "right","verticalAlign" => "middle");
 //$yAxis = array("title" => array("text" => 'Number'));
 //opposite: true
 $yAxis1 = array("title" => array("text" => 'LEFT', "style" => array("color" => "#ff0000")) ,
  'labels' => array("format" => "{value}%"));
 $yAxis2 = array("title" => array("text" => 'RIGHT') ,'opposite' => true,
    'labels' => array("format" => "{value}円"));
 $yAxis = array($yAxis1,$yAxis2);
 $xAxis = array("categories" => array('11/1', '11/2', '11/3','11/4','11/5'));


 $series = array(
                array("name" => 'aaaaaa', "color" => "#ff0000", "type" => "column","yAxis" => 1,"data" => array( 997, 856, 686, 1025,1607),
                    ),
                array("name" => 'saaaa',"color" => "#00ff00", "type" => "line","data" => array(128.2, 108.2, 69.0, 79.1,108.5),
                    )
            );

 $tooltip = array(
                "formatter" => '%function1%',
                "shared" => true
                );

 $tooltip_replace_function = <<< EOF
function () {
            return 'The value for <b>' + this.x +
                '</b> is <b>' + this.y + '</b>';
        }
EOF;

 $json = array(
    "legend" => $legend,
    "yAxis" => $yAxis,
    "xAxis" => $xAxis,
    "tooltip" => $tooltip,
    "series" => $series);
 $json_res = json_encode($json, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
 $json_res = str_replace('"' . "%function1%" . '"', $tooltip_replace_function, $json_res);
 echo $json_res;
?>
<div id="container"></div>



		<script type="text/javascript">

        var obj = <?php echo $json_res; ?>;
var chart = loadChart('container', obj);

window.onload = function() {

   console.log(  JSON.parse(sessionStorage.getItem("nombre"))) ;
   var array = JSON.parse(sessionStorage.getItem("nombre"));
   if (array && Array.isArray(array)) {
        array.forEach(function(val,index,ar){
           myFunc(val,false); //trueになる
        });
   }
}
function myFunc(_name,save = true){
    var series = chart.series.find(function(item, index){
        if (item.name === _name) return true;
    });

    if(series){
        if (series.visible) {
            series.hide();
            if(save)saveSession(_name,false);
        } else {
            series.show();
            if(save)saveSession(_name,true);
        }
    }
}

function saveSession(_name,remove){
    if( ('sessionStorage' in window) && (window.sessionStorage !== null) ) {
        var array = JSON.parse(sessionStorage.getItem("nombre"));
        if (!array || !Array.isArray(array)) {
            array = new Array();
        }
        if(remove){
            array.some(function(v, i){
                if (v==_name) array.splice(i,1);
            });
        } else {
            array.push(_name);
        }
        sessionStorage.setItem('nombre', JSON.stringify(array) );
        console.log(array);
    }
}
		</script>
        <button onclick="myFunc('S')">Other</button>
        <button onclick="myFunc('Project Development')">Project Development</button>
        <button onclick="myFunc('Other')">Other</button>
	</body>
</html>
