<?php

class ProjectController extends Controller
{
    protected $auth_actions = array(
        'index',
        'new',
        'confirm',
        'post',
        'edit',
        'update_confirm_detail',
        'update_post_detail',
        'update_post_remove',
        'joins',
        'joinchange',
        'notReadingAuthority',
    );

    public function indexAction()
    {
        $user = $this->session->get('user');
        if (!$user) {
            return $this->forward404();
        }

        $project_page_no = $this->request->getGet('pno','1');
        $task_page_no = $this->request->getGet('tno','1');
        $task_page_sort = $this->request->getGet('sort','schedule');
        $task_page_desc = $this->request->getGet('desc',true);

        $project_repository = $this->db_manager->get('Project');
        $task_repository = $this->db_manager->get('Task');
        $util = new Utility();

        $projects_count = $project_repository->fetchCountJoinAllProjectByUserId($user['user_id']);
        $projects_pager = $util->createPager($project_page_no,$projects_count['count'],Env::PROJECT_PAGE_LIMIT);
        //var_dump($projects_pager);

        $projects = $project_repository->fetchAllJoinAllProjectsByUserId($user['user_id'],$projects_pager['offset_records'],$projects_pager['view_count']);
       // $projects = $project_repository->fetchAllJoinProjectByUserId($user['user_id']);

        $tasks_count = $task_repository->fetchCountHandleAllTaskByUserId($user['user_id']);

        $tasks_pager = $util->createPager($task_page_no,$tasks_count['count'],Env::TASK_PAGE_LIMIT);
        $tasks = $task_repository->fetchAllHandleAllTaskByUserId($user['user_id'],$tasks_pager['offset_records'],$tasks_pager['view_count'],!$task_page_sort ? 'schedule' : $task_page_sort,$task_page_desc);
        //var_dump($tasks_pager);
        $task_sort_url = $util->createTaskSortUrl($task_page_sort,$task_page_desc);

        return $this->render(
            array(
                'user' => $user,
                'tasks' => $tasks,
                'projects_pager' => $projects_pager,
                'projects' => $projects,
                'tasks_pager' => $tasks_pager,
                'task_sort_url'=> $task_sort_url,
                'task_sort'=> $task_page_sort,
                'task_desc'=> $task_page_desc,
                'tasks' => $tasks,
                'admin' => $this->session->isAdministratorLevel(),
            )
        );
    }

    public function newAction()
    {
        $project_name = $this->request->getPost('project_name', '');
        $project_summary = $this->request->getPost('project_summary', '');

        return $this->render(
            array(
                    'project_name' => $project_name,
                    'project_summary' => $project_summary,
                '_token' => $this->generateCsrfToken('prj/new'),
            )
        );
    }

    public function confirmAction()
    {
        if (!$this->request->isPost()) {
            return $this->forward404();
        }

        $token = $this->request->getPost('_token');
        if (!$this->checkCsrfToken('prj/new', $token)) {
            return $this->redirect('/');
        }

        $project_name = $this->request->getPost('project_name');
        $project_summary = $this->request->getPost('project_summary');

        $errors = array();

        if (!strlen($project_name)) {
            $errors[] = 'プロジェクト名を入力してください';
        } elseif (mb_strlen($project_name) > 80) {
            $errors[] = 'プロジェクト名は80文字以内で入力してください';
        }

        if (!strlen($project_summary)) {
            $errors[] = '概要を入力してください';
        } elseif (mb_strlen($project_summary) > 2000) {
            $errors[] = '概要は80文字以内で入力してください';
        }

        return $this->render(
            array(
                    'project_name' => $project_name,
                    'project_summary' => $project_summary,
                    'errors' => $errors,
                    '_token' => $this->generateCsrfToken('prj/new'),
                ),
            count($errors) === 0 ? null : 'new'
        );
    }

    public function postAction()
    {
        if (!$this->request->isPost()) {
            return $this->forward404();
        }

        $token = $this->request->getPost('_token');
        if (!$this->checkCsrfToken('prj/new', $token)) {
            return $this->redirect('/');
        }

        $project_name = $this->request->getPost('project_name');
        $project_summary = $this->request->getPost('project_summary');

        $errors = array();

        if (!strlen($project_name)) {
            $errors[] = 'プロジェクト名を入力してください';
        } elseif (mb_strlen($project_name) > 80) {
            $errors[] = 'プロジェクト名は80文字以内で入力してください';
        }

        if (!strlen($project_summary)) {
            $errors[] = '概要を入力してください';
        } elseif (mb_strlen($project_summary) > 2000) {
            $errors[] = '概要は80文字以内で入力してください';
        }

        if (count($errors) === 0) {
            $user = $this->session->get('user');
            $new_id = $this->db_manager->get('Project')->insert($user['user_id'], $project_name, $project_summary);
            if ($new_id) {
                $this->session->setToasts(array('プロジェクトを作成しました。編集から参加者を設定しましょう'));

                return $this->redirect('/prj/'.$new_id);
            } else {
                $errors[] = 'プロジェクトの作成ができませんでした。';
            }
        }

        return $this->render(
            array(
                    'project_name' => $project_name,
                    'project_summary' => $project_summary,
                    'errors' => $errors,
                    '_token' => $this->generateCsrfToken('prj/new'),
                ),
            'new'
        );
    }

    public function editAction($params)
    {

        //プロジェクトがなければホームへ
        if (!isset($params['project_no'])) {
            return $this->redirect('/');
        }

        $user = $this->session->get('user');
        $project_repository = $this->db_manager->get('Project');
        $project = $project_repository->fetchByProjectId($params['project_no']);
        if (!$project) {
            return $this->redirect('/');
        }
        //参加中と管理者チェック
        if (!$project_repository->isJoinProjectMangeUser($project['project_id'], $user['user_id']) && !$this->session->isAdministratorLevel()) {
            return $this->redirect('/readingerror');
        }

        $project_name_now = $project['project_name'];
        $project_name = $this->request->getPost('project_name', $project['project_name']);
        $project_summary = $this->request->getPost('project_summary', $project['project_summary']);

        return $this->render(
            array(
                  'project_id' => $project['project_id'],
                    'project_name_now' => $project_name_now,
                  'project_name' => $project_name,
                  'project_summary' => $project_summary,
              '_token' => $this->generateCsrfToken('prj/update'),
            )
        );
    }

    public function update_confirm_detailAction($params)
    {
        if (!$this->request->isPost()) {
            return $this->forward404();
        }

        $token = $this->request->getPost('_token');
        if (!$this->checkCsrfToken('prj/update', $token)) {
            return $this->redirect('/');
        }

        $user = $this->session->get('user');
        $project_repository = $this->db_manager->get('Project');
        $project = $project_repository->fetchByProjectId($params['project_no']);
        if (!$project) {
            return $this->redirect('/');
        }
        //参加中と管理者チェック
        if (!$project_repository->isJoinProjectMangeUser($project['project_id'], $user['user_id']) && !$this->session->isAdministratorLevel()) {
            return $this->redirect('/readingerror');
        }

        $errors = array();
        $action = $this->request->getPost('action');
        $project_name_now = $project['project_name'];
        $project_name = $this->request->getPost('project_name');
        $project_summary = $this->request->getPost('project_summary');

        switch ($action) {
            case 'update':
                if (!strlen($project_name)) {
                    $errors[] = 'プロジェクト名を入力してください';
                } elseif (mb_strlen($project_name) > 80) {
                    $errors[] = 'プロジェクト名は80文字以内で入力してください';
                }

                if (!strlen($project_summary)) {
                    $errors[] = '概要を入力してください';
                } elseif (mb_strlen($project_summary) > 2000) {
                    $errors[] = '概要は80文字以内で入力してください';
                }

                return $this->render(
                    array(
                            'project_id' => $project['project_id'],
                            'project_name_now' => $project_name_now,
                            'project_name' => $project_name,
                            'project_summary' => $project_summary,
                            'errors' => $errors,
                            '_token' => $this->generateCsrfToken('prj/update'),
                        ),
                    count($errors) === 0 ? 'update_confirm_detail' : 'edit'
                );
                break;
            case 'remove':
                return $this->render(
                    array(
                            'project_id' => $project['project_id'],
                            'project_name_now' => $project_name_now,
                            'project_name' => $project['project_name'],
                            'project_summary' => $project['project_summary'],
                            '_token' => $this->generateCsrfToken('prj/update'),
                        ),
                    'update_confirm_remove'
                );
                break;
        }
    }

    public function update_post_detailAction($params)
    {
        if (!$this->request->isPost()) {
            return $this->forward404();
        }

        $token = $this->request->getPost('_token');
        if (!$this->checkCsrfToken('prj/update', $token)) {
            return $this->redirect('/');
        }

        $user = $this->session->get('user');
        $project_repository = $this->db_manager->get('Project');
        $project = $project_repository->fetchByProjectId($params['project_no']);
        if (!$project) {
            return $this->redirect('/');
        }
        //参加中と管理者チェック
        if (!$project_repository->isJoinProjectMangeUser($project['project_id'], $user['user_id']) && !$this->session->isAdministratorLevel()) {
            return $this->redirect('/readingerror');
        }
        $project_name_now = $project['project_name'];
        $project_name = $this->request->getPost('project_name');
        $project_summary = $this->request->getPost('project_summary');

        $errors = array();

        if (!strlen($project_name)) {
            $errors[] = 'プロジェクト名を入力してください';
        } elseif (mb_strlen($project_name) > 80) {
            $errors[] = 'プロジェクト名は80文字以内で入力してください';
        }

        if (!strlen($project_summary)) {
            $errors[] = '概要を入力してください';
        } elseif (mb_strlen($project_summary) > 2000) {
            $errors[] = '概要は80文字以内で入力してください';
        }

        if (count($errors) === 0) {
            $this->db_manager->get('Project')->updateProject($project['project_id'], $project_name, $project_summary);
            $this->session->setToasts(array('内容を更新しましたよ'));

            return $this->redirect('/prj/'.$project['project_id']);
        }

        return $this->render(
            array(
                    'project_id' => $project['project_id'],
                    'project_name_now' => $project_name_now,
                    'project_name' => $project_name,
                    'project_summary' => $project_summary,
                    'errors' => $errors,
                    '_token' => $this->generateCsrfToken('prj/update'),
                ),
            'update'
        );
    }

    public function update_post_removeAction($params)
    {
        if (!$this->request->isPost()) {
            return $this->forward404();
        }

        $token = $this->request->getPost('_token');
        if (!$this->checkCsrfToken('prj/update', $token)) {
            return $this->redirect('/');
        }

        $user = $this->session->get('user');
        $project_repository = $this->db_manager->get('Project');
        $project = $project_repository->fetchByProjectId($params['project_no']);
        if (!$project) {
            return $this->redirect('/');
        }
        //参加中と管理者チェック
        if (!$project_repository->isJoinProjectMangeUser($project['project_id'], $user['user_id']) && !$this->session->isAdministratorLevel()) {
            return $this->redirect('/readingerror');
        }

        $this->db_manager->get('Project')->removeProject($project['project_id']);
        $this->session->setToasts(array($project['project_name'].'を削除しましたよ'));

        return $this->redirect('/prj');
    }

    public function joinsAction($params)
    {
        $user = $this->session->get('user');
        $project_repository = $this->db_manager->get('Project');
        $project = $project_repository->fetchByProjectId($params['project_no']);
        if (!$project) {
            return $this->redirect('/');
        }

        //参加中と管理者チェック
        if (!$project_repository->isJoinProjectMangeUser($project['project_id'], $user['user_id']) && !$this->session->isAdministratorLevel()) {
            return $this->redirect('/readingerror');
        }
        $users = $project_repository->fetchAllUserByProjectJoin($project['project_id']);

        return $this->render(
            array(
                    'project' => $project,
                    'users' => $users,
                '_token' => $this->generateCsrfToken('prj/joins'),
            )
        );
    }

    public function joinchangeAction($params)
    {
        if (!$this->request->isPost()) {
            return $this->forward404();
        }

        $token = $this->request->getPost('_token');
        if (!$this->checkCsrfToken('prj/joins', $token)) {
            return $this->redirect('/');
        }
        $user = $this->session->get('user');
        $project_repository = $this->db_manager->get('Project');
        $project = $project_repository->fetchByProjectId($params['project_no']);
        if (!$project) {
            return $this->redirect('/');
        }

        //参加中と管理者チェック
        if (!$project_repository->isJoinProjectMangeUser($project['project_id'], $user['user_id']) && !$this->session->isAdministratorLevel()) {
            return $this->redirect('/readingerror');
        }

        $action = $this->request->getPost('action');
        $manage_members = $this->request->getPost('manage_members');
        $members = $this->request->getPost('members');
        $no_members = $this->request->getPost('no_members');

        $result = array();
        switch ($action) {
            //管理者の変更
            case 'manage_members_remove':
               if (!$manage_members || !is_array($manage_members)) {
                   $result[] = 'ユーザーを選択してください';
               } else {
                   $count = $project_repository->fetchCountManageUserByProjectJoin($project['project_id']);
                   if (!$count || $count['count'] === '0') {
                       $result[] = '管理者がいません設定をしてください';
                   } elseif (intval($count['count']) === count($manage_members)) {
                       $result[] = '最低一人は管理者を残してください';
                   } else {
                       $remove_ok = $this->checkJoinRemoveHandleUsers(
                             $this->db_manager->get('Task')->fetchAllHandleTaskUserByProjectId($project['project_id']),
                             $manage_members
                         );
                       if (count($remove_ok) === 0) {
                           $result[] = '担当中のタスクを持っている方がいるため削除できませんでした';
                       } else {
                           $result = $project_repository->removeJoinUsersProject($project['project_id'], $remove_ok, $project['create_user_id']);
                           if (count($remove_ok) !== count($manage_members)) {
                               $result[] = '担当中のタスクを持っている方は削除していません';
                           }
                       }
                   }
               }
                break;
            case 'manage_members_down':
                $count = $project_repository->fetchCountManageUserByProjectJoin($project['project_id']);
                if (!$count || $count['count'] === '0') {
                    $result[] = '管理者がいません設定をしてください';
                } elseif (intval($count['count']) === count($manage_members)) {
                    $result[] = '最低一人は管理者を残してください';
                } else {
                    $result = $project_repository->setJoinUsersProject($project['project_id'], $manage_members, 5, $project['create_user_id']);
                }

                break;
            //メンバーの変更
            case 'members_remove':
                if (!$members || !is_array($members)) {
                    $result[] = 'ユーザーを選択してください';
                } else {
                    $remove_ok = $this->checkJoinRemoveHandleUsers(
                         $this->db_manager->get('Task')->fetchAllHandleTaskUserByProjectId($project['project_id']),
                         $members
                     );
                    if (count($remove_ok) === 0) {
                        $result[] = '担当中のタスクを持っているため削除できませんでした';
                    } else {
                        $result = $project_repository->removeJoinUsersProject($project['project_id'], $remove_ok, $project['create_user_id']);
                        if (count($remove_ok) !== count($members)) {
                            $result[] = '担当中のタスクを持っている方は削除していません';
                        }
                    }
                }
                break;
            case 'members_up':
                $result = $project_repository->setJoinUsersProject($project['project_id'], $members, 1, $project['create_user_id']);
                break;
            //メンバーじゃない人の変更
            case 'no_members_add':
                $result = $project_repository->setJoinUsersProject($project['project_id'], $no_members, 5, $project['create_user_id']);
                break;
            case 'no_members_add_manage':
                $result = $project_repository->setJoinUsersProject($project['project_id'], $no_members, 1, $project['create_user_id']);
                break;

            default:
                return $this->redirect('/prj/joins/'.$project['project_id']);
        }
        if ($result && count($result) > 0) {
            $this->session->setToasts($result);
        }

        return $this->redirect('/prj/joins/'.$project['project_id']);
    }

    private function checkJoinRemoveHandleUsers($tasks, $members)
    {
        var_dump($tasks);
        $remove_ok = array();
        foreach ($members as $user_id) {
            if (array_search($user_id, array_column($tasks, 'handle_user_id')) === false) {
                $remove_ok[] = $user_id;
            }
        }

        return $remove_ok;
    }


    public function notReadingAuthorityAction()
    {
        return $this->render(
            array(), 'not_reading_authority'
        );
    }
}
