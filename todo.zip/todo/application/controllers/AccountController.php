<?php

class AccountController extends Controller
{

    protected $auth_actions = array(
        'index',
        'logout',
        'edit',
        'editPost',
        'signup',
        'register',
        'authority',
        'authorityPost',
        'restoration',
        'restorationPost',
        'remove',
        'removepost',
        'user',
    );

    protected $not_change_authority_level_id = array(
        'miwa',
    );

    public function notChangeAuthority($user_name)
    {
        if ($this->not_change_authority_level_id === false ||
              (is_array($this->not_change_authority_level_id) && in_array($user_name, $this->not_change_authority_level_id))) {
            return true;
        }
        return false;
    }

    public function indexAction()
    {
        $user = $this->session->get('user');
        return $this->render(
            array(
                'user' => $user
            )
        );
    }

    public function loginAction()
    {
        if ($this->session->isAuthAndVerification()) {
            return $this->redirect('/');
        }

        return $this->render(
            array(
                'user_name' => '',
                'password' => '',
                '_token' => $this->generateCsrfToken('account/login')
            )
        );
    }

    public function authAction()
    {
        if ($this->session->isAuthAndVerification()) {
            return $this->redirect('/');
        }

        if (! $this->request->isPost()) {
            return $this->forward404();
        }

        $token = $this->request->getPost('_token');
        if (! $this->checkCsrfToken('account/login', $token)) {
            return $this->redirect('/account/login');
        }

        $user_name = $this->request->getPost('user_name');
        $password = $this->request->getPost('password');

        $errors = array();

        if (! strlen($user_name)) {
            $errors[] = 'ユーザーIDを入力してください';
        }

        if (! strlen($password)) {
            $errors[] = 'パスワードを入力してください';
        }

        if (count($errors) === 0) {
            $user_repository = $this->db_manager->get('Account');
            $user = $user_repository->fetchByUserName($user_name);

            if (! $user || ($user['password'] !== $user_repository->hashPassword($password))) {
                $errors[] = 'ユーザIDかパスワードが違います';
            } else {
                $this->session->setAuthenticated(true);
                $this->session->set('user', $user);

                return $this->redirect('/');
            }
        }

        return $this->render(
            array(
                'user_name' => $user_name,
                'password' => $password,
                'errors' => $errors,
                '_token' => $this->generateCsrfToken('account/login')
            ),
            'login'
        );
    }

    public function logoutAction()
    {
        $this->session->clear();
        $this->session->setAuthenticated(false);
        return $this->redirect('/account/login');
    }

    public function signupAction()
    {
        if (!$this->session->isDeveloperLevel()) {
            return $this->redirect('/');
        }
        $authoritys = $this->db_manager->get('Account')->fetchAllByAuthority();
        return $this->render(
            array(
                'user_name' => '',
                'password' => '',
                'show_name' => '',
                'authoritys' => $authoritys,
                '_token' => $this->generateCsrfToken('account/signup')
            )
        );
    }

    public function registerAction()
    {
        if (! $this->request->isPost()) {
            return $this->forward404();
        }

        if (!$this->session->isDeveloperLevel()) {
            return $this->redirect('/');
        }


        $errors = array();
        $user_name = $this->request->getPost('user_name');
        $password = $this->request->getPost('password');
        $show_name = $this->request->getPost('show_name');
        $authority_level = $this->request->getPost('authority');

        $token = $this->request->getPost('_token');
        if (! $this->checkCsrfToken('account/signup', $token)) {
            $errors[] = '不正な遷移を検出しました、この画面でブラウザバックは行わないでください';
            //return $this->redirect('/account/signup');
        }


        if (! strlen($user_name)) {
            $errors[] = 'ユーザーIDを入力してください';
        } else if (! preg_match('/^\w{3,20}$/', $user_name)) {
            $errors[] = 'ユーザーIDは半角英数字およびアンダースコアを3~20文字以内で入力してください';
        } else if (! $this->db_manager->get('Account')->isUniqueUserName($user_name)) {
            $errors[] = 'このユーザーIDはすでに使用されています';
        }

        if (! strlen($show_name)) {
            $errors[] = 'ユーザー名を入力してください';
        } else if (mb_strlen($show_name) > 20) {
            $errors[] = 'ユーザー名は20文字以内で入力してください';
        }

        if (! strlen($password)) {
            $errors[] = 'パスワードを入力してください';
        } else if (4 > strlen($password) || strlen($password) > 30) {
            $errors[] = 'パスワードは4文字以上30文字以内で入力してください';
        }

        if (! strlen($authority_level)) {
            $errors[] = '権限を選択してください';
        }

        if (count($errors) === 0) {
            $user_repository = $this->db_manager->get('Account');
            $user_repository->insert($user_name, $password, $show_name, $authority_level);
            $user = $user_repository->fetchByUserName($user_name);
            $users = $this->db_manager->get('Account')->fetchAllByUser();
            $this->session->setToasts(array($user['show_name'] . '(ID : ' . $user['user_name']  .  ')さんを登録しました'));
            return $this->redirect('/manage/users');
        }

        $authoritys = $this->db_manager->get('Account')->fetchAllByAuthority($this->session->isAdministratorLevel());
        return $this->render(
            array(
                'user_name' => $user_name,
                'password' => $password,
                'show_name' => $show_name,
                'errors' => $errors,
                'authoritys' => $authoritys,
                '_token' => $this->generateCsrfToken('account/signup')
            ),
            'signup'
        );
    }


    public function editAction($params)
    {

        $user = $this->session->get('user');

            return $this->render(
                array(
                    'show_name' => $user['show_name'],
                    '_token' => $this->generateCsrfToken('account/profile')
                )
            );
    }


    public function editPostAction($params)
    {

        if (! $this->request->isPost()) {
            return $this->forward404();
        }

        $errors = array();

        $token = $this->request->getPost('_token');
        if (! $this->checkCsrfToken('account/profile', $token)) {
            $errors[] = '不正な遷移を検出しました、この画面でブラウザバックは行わないでください';
            //return $this->redirect('/account');
        }

        $user = $this->session->get('user');
        $show_name = $this->request->getPost('show_name');
        $password = $this->request->getPost('password');
        $password_conf = $this->request->getPost('password_conf');

        if (! strlen($show_name)) {
            $errors[] = 'ユーザー名を入力してください';
        } else if (mb_strlen($show_name) > 40) {
            $errors[] = 'ユーザー名は40文字以内で入力してください';
        }

        $passchange = true;
        if (! strlen($password)) {
            $passchange = false;
        } else if (4 > strlen($password) || strlen($password) > 30) {
            $errors[] = 'パスワードは4文字以上30文字以内で入力してください';
        } else if ($password !== $password_conf) {
            $errors[] = '確認用パスワードと一致しません。';
        }



        if (count($errors) === 0) {
            $user_repository = $this->db_manager->get('Account');
            $user_repository->updateProfile($user['user_name'], $show_name, $password, $passchange);
            $user = $user_repository->fetchByUserName($user['user_name']);
            $this->session->set('user', $user);
            $this->session->setToasts(array('プロフィールを更新しました'));
            return $this->redirect('/account');
        }


        return $this->render(
            array(
                    'show_name' => $show_name,
                    'errors' => $errors,
                    '_token' => $this->generateCsrfToken('account/profile')
            ),
            'edit'
        );
    }



    public function authorityAction($params)
    {

        if (! $this->session->isDeveloperLevel()) {
            return $this->redirect('/account');
        }

        if (! $params['user_name']) {
            return $this->redirect('/manage/users');
        }
        $user = $this->db_manager->get('Account')->fetchByUserName($params['user_name']);

        if (! $user) {
            return $this->redirect('/manage/users');
        }

        $authoritys = $this->db_manager->get('Account')->fetchAllByAuthority($this->session->isAdministratorLevel());

        return $this->render(
            array(
                'user' => $user,
                'authoritys' => $authoritys,
                '_token' => $this->generateCsrfToken('account/authority')
            )
        );
    }


    public function authorityPostAction($params)
    {

        if (! $this->request->isPost()) {
            return $this->forward404();
        }

        if (! $this->session->isDeveloperLevel()) {
            return $this->redirect('/account');
        }

        if (! $params['user_name']) {
            return $this->redirect('/manage/users');
        }

        $token = $this->request->getPost('_token');
        if (! $this->checkCsrfToken('account/authority', $token)) {
            return $this->redirect('/manage/users');
        }

        $user = $this->db_manager->get('Account')->fetchByUserName($params['user_name']);
        if (! $user) {
            return $this->redirect('/manage/users');
        }

        $errors = array();
        $authority_level = $this->request->getPost('authority');

        if (! strlen($authority_level)) {
            $errors[] = '権限を選択してください';
        } else if ($this->notChangeAuthority($user['user_name'])) {
            $errors[] = 'このIDは権限変更できません';
        }

        if (count($errors) === 0) {
            $user_repository = $this->db_manager->get('Account');
            $user_repository->updateAuthority($user['user_name'], $authority_level);
            $user = $this->db_manager->get('Account')->fetchByUserName($params['user_name']);

            $my = $this->session->get('user');
            if ($my['user_name'] === $user['user_name']) {
                $this->session->set('user', $user);
            }
            $this->session->setToasts(array($user['show_name'] . '(' . $user['user_name']  .  ')さんの権限を「' . $user['authority_name'] . '」に更新しました'));
            return $this->redirect('/manage/users');
        }

        $authoritys = $this->db_manager->get('Account')->fetchAllByAuthority();

        return $this->render(
            array(
                'user' => $user,
                'authoritys' => $authoritys,
                'errors' => $errors,
                '_token' => $this->generateCsrfToken('account/authority')
            ),
            'authority'
        );
    }

    public function removeAction($params)
    {

        if (! $this->session->isDeveloperLevel()) {
            return $this->redirect('/account');
        }

        if (! $params['user_name']) {
            return $this->redirect('/manage/users');
        }

        $user = $this->db_manager->get('Account')->fetchByUserName($params['user_name']);

        if (! $user) {
            return $this->redirect('/manage/users');
        }


        return $this->render(
            array(
                'user' => $user,
                '_token' => $this->generateCsrfToken('account/remove')
            )
        );
    }


    public function removePostAction($params)
    {
        if (! $this->request->isPost()) {
            return $this->forward404();
        }

        if (! $this->session->isDeveloperLevel()) {
            return $this->redirect('/account');
        }

        if (! $params['user_name']) {
            return $this->redirect('/manage/users');
        }

        $token = $this->request->getPost('_token');
        if (! $this->checkCsrfToken('account/remove', $token)) {
            return $this->redirect('/manage/users');
        }

        $user_repository = $this->db_manager->get('Account');
        $user = $user_repository->fetchByUserName($params['user_name']);
        if (! $user) {
            return $this->redirect('/manage/users');
        }

        if ($this->notChangeAuthority($user['user_name'])) {
            $errors[] = 'このIDは削除できません';
        }


            $user_repository->removeByUser($user['user_name']);

            $my = $this->session->get('user');
        if ($my['user_name'] === $user['user_name']) {
            $this->session->clear();
            $this->session->setAuthenticated(false);
        }
            $this->session->setToasts(array($user['show_name'] . '(' . $user['user_name']  .  ')さんを削除しました'));
            return $this->redirect('/manage/users');
    }

    public function restorationAction($params)
    {

        if (! $this->session->isDeveloperLevel()) {
            return $this->redirect('/account');
        }

        if (! $params['user_name']) {
            return $this->redirect('/manage/users');
        }

        $user = $this->db_manager->get('Account')->fetchByUserName($params['user_name'], true);

        if (! $user) {
            return $this->redirect('/manage/users');
        }


        return $this->render(
            array(
                'user' => $user,
                '_token' => $this->generateCsrfToken('account/restoration')
            )
        );
    }


    public function restorationPostAction($params)
    {
        if (! $this->request->isPost()) {
            return $this->forward404();
        }

        if (! $this->session->isDeveloperLevel()) {
            return $this->redirect('/account');
        }

        if (! $params['user_name']) {
            return $this->redirect('/manage/users');
        }

        $token = $this->request->getPost('_token');
        if (! $this->checkCsrfToken('account/restoration', $token)) {
            return $this->redirect('/manage/users');
        }

        $user_repository = $this->db_manager->get('Account');
        $user = $this->db_manager->get('Account')->fetchByUserName($params['user_name'], true);
        if (! $user) {
            return $this->redirect('/manage/users');
        }

        $user_repository->restorationByUser($user['user_name']);
        $this->session->setToasts(array($user['show_name'] . '(' . $user['user_name']  .  ')さんを復活しました'));
        return $this->redirect('/manage/users');
    }

    public function userAction($params)
    {
        $user = $this->db_manager->get('Account')->fetchByUserName($params['user_name']);

        if (!$user) {
            return $this->redirect('/account/users');
        }


        $project_page_no = $this->request->getGet('pno','1');
        $task_page_no = $this->request->getGet('tno','1');
        $task_page_sort = $this->request->getGet('sort','schedule');
        $task_page_desc = $this->request->getGet('desc',true);
        $project_repository = $this->db_manager->get('Project');
        $task_repository = $this->db_manager->get('Task');
        $util = new Utility();

        $projects_count = $project_repository->fetchCountJoinAllProjectByUserId($user['user_id']);
        $projects_pager = $util->createPager($project_page_no,$projects_count['count'],Env::PROJECT_PAGE_LIMIT);
        //var_dump($projects_pager);

        $projects = $project_repository->fetchAllJoinAllProjectsByUserId($user['user_id'],$projects_pager['offset_records'],$projects_pager['view_count']);
       // $projects = $project_repository->fetchAllJoinProjectByUserId($user['user_id']);

        $tasks_count = $task_repository->fetchCountHandleAllTaskByUserId($user['user_id']);
        $tasks_pager = $util->createPager($task_page_no,$tasks_count['count'],Env::TASK_PAGE_LIMIT);
        $tasks = $task_repository->fetchAllHandleAllTaskByUserId($user['user_id'],$tasks_pager['offset_records'],$tasks_pager['view_count'],!$task_page_sort ? 'schedule' : $task_page_sort,$task_page_desc);

        $task_sort_url = $util->createTaskSortUrl($task_page_sort,$task_page_desc);

        return $this->render(
            array(
                'user' => $user,
                'tasks' => $tasks,
                'projects_pager' => $projects_pager,
                'projects' => $projects,
                'tasks_pager' => $tasks_pager,
                'task_sort_url'=> $task_sort_url,
                'task_sort'=> $task_page_sort,
                'task_desc'=> $task_page_desc,
                'tasks' => $tasks,
                'manager' => $this->session->isManagerLevel(),
            )
        );
    }
}
