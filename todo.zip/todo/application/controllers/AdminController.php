<?php

class AdminController extends Controller
{

    protected $auth_actions = array(
        'users',
        'projects',
        'project',
        'hiddenTasks',
        'restoration',
        'restore',
        'task',
    );

    protected $not_change_authority_level_id = array(
        'miwa',
    );

    public function notChangeAuthority($user_name)
    {
        if ($this->not_change_authority_level_id === false ||
              (is_array($this->not_change_authority_level_id) && in_array($user_name, $this->not_change_authority_level_id))) {
            return true;
        }
        return false;
    }

    public function projectsAction()
    {
        if (! $this->session->isAdministratorLevel()) {
            return $this->redirect('/');
        }
        $project_repository = $this->db_manager->get('Project');

        $page_no = $this->request->getGet('p','0');
        $count = $project_repository->fetchCountAllProject();   // データ総数

        $util = new Utility();

        $pager = $util->createPager($page_no,$count['count'], Env::ADMIN_PROJECT_PAGE_LIMIT);

        //var_dump($pager);

        $projects = $this->db_manager->get('Project')->fetchAllProjects($pager['now_offset'],$pager['now_offset_limit']);
        return $this->render(
            array(
                'projects' => $projects,
                'pager' => $pager
            )
        );
    }
    public function restorationAction($params)
    {
        if (! $this->session->isDeveloperLevel()) {
            return $this->redirect('/');
        }

        if (! isset($params['no']) || !(isset($params['action']) && $params['action']==='restoration') || !isset($params['type'])) {
            return $this->redirect('/manage/projects');
        }
        $action = $params['action'];
        $type = $params['type'];
        $no = $params['no'];
        switch ($type) {
            case 'project':
                $project = $this->db_manager->get('Project')->fetchByProjectId($no, true);
                if (! $project) {
                    return $this->redirect('/manage/projects');
                }
                return $this->render(
                    array(
                            'action' => $action,
                            'type' => $type,
                            'no' => $no,
                            'page_title' => 'プロジェクトの復活',
                            'name' => $project['project_name'],
                            'summary' => $project['project_summary'],
                            '_token' => $this->generateCsrfToken('admin/restoration')
                        ),
                    'action'
                );
            case 'task':
                if (! isset($params['no2'])) {
                    return $this->redirect('/manage/projects/'.$params['no2']);
                }
                $no2 = $params['no2'];
                $task = $this->db_manager->get('Task')->fetchRemovedByTaskId($no2);
                if (! $task) {
                    return $this->redirect('/manage/projects');
                }
                return $this->render(
                    array(
                            'action' => $action,
                            'type' => $type,
                            'no' => $no,
                            'no2' => $no2,
                            'page_title' => 'タスクの復活',
                            'name' => $task['task_name'],
                            'summary' => $task['task_summary'],
                            '_token' => $this->generateCsrfToken('admin/restoration')
                        ),
                    'action'
                );
        }
        return $this->redirect('/');
    }

    public function restoreAction($params)
    {
        if (! $this->session->isDeveloperLevel()) {
            return $this->redirect('/');
        }

        if (!$this->request->isPost()) {
            return $this->forward404();
        }

        if (! isset($params['no']) || !(isset($params['action']) && $params['action']==='restore') || !isset($params['type'])) {
            return $this->redirect('/manage/projects');
        }
        //$_action = $params['action'];
        $_type = $params['type'];
        $_no = $params['no'];
        $action = $this->request->getPost('action');
        $type = $this->request->getPost('type');
        $no = $this->request->getPost('no');

        //念のためパラメータチェック いらないかも
        if ($action !== 'restoration' || $no !== $_no || $type !== $_type) {
            return $this->redirect('/manage/projects');
        }

        switch ($type) {
            case 'project':
                 $project_repository = $this->db_manager->get('Project');
                 $project = $project_repository->fetchByProjectId($no, true);
                if (! $project) {
                    $this->session->setToasts(array('プロジェクトが見つかりませんでした'));
                    return $this->redirect('/manage/projects');
                }
                 $project_repository->restoreProject($project['project_id']);
                 $this->session->setToasts(array('プロジェクト（' . $project['project_name'] . '）を復元しました'));
                return $this->redirect('/manage/projects');
            case 'task':
                if (! isset($params['no2'])) {
                    return $this->redirect('/manage/projects/'.$params['no2']);
                }
                $_no2 = $params['no2'];
                $no2 = $this->request->getPost('no2');
                if ($no2 !== $_no2) {
                    return $this->redirect('/manage/projects/'.$params['no2']);
                }
                 $task_repository = $this->db_manager->get('Task');
                 $task = $task_repository->fetchRemovedByTaskId($no2);
                if (! $task) {
                    $this->session->setToasts(array('タスクが見つかりませんでした'));
                    return $this->redirect('/manage/projects');
                }
                 $task_repository->restoreTask($task['task_id']);
                 $this->session->setToasts(array('タスク（' . $task['task_name'] . '）を復元しました'));
                return $this->redirect('/manage/projects/'. $task['project_id']);
        }
        return $this->redirect('/');
    }


    public function hiddenTasksAction($params)
    {
        if (! $this->session->isDeveloperLevel()) {
            return $this->redirect('/');
        }

        if (! isset($params['project_no'])) {
            return $this->redirect('/manage/projects');
        }
        $tasks = $this->db_manager->get('Task')->fetchAllByRemovedProjectId($params['project_no']);
        return $this->render(
            array(
                'project_id' => $params['project_no'],
                'tasks' => $tasks
            ),
            'tasks'
        );
    }


    public function usersAction()
    {

        if (! $this->session->isManagerLevel()) {
            return $this->redirect('/');
        }
        $users = $this->db_manager->get('Account')->fetchAllWithHandleTaskByUser();

        return $this->render(
            array(
                'users' => $users
            )
        );
    }
}
