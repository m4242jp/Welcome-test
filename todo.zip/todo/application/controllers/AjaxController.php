<?php
//テスト用
class AjaxController extends Controller
{
    protected $auth_actions = array(
        'sendtest'
    );

    protected $auth_ajax_actions = array(
        'sendtest', );

    public function sendtestAction()
    {
        if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            header('Content-type: text/plain; charset=UTF-8');

            if (!$this->request->isPost()) {
                return 'NG.';
            }

            if (!$this->session->isAuthAndVerification()) {
                return 'NOT AUTH';
            }
            if (isset($_POST['request'])) {
                //ここに何かしらの処理を書く（DB登録やファイルへの書き込みなど）
                return 'OK';
            } else {
                return 'The parameter of "request" is not found.';
            }
        }

        return 'not ajax.';
    }

}
