<header>
    <div>
        <nav id="naviTop" class="nav-extended header-back-color">
            <div class="nav-wrapper">
                <a href="<?php echo $base_url;?>/" class="brand-logo brand-logo-font brand-logo-padding">MINI TODO</a>
                <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a>
                <ul class="right hide-on-med-and-down">
                    <?php if (isset($navigations) && is_array($navigations) && count($navigations)>0): ?>
                    <?php foreach ($navigations as $navigation): ?>
                    <?php if (isset($navigation['url']) && isset($navigation['title'])): ?>
                    <li><a href="<?php echo $this->escape($navigation['url']);?>"><?php echo $this->escape($navigation['title']) ?></a></li>
                    <?php endif;?>
                    <?php endforeach;?>
                    <?php endif;?>
                    <li><a class="dropdown-button dropdown-button-arrow-after" href="#!" data-activates='dropdown_menu' data-constrainWidth="false" data-beloworigin="true">
                    <?php echo $this->escape($login_name);?>さん</a></li>
                    <?php if($develop || $manager):?>
                    <li><a  class="dropdown-button" href="#!" data-activates='dropdown_menu_manage' data-constrainWidth="false" data-beloworigin="true"><i class="material-icons">more_vert</i></a></li>
                    <?php endif;?>
                    <!-- Dropdown Structure -->
                    <ul id='dropdown_menu' class='dropdown-content'>
                        <li><a href="<?php echo $base_url;?>/"><i class="material-icons">home</i>ホーム</a></li>
                        <li><a href="<?php echo $base_url;?>/account"><i class="material-icons">person</i>アカウント</a></li>
                        <li class="divider"></li>
                        <li><a href="<?php echo $base_url;?>/account/logout">ログアウト</a></li>
                    </ul>
                    <?php if($develop || $manager):?>
                    <ul id='dropdown_menu_manage' class='dropdown-content'>
                        <?php if($develop):?>
                        <li><a href="<?php echo $base_url;?>/account/signup">アカウント登録</a></li>
                        <?php endif;?>
                        <?php if($manager):?>
                        <li><a href="<?php echo $base_url;?>/manage/users">ユーザー一覧</a></li>
                        <li><a href="<?php echo $base_url;?>/manage/projects">プロジェクト一覧</a></li>
                        <?php endif;?>
                    </ul>
                    <?php endif;?>
                </ul>
            </div>
            <?php if (isset($breadcrumbs) && is_array($breadcrumbs) && count($breadcrumbs)>0): ?>
            <div class="nav-content toolbar-content ">
                <a href="<?php echo $base_url;?>/" class="breadcrumb">ホーム</a>
                <?php foreach ($breadcrumbs as $breadcrumb): ?>
                <?php if (isset($breadcrumb['url']) && isset($breadcrumb['title'])): ?>
                <a href="<?php echo $this->escape($breadcrumb['url']);?>" class="breadcrumb"><?php echo $this->escape($breadcrumb['title']) ?></a>
                <?php endif;?>
                <?php endforeach;?>
            </div>
            <?php endif;?>
        </nav>
    </div>
    <ul class="side-nav" id="mobile-demo">
        <li><div class="user-view"><?php echo $this->escape($login_name);?>さん</div></li>
        <li><a href="<?php echo $base_url;?>/"><i class="material-icons">home</i>ホーム</a></li>
        <li><a href="<?php echo $base_url;?>/account"><i class="material-icons">person</i>アカウント</a></li>
        <li class="divider"></li>
        <?php if($develop):?>
        <li><a href="<?php echo $base_url;?>/account/signup">アカウント登録</a></li>
        <?php endif;?>
        <?php if($manager):?>
        <li><a href="<?php echo $base_url;?>/manage/users">ユーザー一覧</a></li>
        <li><a href="<?php echo $base_url;?>/manage/projects">プロジェクト一覧</a></li>
        <?php endif;?>
        <?php if (isset($navigations) && is_array($navigations) && count($navigations)>0): ?>
        <?php foreach ($navigations as $navigation): ?>
        <?php if (isset($navigation['url']) && isset($navigation['title'])): ?>
        <li><a href="<?php echo $this->escape($navigation['url']);?>"><?php echo $this->escape($navigation['title']) ?></a></li>
        <?php endif;?>
        <?php endforeach;?>
        <li class="divider"></li>
        <?php endif;?>
        <li><a href="<?php echo $base_url;?>/account/logout">ログアウト</a></li>
    </ul>
</header>