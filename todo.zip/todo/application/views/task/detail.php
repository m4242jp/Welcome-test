<?php $this->setLayoutVar('title', $this->escape($task['task_name']));?>
<?php $this->setLayoutVar('isReadMore', true);?>
<?php $this->setLayoutVar('isThread', true);?>
<?php $this->setLayoutVar('breadcrumbs', array(array(
'url'=> $base_url . '/prj/' . $this->escape($project['project_id'] . '/tasks' ),
'title'=>$this->escape($project['project_name'])
)));?>
<?php if(isset($errors) && count($errors)>0): ?>
<?php $this->setLayoutVar('errors', $errors);?>
<?php endif;?>
<?php
$task_create_date = $this->escapeDate($task['create_date'],'Y-m-d H:i');
$task_update_date = $this->escapeDate($task['update_date'],'Y-m-d H:i');
$category_class='orange white-text';
switch ($task['category_id']){
case '1':;
$category_class = 'green white-text';
break;
case '2':
$category_class = 'red white-text';
break;
case '3':
$category_class = 'blue white-text';
break;
}
?>
<div class="col s12 m12 l9 ">
    <div id="task_content" class="section">
        <div class="toolbar-content max-width card  valign-wrapper <?php echo $category_class ?>">
            <h1 class="page-title"><strong><?php echo $this->escape($task['task_name']); ?></strong></h1>
        </div>
        <div class="card">
            <div class="card-content">
                <div><span class="readmore break"><?php echo nl2br($this->escape($task['task_summary'],true)); ?></span></div>
                <div class="row no-margin-bottom">
                    <div class="col right  right-align">
                        <?php if ($isJoinManage || $admin): ?>
                        <span><a href="<?php echo $base_url; ?>/prj/<?php echo $this->escape($project['project_id']); ?>/tasks/<?php echo $this->escape($task['task_id']); ?>/edit">
                        内容の編集</a></span><br />
                        <?php endif; ?>
                        <span><?php echo $task_create_date ?></span>
                        <?php if($task_create_date !== $task_update_date): ?>
                        <span class="grey-text darken-1" style="font-size: 80%; ">更新：<?php echo $task_update_date ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="col s12 m12 l3 right">
    <div id="users" class="section">
        <div class="toolbar-content max-width card  valign-wrapper light-blue white-text">
            <h1 class="page-title truncate"><strong>情報</strong></h1>
        </div>
        <div class="card">
            <div class="card-content">
                <div>
                    <div class="task_date margin-bottom-20">
                        <p><span class="label">分類</span></p>
                        <p class="margin-bottom-8"><?php echo $this->escape($task['category_name']); ?></p>
                        <p><span class="label">優先度</span></p>
                        <p class="margin-bottom-8"><?php echo $this->escape($task['priority_name']); ?></p>
                        <p><span class="label">担当</span></p>
                        <p class="margin-bottom-8"><?php echo $this->escape($task['handle_name']); ?></p>
                        <p><span class="label">ステイタス</span></p>
                        <p class="margin-bottom-8"><?php echo $this->escape($task['status_name']); ?></p>
                        <p><span class="label">終了予定日</span></p>
                        <p class="margin-bottom-8"><?php echo $this->escapeDate($task['schedule']); ?></p>
                        <p><span class="label">作成者</span></p>
                        <?php if (!$task['user_removed']): ?>
                        <p class="margin-bottom-8"><?php echo $this->escape(!$task['creater_show_name'] ? 'いません' : $task['creater_show_name']); ?></p>
                        <?php else: ?>
                        <p class="margin-bottom-8">退会済み</p>
                        <?php endif; ?>
                        <p><span class="label">作成日</span></p>
                        <p class="margin-bottom-8"><?php echo $this->escape($task['create_date']); ?></p>
                        <?php if($task_create_date !== $task_update_date): ?>
                        <p><span class="label">更新日</span></p>
                        <p class="margin-bottom-8"><?php echo $this->escape($task['update_date']); ?></p>
                        <?php endif; ?>
                    </div>
                    <?php if ($isJoinManage || $admin): ?>
                    <div>
                        <ul class="collapsible" data-collapsible="accordion" >
                            <li>
                                <div class="collapsible-header center-align light-blue white-text <?php if($is_active_info): echo 'active';endif; ?>">更新</div>
                                <div class="collapsible-body">
                                    <form action="<?php echo $base_url; ?>/prj/<?php echo $this->escape($project['project_id']); ?>/tasks/<?php echo $this->escape($task['task_id']); ?>/statuschange" method="post">
                                        <input type="hidden" name="_token"
                                        value="<?php echo $this->escape($_token); ?>" />
                                        <label>優先度</label>
                                        <div class="input-field">
                                            <select name="priority_id">
                                                <?php foreach ($prioritys as $priority): ?>
                                                <option value="<?php echo $this->escape($priority['priority_id']); ?>"
                                                    <?php echo $this->escape($priority['priority_id'] === $priority_id ? 'selected="selected' : '' ); ?>
                                                ><?php echo $this->escape($priority['priority_name']); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <label>終了予定日</label>
                                        <div class="input-field">
                                            <input type="date" name="schedule" class="datepicker"
                                            value="<?php echo $this->escapeDate($schedule,'Y-m-d','');?>" />
                                        </div>
                                        <label>担当者</label>
                                        <div class="input-field">
                                            <select name="handle_user_id">
                                                <option value="">未設定</option>
                                                <?php foreach ($join_users as $join_user): ?>
                                                <option value="<?php echo $this->escape($join_user['user_id']); ?>"
                                                    <?php echo $this->escape($join_user['user_id'] === $handle_user_id ? 'selected="selected"' : '' ); ?>
                                                ><?php echo $this->escape($join_user['show_name']); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <label>ステイタス</label>
                                        <div class="input-field">
                                            <select name="status">
                                                <?php foreach ($task_statuses as $task_status): ?>
                                                <option value="<?php echo $this->escape($task_status['status_id']); ?>"
                                                    <?php echo $this->escape($task_status['status_id'] === $status_id ? 'selected="selected' : '' ); ?>
                                                ><?php echo $this->escape($task_status['status_name']); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <button type="submit" value="" class="waves-effect waves-light btn" style="width: 100%;">送信</button>
                                    </form>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="col s12 m12 l9 ">
    <div id="task_threads" class="section">
        <?php if ($isJoinManage || $admin): ?>
        <ul class="collapsible" data-collapsible="accordion" >
            <li>
                <div class="collapsible-header center-align light-blue white-text <?php if($is_active_thread): echo 'active';endif; ?>">&nbsp;メッセージ投稿</div>
                <div class="collapsible-body">
                    <div class="row no-margin-bottom">
                        <form action="<?php echo $base_url; ?>/prj/<?php echo $this->escape($project['project_id']); ?>/tasks/<?php echo $this->escape($task['task_id']); ?>/postthread" method="post">
                            <input type="hidden" name="_token" value="<?php echo $this->escape($_token); ?>" />
                            <div class="row">
                                <div class="input-field col s12">
                                    <textarea id="threadtextarea" name="thread_body"
                                    data-original-height="0"
                                    class="materialize-textarea character_counter validate" data-length="1000"><?php echo $this->escape($thread_body); ?></textarea>
                                    <label for="threadtextarea">内容</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col s12 label">
                                 ▼&nbsp;投稿時に担当者やステイタスを更新したい場合は選択してください。
                                </div>
                                <div class="col s6 center-align">
                                    <label>担当者</label>
                                    <div class="input-field inline">
                                        <select name="handle_user_id">
                                            <option value="">未設定</option>
                                            <?php foreach ($join_users as $join_user): ?>
                                            <option value="<?php echo $this->escape($join_user['user_id']); ?>"
                                                <?php echo $this->escape($join_user['user_id'] === $handle_user_id ? 'selected="selected"' : '' ); ?>
                                            ><?php echo $this->escape($join_user['show_name']); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col s6 center-align">
                                    <label>ステイタス</label>
                                    <div class="input-field inline">
                                        <select name="status">
                                            <?php foreach ($task_statuses as $task_status): ?>
                                            <option value="<?php echo $this->escape($task_status['status_id']); ?>"
                                                <?php echo $this->escape($task_status['status_id'] === $status_id ? 'selected="selected' : '' ); ?>
                                            ><?php echo $this->escape($task_status['status_name']); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class=" center-align  col s12">
                                    <button type="submit" class="waves-effect waves-light btn">送信</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </li>
        </ul>
        <?php endif; ?>
        <div class="">
            <div class="timeline">
                <?php foreach ($threads as $thread): ?>
                <div class="timeline-item" id="timeline-example-2">
                    <div class="timeline-left">
                        <?php if(!$thread['system']): ?>
                        <span class="timeline-icon icon-lg">
                            <i class="material-icons" style="padding-top: 5px;">person</i>
                        </span>
                        <?php else: ?>
                        <span class="timeline-icon icon"></span>
                        <?php endif; ?>
                    </div>
                    <div class="timeline-content">
                        <?php echo $this->render('task/thread',array('thread'=> $thread,'_token'=>$_token,'project_id' => $project['project_id'],'task_id' => $task['task_id'])); ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <!-- Modal Thread編集 -->
            <div id="modalEditableThread" class="modal modal-fixed-footer">
                <form
                    id="modalEditableThread"
                    action="#"
                    method="post">
                    <div class="modal-content">
                        <h4>コメントの編集</h4>
                        <input type="hidden" name="_token"
                        value="<?php echo $this->escape($_token); ?>" />
                        <input type="hidden" name="_thread"
                        value="" />
                        <div class="row">
                            <div class="input-field col s12">
                                <textarea id="threadtextarea" name="thread_body" class="materialize-textarea character_counter validate" data-length="1000"><?php echo $this->escape($thread_body); ?></textarea>
                                <label for="threadtextarea">内容</label>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="action" value="update" class="modal-action modal-close waves-effect waves-green btn-flat ">更新</button>
                        <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat ">キャンセル</a>
                    </div>
                </form>
            </div>
            <!-- Modal Thread削除 -->
            <div id="modalRemoveThread" class="modal modal-fixed-footer">
                <form
                    id="modalRemoveFrom"
                    action="#"
                    method="post">
                    <div class="modal-content">
                        <h4>コメントの削除</h4>
                        <p>以下のコメントを削除します。問題ない場合は削除を押してください。</p>
                        <div name="confirm_thread_body"></div>
                        <input type="hidden" name="_token"
                        value="<?php echo $this->escape($_token); ?>" />
                        <input type="hidden" name="_thread"
                        value="" />
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="action" value="remove" class="modal-action modal-close waves-effect waves-green btn-flat ">削除</button>
                        <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat ">キャンセル</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>