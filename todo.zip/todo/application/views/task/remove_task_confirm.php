<?php $this->setLayoutVar('title', '編集-' . $task['task_name']);?>
<?php $this->setLayoutVar('breadcrumbs', array(array(
'url'=> $base_url . '/prj/' . $this->escape($project['project_id'] . '/tasks' ),
'title'=>$this->escape($project['project_name'])
),array(
'url'=> $base_url . '/prj/' . $this->escape($project['project_id'] . '/tasks/' . $task['task_id'] ),
'title'=>$this->escape($task['task_name'])
)));?>
<?php if(isset($errors) && count($errors)>0): ?>
<?php $this->setLayoutVar('errors', $errors);?>
<?php endif;?>

<div class="col s12 ">
    <div id="edit_task" class="section">
        <?php echo $this->render('task/confirm_body',array(
        'title' => 'タスクの削除',
        'summary' => '以下のタスクを削除します。本当に問題ないですか？',
        'task_title' => $task_title,
        'task_summary' => $task_summary,
        'category_name' => $category_name,
        'schedule' => '',
        'handle_user_name' => '',
        'isExtraForm' => false
        )); ?>
        <div id="confirm_panel">
            <form name="confirm_form" action="<?php echo $base_url; ?>/prj/<?php echo $this->escape($project['project_id']); ?>/tasks/<?php echo $this->escape($task['task_id']); ?>/removetask" method="post">
                <input type="hidden" name="_token"
                value="<?php echo $this->escape($_token); ?>" />
                <button type="submit" class="btn-large right" id="submit">削除</button>
                <button type="submit" class="btn-large" onclick="confirm_form.action='<?php echo $base_url; ?>/prj/<?php echo $this->escape($project['project_id']); ?>/tasks/<?php echo $this->escape($task['task_id']); ?>/edit';return true;">戻る</button>
            </form>
        </div>
    </div>
</div>