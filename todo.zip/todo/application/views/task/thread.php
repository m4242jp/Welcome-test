<div class="thread_content margin-bottom20">
    <div class="thread_main keep-all">
        <?php
            $thread_create_date = $this->escapeDate($thread['create_date'],'Y-m-d H:i');
            $thread_update_date = $this->escapeDate($thread['update_date'],'Y-m-d H:i');
        ?>
        <span class=""><?php echo $this->escape($thread['creater_show_name']); ?></span>
        <span class="light-blue-text darken-1"><?php echo $thread_create_date ?></span>
        <?php if($thread_create_date !== $thread_update_date): ?>
            <span class="grey-text darken-1 " style="font-size: 80%; ">更新：<?php echo $thread_update_date ?></span>
        <?php endif; ?>
        <?php if(!$thread['system'] && $thread['mycreate']): ?>
        &nbsp;<span class="">
                <a data-target="modalEditableThread" href="#"
                    data-url="<?php echo $base_url; ?>/prj/<?php echo $this->escape($project_id); ?>/tasks/<?php echo $this->escape($task_id); ?>/changethread"
                    data-id="<?php echo $this->escape($thread['thread_id']); ?>"
                    data-thread="<?php echo $this->escape($thread['thread_body']); ?>"
                    >編集</a>&nbsp;&nbsp;
                <a data-target="modalRemoveThread" href="#"
                    data-url="<?php echo $base_url; ?>/prj/<?php echo $this->escape($project_id); ?>/tasks/<?php echo $this->escape($task_id); ?>/changethread"
                    data-id="<?php echo $this->escape($thread['thread_id']); ?>"
                    data-thread="<?php echo nl2br($this->escape($thread['thread_body'])); ?>"
            >削除</a></span>
        <?php endif; ?>
    </div>
    <div class="readmore_min">
         <span class="break">
                <?php echo nl2br($this->escape($thread['thread_body']),true); ?>
        </span>
    </div>

</div>