<div class="toolbar-content max-width card-panel  valign-wrapper">
    <h1 class="page-title truncate"><strong><?php echo $this->escape($title); ?></strong></h1>
</div>
<div class="toolbar-content max-width margin-bottom-20">
    <p><?php echo $this->escape($summary); ?></p>
</div>
<div class="max-width card-panel">
    <p>タスクタイトル</p>
    <p class="margin-bottom-20"><?php echo $this->escape($task_title); ?></p>
    <p class="divider"></p>
    <p>内容</p>
    <p class="break margin-bottom-20"><?php echo nl2br($this->escape($task_summary)); ?></p>
    <p class="divider"></p>
    <p>分類</p>
    <p class="margin-bottom-20"><?php echo $this->escape($category_name); ?></p>
    <?php if($isExtraForm): ?>
    <p class="divider"></p>
    <p>優先度</p>
    <p class="margin-bottom-20"><?php echo $this->escape($priority_name); ?></p>
    <p class="divider"></p>
    <p>終了予定日</p>
    <p class="margin-bottom-20"><?php echo $this->escapeDate($schedule); ?></p>
    <p class="divider"></p>
    <p>担当</p>
    <p><?php echo $this->escape($handle_user_name); ?></p>
    <?php endif; ?>
</div>