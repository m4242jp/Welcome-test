<?php $this->setLayoutVar('title', '新しいタスクの作成');?>
<?php $this->setLayoutVar('breadcrumbs', array(array(
'url'=> $base_url . '/prj/' . $this->escape($project['project_id'] . '/tasks' ),
'title'=>$this->escape($project['project_name'])
)));?>

<div class="col s12 ">
    <div id="new_project" class="section">

        <?php echo $this->render('task/confirm_body',array(
        'title' => '新しいタスクの作成',
        'summary' => '以下の内容で作成します。問題ないですか？',
        'task_title' => $task_title,
        'task_summary' => $task_summary,
        'schedule' => $schedule,
        'handle_user_name' => $handle_user_name,
        'category_name' => $category_name,
        'priority_name' => $priority_name,
        'isExtraForm' => true,
        )); ?>
        <div id="confirm_panel">
            <form name="confirm_form" action="<?php echo $base_url; ?>/prj/<?php echo $this->escape($project['project_id']); ?>/newtask/up" method="post">
                <input type="hidden" name="_token"
                value="<?php echo $this->escape($_token); ?>" />
                <input type="hidden" name="task_title" value="<?php echo $this->escape($task_title); ?>" />
                <input type="hidden"  name="task_summary" value="<?php echo $this->escape($task_summary); ?>" />
                <input type="hidden"  name="schedule" value="<?php echo $this->escape($schedule); ?>" />
                <input type="hidden"  name="handle_user_id" value="<?php echo $this->escape($handle_user_id); ?>" />
                <input type="hidden"  name="category_id" value="<?php echo $this->escape($category_id); ?>" />
                <input type="hidden"  name="priority_id" value="<?php echo $this->escape($priority_id); ?>" />
                <button type="submit" class="btn-large right" id="submit">作成</button>
                <button type="submit" class="btn-large" onclick="confirm_form.action='<?php echo $base_url; ?>/prj/<?php echo $this->escape($project['project_id']); ?>/newtask';return true;">戻る</button>
             </form>
        </div>
    </div>
</div>