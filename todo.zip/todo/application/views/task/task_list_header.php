<div>
    <div class="row no-margin-bottom valign-wrapper">
        <div class="col s12 m8 l8 no-padding">
            <span class="valign-wrapper right">
                <?php if ($pager['prev_page_no'] || $pager['next_page_no']): ?>

                <span class="text-size-sub"><?php echo $this->escape($pager['record_count']); ?>件中&nbsp;<?php echo $this->escape($pager['start_no']); ?>-<?php echo $this->escape($pager['end_no']); ?>&nbsp;</span>
                <span>
                    <?php if ($pager['prev_page_no']>0): ?>
                    <a class="waves-effect waves-light btn btn-mini" href="<?php echo $this->escape($page_url); ?><?php echo $this->escape($get_param_before); ?><?php echo $this->escape($param_name); ?>=<?php echo $this->escape($pager['prev_page_no']); ?><?php echo $this->escape($get_param_after); ?>">
                    <i class="material-icons">chevron_left</i></a>
                    <?php else: ?>
                    <a class="disabled btn btn-mini"><i class="material-icons">chevron_left</i></a>
                    <?php endif; ?>
                    <?php if ($pager['next_page_no']>0): ?>
                    <a class="waves-effect waves-light btn btn-mini" href="<?php echo $this->escape($page_url); ?><?php echo $this->escape($get_param_before); ?><?php echo $this->escape($param_name); ?>=<?php echo $this->escape($pager['next_page_no']); ?><?php echo $this->escape($get_param_after); ?>">
                    <i class="material-icons">chevron_right</i>
                    </a>
                    <?php else: ?>
                    <a class="disabled btn btn-mini"><i class="material-icons">chevron_right</i></a>
                    <?php endif; ?>

                </span>

                <?php else: ?>
                <?php if ($pager['record_count'] > 0): ?>
                <span class="text-size-sub"><?php echo $this->escape($pager['record_count']); ?>件&nbsp;</span>
                <?php endif; ?>

                <?php endif; ?>
            </span>
        </div>
    </div>
</div>