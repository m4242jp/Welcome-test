<div class="input-field col s12 margin-bottom20">
    <input type="text" id="task_title" name="task_title" value="<?php echo $this->escape($task_title); ?>" class="validate"  data-length="45"/>
    <label for="task_title">タスクタイトル 最大45文字（必須）</label>
</div>
<div class="input-field col s12">
    <textarea id="task_summary" name="task_summary" class="materialize-textarea character_counter validate" data-length="5000" rows="10"><?php echo $this->escape($task_summary); ?></textarea>
    <label for="task_summary">内容 最大5000文字（必須）</label>
</div>
<div class="col s12 margin-bottom-8">
    <label class="col s12">分類（必須）</label>
    <div class="input-field inline">
        <select name="category_id">
            <?php foreach ($categorys as $category): ?>
            <option value="<?php echo $this->escape($category['category_id']); ?>"
                <?php echo $this->escape($category['category_id'] === $category_id ? 'selected="selected"' : '' ); ?>
            ><?php echo $this->escape($category['category_name']); ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</div>
<?php if($isExtraForm): ?>
<div class="col s12 margin-bottom-8">
    <label class="col s12">優先度（任意）</label>
    <div class="input-field inline">
        <select name="priority_id">
            <?php foreach ($prioritys as $priority): ?>
            <option value="<?php echo $this->escape($priority['priority_id']); ?>"
                <?php echo $this->escape($priority['priority_id'] === $priority_id ? 'selected="selected"' : '' ); ?>
            ><?php echo $this->escape($priority['priority_name']); ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</div>
<div class="col s12 margin-bottom-8">
    <label class="col s12">終了予定日（任意）</label>
    <div class="input-field inline">
        <input id="schedule" type="date" class="datepicker" name="schedule"  value="<?php echo $this->escapeDate($schedule,'Y-m-d',''); ?>">
    </div>
</div>
<div class="col s12 margin-bottom-8">
    <label class="col s12">担当者（任意）</label>
    <div class="input-field inline">
        <select name="handle_user_id">
            <option value="">未設定</option>
            <?php foreach ($join_users as $join_user): ?>
            <option value="<?php echo $this->escape($join_user['user_id']); ?>"
                <?php echo $this->escape($join_user['user_id'] === $handle_user_id ? 'selected="selected"' : '' ); ?>
            ><?php echo $this->escape($join_user['show_name']); ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</div>
<?php endif; ?>