<?php $this->setLayoutVar('title', 'ログイン') ?>
<div class="col s12">
    <div class="section no-pad-bot">
            <div class="container">
                <h1 class="header center white-text padding-top-32 brand-logo-font"><strong>MINI TODO</strong></h1>
                <div class="card-panel login-container" >
                <h5 class="center light">ログイン</h5>
                <form action="<?php echo $base_url; ?>/account/login/auth" method="post" class="padding-horizontal-20">
                    <input type="hidden" name="_token" value="<?php echo $this->escape($_token); ?>" />
    <?php if (isset($errors) && count($errors) > 0): ?>
                    <div class="row center">
                        <ul class="error_list">
                            <?php foreach ($errors as $error): ?>
                            <li class="label red-text"><?php echo $this->escape($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
    <?php endif; ?>
                    <div class="row center">
                        <div class="input-field ">
                            <input id="user_name" name="user_name" type="text" class="validate" value="<?php echo $this->escape($user_name); ?>" />
                            <label for="user_name">ユーザID</label>
                        </div>
                    </div>
                    <div class="row center">
                        <div class="input-field ">
                            <input id="password" type="password"  name="password" class="validate"  value="<?php echo $this->escape($password); ?>"/>
                            <label for="password">パスワード</label>
                        </div>
                    </div>
                    <div class="row center">
                        <button type="submit" value="login" class="btn waves-effect waves-light light-blue">ログイン</button>
                    </div>
                </form>
            </div>
            </div>
    </div>
</div>