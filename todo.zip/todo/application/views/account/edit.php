<?php $this->setLayoutVar('title', 'アカウント編集')?>
<?php $this->setLayoutVar('breadcrumbs', array(array(
'url'=> $base_url . '/account',
'title'=>'アカウント'
)));?>
<?php if(isset($errors) && count($errors)>0): ?>
<?php $this->setLayoutVar('errors', $errors);?>
<?php endif;?>
<div class="col s12 ">
    <div id="content" class="section">
        <div class="toolbar-content max-width card-panel  valign-wrapper">
            <h1 class="page-title"><strong>アカウント編集</strong></h1>
        </div>
        <div class="margin-bottom-20">
            <form action="<?php echo $base_url; ?>/account/edit/post" method="post">
                <input type="hidden" name="_token" value="<?php echo $this->escape($_token); ?>" />
                <div class="col s12">
                    <div class="input-field margin-bottom20 inline">
                        <input type="text" id="show_name" name="show_name" value="<?php echo $this->escape($show_name); ?>" data-length="20" />
                        <label for="show_name">ユーザ名</label>
                    </div>
                </div>
                <div class="col s12 ">
                    <p>パスワードを変更しない場合は空白ママにしてください。</p>
                </div>
                <div class="col s12">
                    <div class="input-field margin-bottom20 inline">
                        <input type="password" id="password" name="password" value="" />
                        <label for="password">パスワード</label>
                    </div>
                </div>
                <div class="col s12">
                    <div class="input-field margin-bottom20 inline">
                        <input type="password" id="password_conf" name="password_conf" value="" />
                        <label for="password_conf">パスワード確認用</label>
                    </div>
                </div>
                <button type="submit" class="btn" id="submit">更新</button>
            </form>
        </div>
    </div>
</div>