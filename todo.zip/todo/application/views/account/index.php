<?php $this->setLayoutVar('title', 'アカウント')?>
<div class="col s12 ">
    <div id="content" class="section">
        <div class="toolbar-content max-width card-panel  valign-wrapper">
            <h1 class="page-title"><strong>アカウント情報</strong></h1>
        </div>
        <div class="margin-bottom-20">
            <p class="label">ID</p>
            <p><?php echo $this->escape($user['user_name']); ?></p>
            <p class="label">ユーザ名</p>
            <p><?php echo $this->escape(!is_null($user['show_name']) ? $user['show_name'] : 'ユーザー名が未設定です'); ?></p>
            <p class="label">権限</p>
            <p><?php echo $this->escape($user['authority_name']); ?></p>
            <p><a href="<?php echo $base_url?>/account/edit" class="btn">編集</a></p>
        </div>
    </div>
</div>