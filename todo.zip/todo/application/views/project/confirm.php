<?php $this->setLayoutVar('title', 'プロジェクト作成');?>
<div class="col s12 ">
    <div id="new_project" class="section">
        <input type="hidden" name="_token"
        value="<?php echo $this->escape($_token); ?>" />
        <?php echo $this->render('project/confirm_body',array(
        'title' => '新しいプロジェクトの作成',
        'summary' => '以下の内容で作成します。問題ないですか？',
        'project_name' => $project_name,
        'project_summary' => $project_summary
        )); ?>
        <div id="confirm_panel">
            <form name="confirm_form" action="<?php echo $base_url; ?>/prj/new/post" method="post">
                <input type="hidden" name="_token"
                value="<?php echo $this->escape($_token); ?>" />
                <input type="hidden" name="project_name"
                value="<?php echo $this->escape($project_name); ?>" />
                <input type="hidden" name="project_summary"
                value="<?php echo $this->escape($project_summary); ?>" />
                <button type="submit" class="btn-large right" id="submit">作成</button>
                <button type="submit" class="btn-large" onclick="confirm_form.action='<?php echo $base_url; ?>/prj/new';return true;">戻る</button>
            </form>
        </div>
    </div>
</div>