<div class="input-field col s12 margin-bottom20">
    <input type="text" id="project_name" name="project_name" value="<?php echo $this->escape($project_name); ?>" class="validate"  data-length="30"/>
    <label for="project_name">プロジェクトタイトル 最大30文字（必須）</label>
</div>
<div class="input-field col s12">
    <textarea id="project_summary" name="project_summary" class="materialize-textarea character_counter validate" data-length="2000" rows="10"><?php echo $this->escape($project_summary); ?></textarea>
    <label for="project_summary">概要 最大2000文字（必須）</label>
</div>