<?php $this->setLayoutVar('title', '編集 - ' . $this->escape($project_name_now));?>
<?php $this->setLayoutVar('breadcrumbs', array(array(
'url'=> $base_url . '/prj/' . $this->escape($project_id),
'title'=>$this->escape($project_name_now)
)));?>
<?php if(isset($errors) && count($errors)>0): ?>
<?php $this->setLayoutVar('errors', $errors);?>
<?php endif;?>
<div class="col s12 ">
    <div id="update_project" class="section">
        <div class="toolbar-content max-width card-panel  valign-wrapper margin-bottom20">
            <h1 class="page-title truncate"><strong>プロジェクトの編集</strong></h1>
        </div>
        <form action="<?php echo $base_url; ?>/prj/edit/<?php echo $this->escape($project_id); ?>/confirm/detail" method="post">
            <input type="hidden" name="_token"
            value="<?php echo $this->escape($_token); ?>" />
            <?php echo $this->render('project/project_input',array(
            'project_name' => $project_name,
            'project_summary' => $project_summary
            )); ?>
            <div>
                <button type="submit" name="action" value="update" class="btn-large right">更新</button>
                <button type="submit" name="action" value="remove" class="btn-large">削除</button>
            </div>
        </form>
    </div>
</div>