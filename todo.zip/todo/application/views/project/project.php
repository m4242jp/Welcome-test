<tr  data-url="<?php echo $base_url;?>/prj/<?php echo $this->escape($project['project_id']);?>">
    <td>
        <a href="<?php echo $base_url;?>/prj/<?php echo $this->escape($project['project_id']);?>">
            <?php echo $this->escape($project['project_name']); ?>
        </a>
    </td>
</tr>