<?php $this->setLayoutVar('title', 'ホーム');?>
<?php $this->setLayoutVar('navigations', array(array(
'url'=> $base_url . '/prj/new',
'title'=> '新しいプロジェクト'
)));?>
<?php
$base_page_nation_url = $base_url . '?';
$now_project_page_no = 'pno=' . $this->escape($projects_pager['page_no']);
$now_task_page_no = 'tno=' . $this->escape($tasks_pager['page_no']);
$now_task_sort = 'sort=' . $this->escape($task_sort). '&desc=' . $this->escape($task_desc);
$task_desc_mark = $task_desc ? '<span class="label">&nbsp;▼<span>' : '<span class="label">&nbsp;▲<span>';
?>
<div class="col s12 m12 l9 ">
    <div class="box margin-bottom-8">
        <h1 class="page-title"><strong><b>あなたのタスク</b></strong></h1>
    </div>
    <div id="my_tasks" class="section">
        <?php echo $this->render('task/task_list_header',array(
        'pager' => $tasks_pager,
        'page_url' => $base_page_nation_url,
        'param_name' => 'tno',
        'get_param_before' => strlen($now_project_page_no) ? $now_project_page_no . '&'  :  '',
        'get_param_after' => '&' . $now_task_sort .'#project_tasks'
        )); ?>
        <?php if (count($tasks) > 0): ?>
        <div class="responsive-wrapper">
            <table class="bordered highlight responsive-table-s text-size-sub border-panel">
                <thead>
                    <tr>
                        <th><a class="black-text" href="<?php echo $this->escape($base_page_nation_url); ?><?php echo $this->escape($now_project_page_no . '&' . $now_task_page_no); ?>&<?php echo $this->escape($task_sort_url['category']); ?>#project_tasks">分類<?php echo $task_sort === 'category' ? $task_desc_mark : ''; ?></a></th>
                        <th><a class="black-text" href="<?php echo $this->escape($base_page_nation_url); ?><?php echo $this->escape($now_project_page_no . '&' . $now_task_page_no); ?>&<?php echo $this->escape($task_sort_url['priority']); ?>#project_tasks">優先<?php echo $task_sort === 'priority' ? $task_desc_mark: ''; ?></a></th>
                        <th><a class="black-text" href="<?php echo $this->escape($base_page_nation_url); ?><?php echo $this->escape($now_project_page_no . '&' . $now_task_page_no); ?>&<?php echo $this->escape($task_sort_url['task']); ?>#project_tasks">タスク名<?php echo $task_sort === 'task' ? $task_desc_mark : ''; ?></a></th>
                        <th><a class="black-text" href="<?php echo $this->escape($base_page_nation_url); ?><?php echo $this->escape($now_project_page_no . '&' . $now_task_page_no); ?>&<?php echo $this->escape($task_sort_url['status']); ?>#project_tasks">状態<?php echo $task_sort === 'status' ? $task_desc_mark : ''; ?></a></th>
                        <th><a class="black-text" href="<?php echo $this->escape($base_page_nation_url); ?><?php echo $this->escape($now_project_page_no . '&' . $now_task_page_no); ?>&<?php echo $this->escape($task_sort_url['schedule']); ?>#project_tasks">スケジュール<?php echo $task_sort === 'schedule' ? $task_desc_mark : ''; ?></a></th>
                        <th><a class="black-text" href="<?php echo $this->escape($base_page_nation_url); ?><?php echo $this->escape($now_project_page_no . '&' . $now_task_page_no); ?>&<?php echo $this->escape($task_sort_url['date']); ?>#project_tasks">更新日<?php echo $task_sort === 'date' ? $task_desc_mark : ''; ?></a></th>
                        <th><a class="black-text" href="<?php echo $this->escape($base_page_nation_url); ?><?php echo $this->escape($now_project_page_no . '&' . $now_task_page_no); ?>&<?php echo $this->escape($task_sort_url['project']); ?>#project_tasks">プロジェクト<?php echo $task_sort === 'project' ? $task_desc_mark : ''; ?></a></th>

                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tasks as $task): ?>
                    <?php echo $this->render('task/task',array('task'=>$task, "isShowProjectName" => true)); ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="margin-bottom-20 min-height200">登録されたタスクはありません。</div>
        <?php endif; ?>
    </div>
</div>
<div class="col s12 m12 l3">
    <div class="box margin-bottom-8">
        <h2 class="page-title"><strong><b>あなたのプロジェクト</b></strong></h2>
    </div>
    <div id="projects" class="section">
        <div class="row no-margin-bottom valign-wrapper">
            <div class="col s4 m4  hide-on-large-only ">
                <a class="btn btn-mini primary" href="<?php echo $base_url;?>/prj/new" data-delay="50" data-tooltip="新しいプロジェクト">
                <i class="material-icons">add</i></a></li>
            </div>
            <div class="col s8 m8 l12 right">
            <?php echo $this->render('project/project_list_pager',array(
            'isHome' => false,
            'pager' => $projects_pager,
            'page_url' => $base_page_nation_url,
            'param_name' => 'pno',
            'get_param_before' => '',
            'get_param_after' => '&' . $now_task_page_no . '&' . $now_task_sort .'#projects'
            )); ?>
        </div>
        </div>
        <?php if (count($projects) > 0): ?>
        <div class="responsive-wrapper">
            <table class="bordered highlight responsive-table-s text-size-sub border-panel margin-bottom-6">
                <tbody>
                    <?php foreach ($projects as $project): ?>
                    <?php echo $this->render('project/project',array("project" => $project)); ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="margin-bottom-20 min-height200"><span>参加プロジェクトはありません。</span></div>
        <?php endif; ?>
    </div>
</div>