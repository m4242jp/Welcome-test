<?php $this->setLayoutVar('title', '編集-' . $project_name_now);?>
<?php $this->setLayoutVar('breadcrumbs', array(array(
'url'=> $base_url . '/prj/' . $this->escape($project_id),
'title'=>$this->escape($project_name_now)
)));?>
<div class="col s12 ">
    <div id="update_project" class="section">
        <input type="hidden" name="_token"
        value="<?php echo $this->escape($_token); ?>" />
        <?php echo $this->render('project/confirm_body',array(
        'title' => 'プロジェクトの編集',
        'summary' => '以下の内容で更新します。問題ないですか？',
        'project_name' => $project_name,
        'project_summary' => $project_summary
        )); ?>
        <div id="confirm_panel">
            <form name="confirm_form" action="<?php echo $base_url; ?>/prj/edit/<?php echo $this->escape($project_id); ?>/post/detail" method="post">
                <input type="hidden" name="_token"
                value="<?php echo $this->escape($_token); ?>" />
                <input type="hidden" name="project_name"
                value="<?php echo $this->escape($project_name); ?>" />
                <input type="hidden" name="project_summary"
                value="<?php echo $this->escape($project_summary); ?>" />
                <button type="submit" class="btn-large right" id="submit">更新</button>
                <button type="submit" class="btn-large" onclick="confirm_form.action='<?php echo $base_url; ?>/prj/edit/<?php echo $this->escape($project_id); ?>';return true;">戻る</button>
            </form>
        </div>
    </div>
</div>