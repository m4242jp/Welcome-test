<?php $this->setLayoutVar('title', '削除済タスク') ?>
<?php $this->setLayoutVar('breadcrumbs', array(array(
'url'=> $base_url . '/manage/projects',
'title'=>'プロジェクト一覧'
)));?>
<?php if(isset($errors) && count($errors)>0): ?>
<?php $this->setLayoutVar('errors', $errors);?>
<?php endif;?>
<?php
//あとで削除
$start_count_task =0;
$end_count_task =count($tasks)
?>
<div class="col s12 ">
    <div id="content" class="section">
        <div class="toolbar-content max-width card-panel  valign-wrapper">
            <h1 class="page-title"><strong>削除済タスク</strong></h1>
        </div>
        <?php if($session->isDeveloperLevel()):?>

<div class="col s12 m12 l9 ">
    <div id="my_tasks" class="section">
        <?php echo $this->render('task/task_list_header',array(
        "isHome" => true,
        'count' => count($tasks),
        'start_count' => $start_count_task,
        'end_count' => $end_count_task,
        'isPager' => ($end_count_task - $start_count_task) < count($tasks)
        )); ?>
        <?php if (count($tasks) > 0): ?>
        <div class="responsive-wrapper">
            <table class="bordered highlight responsive-table-s text-size-sub border-panel">
                <thead>
                    <tr>
                        <th>分類</th>
                        <th>タスク名</th>
                        <th>プロジェクト</th>
                        <th>有効化</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tasks as $task): ?>
                    <?php echo $this->render('admin/task',array('task'=>$task)); ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="margin-bottom-20 min-height200">登録されたタスクはありません。</div>
        <?php endif; ?>
    </div>
</div>


        <?php else: ?>
            <div id="not_auth">
                閲覧権限がありません。
            </div>
        <?php endif; ?>
    </div>
</div>