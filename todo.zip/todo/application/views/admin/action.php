<?php if ($type && ($type === 'project' || $type === 'task')): ?>
<?php $this->setLayoutVar('title', '有効化-' . $this->escape($page_title)) ?>
<?php
$breadcrumbs = array();
$breadcrumbs[] =array(
'url'=> $base_url . '/manage/projects',
'title'=>'プロジェクト一覧'
);
if ($type === 'task' && isset($no)):
$breadcrumbs[] = array(
'url'=> $base_url . '/manage/projects/' . $no,
'title'=>'削除済タスク');
endif;
$this->setLayoutVar('breadcrumbs',$breadcrumbs);
?>
<div class="col s12 ">
    <div id="content" class="section">
        <div class="toolbar-content max-width card-panel  valign-wrapper">
            <h1 class="page-title truncate"><strong><?php echo $this->escape($page_title); ?></strong></h1>
        </div>
        <div class="toolbar-content max-width margin-bottom-20">
            <p><?php echo $this->escape($type === 'project' ?
                '以下のプロジェクトを復活させます' :
                '以下のタスクを復活させます'
            ); ?></p>
        </div>
        <div class="max-width card-panel">
            <p>タイトル</p>
            <p><?php echo $this->escape($name); ?></p>
            <p>内容</p>
            <p><?php echo $this->escape($summary); ?></p>
        </div>
        <div id="confirm_panel">
            <form action="<?php echo $base_url; ?>/manage/action/restore/<?php echo $this->escape($type); ?>/<?php echo $this->escape($no); ?><?php echo isset($no2) ? $this->escape('/'. $no2) : ''; ?>" method="post">
                <input type="hidden" name="_token"
                value="<?php echo $this->escape($_token); ?>" />
                <input type="hidden" name="action"
                value="<?php echo $this->escape($action); ?>" />
                <input type="hidden" name="type"
                value="<?php echo $this->escape($type); ?>" />
                <input type="hidden" name="no"
                value="<?php echo $this->escape($no); ?>" />
                <?php if (isset($no2)): ?>
                <input type="hidden" name="no2"
                value="<?php echo $this->escape($no2); ?>" />
                <?php endif; ?>
                <button type="submit" class="btn" id="submit">有効</button>
            </form>
        </div>
    </div>
</div>
<?php else: ?>
<?php $this->setLayoutVar('title', 'エラー') ?>
エラーです。
<?php endif; ?>