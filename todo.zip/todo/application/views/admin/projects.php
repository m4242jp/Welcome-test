<?php $this->setLayoutVar('title', 'プロジェクト一覧') ?>
<?php if(isset($errors) && count($errors)>0): ?>
<?php $this->setLayoutVar('errors', $errors);?>
<?php endif;?>
<div class="col s12 ">
    <div id="content" class="section">
        <div class="toolbar-content max-width card-panel  valign-wrapper">
            <h1 class="page-title"><strong>プロジェクト一覧</strong></h1>
        </div>
        <?php if($session->isAdministratorLevel()):?>
        <?php if (count($projects) > 0): ?>
        <div id="pager_box" class="toolbar-content max-width">
            <div class="col s12">
                <span class="valign-wrapper right">
                    <?php if ($pager['prev_page_no'] || $pager['next_page_no']): ?>
                    <span class="text-size-sub"><?php echo $this->escape($pager['record_count']); ?>件中&nbsp;<?php echo $this->escape($pager['start_no']); ?>-<?php echo $this->escape($pager['end_no']); ?>&nbsp;</span>
                    <span>
                        <?php if ($pager['prev_page_no']>0): ?>
                        <a class="waves-effect waves-light btn btn-mini" href="<?php echo $base_url;?>/manage/projects?p=<?php echo $this->escape($pager['prev_page_no']);?>#pager_box">
                        <i class="material-icons">chevron_left</i></a>
                        <?php else: ?>
                        <a class="disabled btn btn-mini"><i class="material-icons">chevron_left</i></a>
                        <?php endif; ?>
                        <?php if ($pager['next_page_no']>0): ?>
                        <a class="waves-effect waves-light btn btn-mini" href="<?php echo $base_url;?>/manage/projects?p=<?php echo $this->escape($pager['next_page_no']);?>#pager_box">
                            <i class="material-icons">chevron_right</i>
                        </a>
                        <?php else: ?>
                        <a class="disabled btn btn-mini"><i class="material-icons">chevron_right</i></a>
                        <?php endif; ?>
                    </span>
                    <?php else: ?>
                    <span class="text-size-sub"><?php echo $this->escape($pager['record_count']); ?>件&nbsp;</span>
                    <?php endif; ?>
                </span>
            </div>
            <div class="responsive-wrapper">
                <table class="bordered highlight responsive-table-s text-size-sub border-panel">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>プロジェクト名</th>
                            <th>状態</th>
                            <th>編集/削除</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($projects as $project): ?>
                        <?php echo $this->render('admin/project',array('project'=>$project, "isAdmin" => true)); ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="margin-bottom-20 min-height200">登録されたプロジェクトはありません。</div>
            <?php endif; ?>
            <?php else: ?>
            <div id="not_auth">
                閲覧権限がありません。
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>