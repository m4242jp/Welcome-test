<?php if($session->isManagerLevel()):?>
<tr
<?php if(!$project['project_removed']):?>
data-url="<?php echo $base_url;?>/prj/<?php echo $this->escape($project['project_id']);?>"
<?php endif; ?>
>
    <?php if($isAdmin):?>
        <td>
            <a href="<?php echo $base_url;?>/prj/<?php echo $this->escape($project['project_id']);?>">
                <?php echo $this->escape($project['project_id']); ?>
            </a>
        </td>
    <?php endif; ?>
    <td>
        <a href="<?php echo $base_url;?>/prj/<?php echo $this->escape($project['project_id']);?>">
            <?php echo $this->escape($project['project_name']); ?>
        </a>
    </td>
    <?php if($isAdmin):?>
    <?php if($project['project_removed']):?>
    <td>無効</td>
    <td>
        <span><a href="<?php echo $base_url;?>/manage/action/restoration/project/<?php echo $this->escape($project['project_id']);?>">有効化</a></span>
    </td>
    <?php else: ?>
    <td>有効</td>
    <td>
        <span><a href="<?php echo $base_url;?>/prj/edit/<?php echo $this->escape($project['project_id']);?>">編集</a></span>&nbsp;
        <span><a href="<?php echo $base_url;?>/prj/joins/<?php echo $this->escape($project['project_id']);?>">参加者</a></span>&nbsp;
        <span><a href="<?php echo $base_url;?>/manage/projects/<?php echo $this->escape($project['project_id']);?>">削除タスク</a></span>
    </td>
    <?php endif; ?>
    <?php endif; ?>
</tr>
<?php endif; ?>