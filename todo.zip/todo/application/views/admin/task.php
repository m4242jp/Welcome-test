<?php if($session->isDeveloperLevel()):?>
<?php
$category_class='orange white-text';
switch ($task['category_id']){
    case '1':
    $category_class = 'green white-text';
    break;
    case '2':
    $category_class = 'red white-text';
    break;
    case '3':
    $category_class = 'blue white-text';
    break;
}
?>
<tr>
    <td><span class="padding-2 nowrap <?php echo $category_class ?>"><?php echo $this->escape($task['category_name']); ?></span></td>
    <td>
        <a href="<?php echo $base_url;?>/prj/<?php echo $this->escape($task['project_id']);?>/tasks/<?php echo $this->escape($task['task_id']);?>">
            <?php echo $this->escape($task['task_name']); ?>
        </a>
    </td>
    <td>
        <a href="<?php echo $base_url;?>/prj/<?php echo $this->escape($task['project_id']);?>">
            <?php echo $this->escape($task['project_name']); ?>
        </a>
    </td>
    <td>
        <a class="nowrap" href="<?php echo $base_url;?>/manage/action/restoration/task/<?php echo $this->escape($task['project_id']);?>/<?php echo $this->escape($task['task_id']);?>">有効化</a>
    </td>
</tr>
<?php endif; ?>