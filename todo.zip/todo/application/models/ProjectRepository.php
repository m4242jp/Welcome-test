<?php

class ProjectRepository extends DbRepository
{

    public function insert($user_id, $project_name, $project_summary)
    {

        $sql = "
               INSERT INTO project (project_name , project_summary , create_user_id)
               VALUES(:project_name, :project_summary , :user_id)
               ";

        $stmt = $this->execute(
            $sql,
            array(
                ':project_name' => $project_name,
                ':project_summary' => $project_summary,
                ':user_id' => $user_id
            )
        );

        if (!$stmt) {
            return false;
        }
        $new_id = $this->lastInsertId();
        $sql = "
               INSERT INTO account_join_project (project_id , user_id , join_authority_level)
               VALUES(:project_id, :user_id , :join_authority_level)
               ";

        $stmt = $this->execute(
            $sql,
            array(
                ':project_id' => $new_id,
                ':user_id' => $user_id,
                ':join_authority_level' => 1
            )
        );

        return $new_id;
    }

    public function updateProject($project_id, $project_name, $project_summary)
    {

            $sql = '
                   UPDATE project SET project_name = :project_name,
                   project_summary = :project_summary WHERE id = :project_id';

        $stmt = $this->execute(
            $sql,
            array(
                ':project_name' => $project_name,
                ':project_summary' => $project_summary,
                ':project_id' => $project_id
            )
        );
    }

    public function removeProject($project_id)
    {

            $sql = '
                   UPDATE project SET removed = true WHERE id = :project_id';

        $stmt = $this->execute(
            $sql,
            array(
                ':project_id' => $project_id
            )
        );
    }
    public function restoreProject($project_id)
    {

            $sql = '
                   UPDATE project SET removed = false WHERE id = :project_id';

        $stmt = $this->execute(
            $sql,
            array(
                ':project_id' => $project_id
            )
        );
    }

    public function setJoinUsersProject($project_id, $user_ids, $join_authority_level, $keep_user_id, $debug = false)
    {
        $result = array();
        if (!$user_ids || !is_array($user_ids)) {
            $result[] = 'ユーザーを選択してください';
            return $result;
        }
        try {
            //トランザクション開始
            $this->beginTransaction();

            $sql = "
                INSERT INTO account_join_project (project_id , user_id , join_authority_level)
                VALUES(:project_id, :user_id , :join_authority_level) on duplicate key update join_authority_level=:join_authority_level
               ";
            foreach ($user_ids as $user_id) {
                if ($keep_user_id !== $user_id) {
                    $stmt = $this->execute(
                        $sql,
                        array(
                                ':project_id' => $project_id,
                                ':user_id' => $user_id,
                                ':join_authority_level' => $join_authority_level
                        )
                    );
                } else {
                    $result[] = 'プロジェクト作成者は変更できません';
                }
            }

            $this->commit();
            $result[] = '権限の変更をしました';
        } catch (PDOException $e) {
            //トランザクション取り消し（ロールバック）
            $this->rollBack();
            $result[] = $debug ? $e->getMessage() : '予期せぬ不具合により更新に失敗しました';
        }

        return $result;
    }

    public function removeJoinUsersProject($project_id, $user_ids, $keep_user_id, $debug = false)
    {
        $result = array();
        if (!$user_ids || !is_array($user_ids)) {
            $result[] = 'ユーザーを選択してください';
            return $result;
        }
        try {
            //トランザクション開始
            $this->beginTransaction();

            $sql = "
                DELETE FROM account_join_project WHERE project_id = :project_id AND user_id = :user_id
               ";
            foreach ($user_ids as $user_id) {
                if ($keep_user_id !== $user_id) {
                    $stmt = $this->execute(
                        $sql,
                        array(
                                ':project_id' => $project_id,
                                ':user_id' => $user_id,
                        )
                    );
                } else {
                    $result[] = 'プロジェクト作成者は変更できません';
                }
            }

            $this->commit();
            $result[] = '権限の変更をしました';
        } catch (PDOException $e) {
            //トランザクション取り消し（ロールバック）
            $this->rollBack();
            $result[] = $debug ? $e->getMessage() : '予期せぬ不具合により更新に失敗しました';
        }
        return $result;
    }

/**
 * ユーザーが作成したプロジェクト一覧
 * @param  $user_id
 * @return array
 */
    public function fetchAllCreateProjectByUserId($user_id)
    {
        $sql = "SELECT p.id as project_id, p.project_name, p.project_summary,
                 p.create_date, p.update_date FROM project
            WHERE create_user_id = :user_id
            ORDER BY created_date DESC
            ";
            return $this->fetchAll($sql, array(
                ':user_id' => $user_id
            ));
    }

     /**
     * ユーザーが参加しているプロジェクト一覧
     * @param  $user_id
     * @return array
     */
    public function fetchAllJoinProjectByUserId($user_id)
    {
        $sql = "SELECT p.id as project_id, p.project_name, p.project_summary,
                 p.create_date, p.update_date,
                 CASE j.join_authority_level
                    WHEN '1' THEN true
                    ELSE false END as join_manage ,
            u.user_name , u.show_name
            FROM project p, account_join_project j , account u
            WHERE p.removed = false AND j.project_id = p.id AND  j.user_id = u.id AND j.user_id = :user_id
            ORDER BY p.update_date DESC";

        return $this->fetchAll($sql, array(
            ':user_id' => $user_id
        ));
    }

    /**
     * 該当プロジェクトの参加ユーザー一覧
     * @param  $project_id
     * @return array
     */
    public function fetchAllJoinUserByProjectId($project_id)
    {

        $sql = "SELECT u.id as user_id , u.user_name , u.show_name ,
                 CASE j.join_authority_level
                    WHEN '1' THEN true
                    ELSE false END as join_manage
            FROM account_join_project j , account u
            WHERE  j.project_id = :project_id AND  j.user_id = u.id AND u.removed = false
            ORDER BY u.show_name DESC";


        return $this->fetchAll($sql, array(
            ':project_id' => $project_id
        ));
    }

    /**
     * ユーザーがプロジェクトに参加しているかどうか
     * @param  $project_id
     * @return array
     */
    public function isJoinProjectUser($project_id, $user_id)
    {

        $sql = "SELECT j.*
            FROM account_join_project j
            WHERE  j.project_id = :project_id AND  j.user_id = :user_id";


        return $this->fetch($sql, array(
            ':project_id' => $project_id,
            ':user_id' => $user_id
        ));
    }
    /**
     * ユーザーがプロジェクトの管理者かどうか
     * @param  $project_id
     * @return array
     */
    public function isJoinProjectMangeUser($project_id, $user_id)
    {

        $sql = "SELECT j.*
            FROM account_join_project j
            WHERE  j.project_id = :project_id AND  j.user_id = :user_id AND j.join_authority_level = 1";


        return $this->fetch($sql, array(
            ':project_id' => $project_id,
            ':user_id' => $user_id
        ));
    }

/**
     * プロジェクトの取得　削除を検索するなら引数を真に
 * @param  [type] $project_id [description]
 * @param  [type] $removed    [description]
 * @return [type]             [description]
 */
    public function fetchByProjectId($project_id,$removed=false)
    {
       /*$sql = "SELECT p.*
            FROM project p
            WHERE  p.id = :project_id"; */
        $sql = "SELECT p.id as project_id, p.project_name, p.project_summary,
                 p.create_date, p.update_date, u.id as user_id , u.show_name as creater_name, u.removed as user_removed
            FROM project p
            LEFT JOIN account u on p.create_user_id = u.id
            WHERE p.removed = :removed AND p.id = :project_id";

        return $this->fetch($sql, array(
            ':project_id' => $project_id,
            ':removed' => $removed
        ));
    }



    /**
     * 該当プロジェクトに対するユーザーのリスト
     * @return [type] [description]
     */
    public function fetchAllUserByProjectJoin($project_id)
    {
        $sql = 'SELECT u.id as user_id , u.user_name , u.show_name ,
                 CASE j.join_authority_level
                    WHEN 1 THEN true
                    ELSE false END as join_manage,
                 CASE
                    WHEN j.user_id is not null THEN true
                    ELSE false END as joined
            FROM  account u
            left join account_join_project j on j.user_id = u.id AND j.project_id = :project_id
            WHERE u.removed = false
            ORDER BY u.show_name DESC
            ';

        return $this->fetchAll($sql, array(
            ':project_id' => $project_id));
    }
     /**
     * 該当プロジェクトに対する管理者ユーザーのリスト
     * @return [type] [description]
     */
    public function fetchCountManageUserByProjectJoin($project_id)
    {
        $sql = 'SELECT count(u.id) as count
            FROM  account u
            left join account_join_project j on j.user_id = u.id AND j.project_id = :project_id
            WHERE u.removed = false AND j.join_authority_level = 1
            ORDER BY u.show_name DESC
            ';

        return $this->fetch($sql, array(
            ':project_id' => $project_id));
    }


    /**
     *以下から改修したＳＱＬ
     *fetch系はこちらを
     *
     **************************************************************/

//トップ画面
     /**
     * ユーザーの参加プロジェクト数
     * @return [array] [count]
     */
    public function fetchCountJoinAllProjectByUserId($user_id)
    {
        $sql = 'SELECT COUNT(id) as count
                FROM
                project p ,account_join_project j
                where p.id = j.project_id AND j.user_id = :user_id AND p.removed = false';

        return $this->fetch($sql, array(
            ':user_id' => $user_id
            ));
    }

     /**
     * ユーザーが参加しているプロジェクト一覧
     * @param  $user_id
     * @return array
     */
    public function fetchAllJoinAllProjectsByUserId($user_id,$offset=0,$limit=25)
    {
        $sql = 'SELECT p.id as project_id, p.project_name,
                 p.create_date, p.update_date
                FROM
                (SELECT fp.id
                FROM
                project fp,account_join_project j
                where fp.id = j.project_id AND j.user_id = :user_id )
                 as p2 , project p
                where p2.id = p.id AND p.removed = false
                ORDER BY p.project_name ASC LIMIT :offset , :offset_limit ';

        $stmt = $this->con->prepare($sql);
        $stmt->bindValue(':user_id', $user_id);
        $stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
        $stmt->bindValue(':offset_limit', (int)$limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }



//Admin画面向け***************************************************
    //プロジェクト一覧管理用
     /**
     * プロジェクトの全件
     * @return [array] [count]
     */
    public function fetchCountAllProject()
    {
        $sql = 'SELECT COUNT(id) as count FROM project';

        return $this->fetch($sql, array());
    }

    /**
     * プロジェクトの全件
     * @param  integer $offset [description]
     * @param  integer $limit [description]
     * @return [type]         [description]
     */
        public function fetchAllProjects($offset=1,$limit=50)
    {
            $sql = "SELECT p.id as project_id, p.project_name, p.project_summary,
                 p.create_date, p.update_date, p.removed as project_removed
            FROM project p
            WHERE id BETWEEN :offset AND :offset_limit
            ORDER BY p.id ASC";
            //ORDER BY p.update_date DESC";

        return $this->fetchAll($sql, array(
            ':offset' => $offset,
            ':offset_limit' => $limit
            ));
    }
}
