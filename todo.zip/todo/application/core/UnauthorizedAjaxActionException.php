<?php

class UnauthorizedAjaxActionException extends Exception
{
}