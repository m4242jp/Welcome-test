<?php

class UnauthorizedActionException extends Exception
{
}