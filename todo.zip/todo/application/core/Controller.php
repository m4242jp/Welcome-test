<?php

abstract class Controller
{

    protected $controller_name;

    protected $action_name;

    protected $application;

    protected $request;

    protected $respons;

    protected $session;

    protected $db_manager;

    protected $auth_actions = array();

    protected $auth_ajax_actions = array();


    public function __construct($application)
    {
        // クラス名の後ろのContoller(10文字分)を取り除き、
        // strtolowerで小文字変換（ルーティングでは小文字でおこなうため）
        $this->controller_name = strtolower(substr(get_class($this), 0, - 10));

        $this->application = $application;
        $this->request = $application->getRequest();
        $this->respons = $application->getResponse();
        $this->session = $application->getSession();
        $this->db_manager = $application->getDbManager();
    }

    public function run($action, $params = array())
    {
        $this->action_name = $action;

        // Actionメソッドがクラスに設定されているか
        $action_method = $action . 'Action';
        if (! method_exists($this, $action_method)) {
            $this->forward404();
        }

        // ログインが必要な画面、かつログイン状態の確認。必要でログインしていなければthorw
        /*
       if ($this->needsAuthentication($action) && ! $this->session->isAuthAndVerification()) {
            if ($this->session->isAuthenticated() && ! $this->session->isVerification()) {
                throw new InvalidUserAccessActionException();
            }
            throw new UnauthorizedActionException();
        }
        */
        if (($this->needsAuthentication($action) || $this->needsAjaxAuthentication($action))
         && ! $this->session->isAuthAndVerification()) {
            if ($this->session->isAuthenticated() && ! $this->session->isVerification()) {
                if (! $this->needsAjaxAuthentication($action)) {
                    throw new InvalidUserAccessActionException();
                } else {
                    throw new UnauthorizedAjaxActionException();
                }
            }
            if (! $this->needsAjaxAuthentication($action)) {
                  throw new UnauthorizedActionException();
            } else {
                throw new UnauthorizedAjaxActionException();
            }
        }

        $content = $this->$action_method($params);
        return $content;
    }

    public function needsAuthentication($action)
    {
        if ($this->auth_actions === true ||
             (is_array($this->auth_actions) && in_array($action, $this->auth_actions))) {
            return true;
        }
        return false;
    }
    public function needsAjaxAuthentication($action)
    {
        if ($this->auth_ajax_actions === true ||
             (is_array($this->auth_ajax_actions) && in_array($action, $this->auth_ajax_actions))) {
            return true;
        }
        return false;
    }

    public function render($variables = array(), $template = null, $layout = 'base')//'layout')
    {


        $defaults = array(
            'request' => $this->request,
            'base_url' => $this->request->getBaseUrl(),
            'session' => $this->session,
            'toasts' => $this->session->getToasts()
        );

        $view = new View($this->application->getViewDir(), $defaults);

        if (is_null($template)) {
            $template = $this->action_name;
        }

        // viewファイルのパス
        $path = $this->controller_name . "/" . $template;
        return $view->render($path, $variables, $layout);
    }

    public function forward404()
    {
        throw new HttpNotFoundException(
            'Forwarded 404 page from ' . $this->controller_name . '/' . $this->action_name
        );
    }

    public function redirect($url)
    {
        if (! preg_match('#https?://#', $url)) {
            $protocol = $this->request->isSsl() ? 'https://' : 'http://';
            $host = $this->request->getHost();
            $base_url = $this->request->getBaseUrl();

            $url = $protocol . $host . $base_url . $url;
        }

        $this->respons->setStatusCode(302, 'Found');
        $this->respons->setHttpHeader('Location', $url);
    }

    public function generateCsrfToken($form_name)
    {
        $key = 'csrf_tokens/' . $form_name;
        $tokens = $this->session->get($key, array());
        if (count($tokens) >= 10) {
            array_shift($tokens);
        }
        //$token = sha1($form_name . session_id() . microtime());
        $token = sha1($form_name . session_id() . uniqid(rand(), true));

        $tokens[] = $token;

        $this->session->set($key, $tokens);

        return $token;
    }

    public function checkCsrfToken($form_name, $token)
    {
        $key = 'csrf_tokens/' . $form_name;
        $tokens = $this->session->get($key, array());

        if (false !== ($pos = array_search($token, $tokens, true))) {
            unset($tokens[$pos]);
            $this->session->set($key, $tokens);

            return true;
        }

        return false;
    }


}
