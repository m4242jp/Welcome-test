<?php

class InvalidUserAccessActionException extends Exception
{
}