<?php

class Response
{

    protected $content;

    protected $status_code = 200;

    protected $status_text = 'OK';

    protected $http_header = array();

    public function send()
    {
        header('HTTP/1.1 ' . $this->status_code . ' ' . $this->status_text);
        foreach ($this->http_header as $name => $val) {
            header($name . ': ' . $val);
        }
        
        echo $this->content;
    }

    public function setContent($content)
    {
        $this->content = $content;
    }

    public function setStatusCode($status_code, $status_text = '')
    {
        $this->status_code = $status_code;
        $this->status_text = $status_text;
    }

    public function setHttpHeader($name, $val)
    {
        $this->http_header[$name] = $val;
    }
}