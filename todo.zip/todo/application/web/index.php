<?php
require '../bootstrap.php';
require '../TodoApplication.php';

$app = new TodoApplication(false);
$app->run();