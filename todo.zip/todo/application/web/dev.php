<?php
require '../bootstrap.php';
require '../TodoApplication.php';

$app = new TodoApplication(true);
$app->run();