<?php

class Env
{

    const PROJECT_PAGE_LIMIT = 25;
    const TASK_PAGE_LIMIT = 50;

    const ADMIN_PROJECT_PAGE_LIMIT = 50;

    const TASK_PAGE_SORT_TYPE = array(
        'project_name' => 'project',
          'handle_name' => 'handle',
          'category_id' => 'category',
            'task_name' => 'task',
          'schedule' => 'schedule',
          'update_date' => 'date',
          'status_id' => 'status',
         'priority_id' => 'priority'
        );
}
