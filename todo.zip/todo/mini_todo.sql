-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 2017 年 8 朁E06 日 20:10
-- サーバのバージョン： 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mini_todo`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`id` int(11) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `show_name` varchar(40) DEFAULT NULL,
  `authority_level` int(11) NOT NULL DEFAULT '1',
  `removed` tinyint(1) NOT NULL DEFAULT '0',
  `create_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_date` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `account_authority`
--

CREATE TABLE IF NOT EXISTS `account_authority` (
  `authority_level` int(11) NOT NULL,
  `authority_name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `account_join_authority`
--

CREATE TABLE IF NOT EXISTS `account_join_authority` (
  `authority_level` int(11) NOT NULL,
  `authority_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `account_join_project`
--

CREATE TABLE IF NOT EXISTS `account_join_project` (
  `user_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `join_authority_level` int(11) NOT NULL DEFAULT '5',
  `create_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `project`
--

CREATE TABLE IF NOT EXISTS `project` (
`id` int(11) NOT NULL,
  `project_name` varchar(80) NOT NULL,
  `project_summary` text NOT NULL,
  `create_user_id` int(11) NOT NULL,
  `removed` tinyint(1) NOT NULL DEFAULT '0',
  `create_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=1000015 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `project_task`
--

CREATE TABLE IF NOT EXISTS `project_task` (
`id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `task_name` varchar(80) NOT NULL,
  `task_summary` text NOT NULL,
  `create_user_id` int(11) NOT NULL,
  `handle_user_id` int(11) DEFAULT NULL,
  `category_id` int(11) NOT NULL DEFAULT '10',
  `priority_id` int(11) NOT NULL DEFAULT '10',
  `status_id` int(11) NOT NULL DEFAULT '10',
  `schedule` datetime DEFAULT NULL,
  `removed` tinyint(1) NOT NULL DEFAULT '0',
  `create_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=2000049 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `project_task_category`
--

CREATE TABLE IF NOT EXISTS `project_task_category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `project_task_priority`
--

CREATE TABLE IF NOT EXISTS `project_task_priority` (
  `priority_id` int(11) NOT NULL,
  `priority_name` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `project_task_status`
--

CREATE TABLE IF NOT EXISTS `project_task_status` (
  `status_id` int(11) NOT NULL,
  `status_name` varchar(12) NOT NULL,
  `create_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='タスクのステイタス用';

-- --------------------------------------------------------

--
-- テーブルの構造 `project_task_thread`
--

CREATE TABLE IF NOT EXISTS `project_task_thread` (
`id` int(11) NOT NULL,
  `task_id` int(11) NOT NULL,
  `thread_body` text NOT NULL,
  `create_user_id` int(11) NOT NULL,
  `system` tinyint(1) NOT NULL DEFAULT '0',
  `create_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `tmp`
--

CREATE TABLE IF NOT EXISTS `tmp` (
`id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `text` varchar(80) NOT NULL,
  `sample_id` int(11) NOT NULL DEFAULT '6',
  `sample_handle` int(11) NOT NULL DEFAULT '3'
) ENGINE=InnoDB AUTO_INCREMENT=1000011 DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `user_name_index` (`user_name`);

--
-- Indexes for table `account_authority`
--
ALTER TABLE `account_authority`
 ADD PRIMARY KEY (`authority_level`), ADD UNIQUE KEY `authority_level` (`authority_level`);

--
-- Indexes for table `account_join_authority`
--
ALTER TABLE `account_join_authority`
 ADD PRIMARY KEY (`authority_level`);

--
-- Indexes for table `account_join_project`
--
ALTER TABLE `account_join_project`
 ADD PRIMARY KEY (`user_id`,`project_id`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
 ADD PRIMARY KEY (`id`), ADD KEY `index_updated_at_and_id` (`update_date`,`id`);

--
-- Indexes for table `project_task`
--
ALTER TABLE `project_task`
 ADD PRIMARY KEY (`id`), ADD KEY `index_status_id` (`status_id`), ADD KEY `index_handle_user_id` (`handle_user_id`), ADD KEY `index_project_id` (`project_id`);

--
-- Indexes for table `project_task_category`
--
ALTER TABLE `project_task_category`
 ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `project_task_priority`
--
ALTER TABLE `project_task_priority`
 ADD PRIMARY KEY (`priority_id`);

--
-- Indexes for table `project_task_status`
--
ALTER TABLE `project_task_status`
 ADD PRIMARY KEY (`status_id`);

--
-- Indexes for table `project_task_thread`
--
ALTER TABLE `project_task_thread`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tmp`
--
ALTER TABLE `tmp`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `project`
--
ALTER TABLE `project`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1000015;
--
-- AUTO_INCREMENT for table `project_task`
--
ALTER TABLE `project_task`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2000049;
--
-- AUTO_INCREMENT for table `project_task_thread`
--
ALTER TABLE `project_task_thread`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=159;
--
-- AUTO_INCREMENT for table `tmp`
--
ALTER TABLE `tmp`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1000011;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
