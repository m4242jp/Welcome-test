<?php
session_start();

$uniq = uniqid();
$_SESSION['hash'] = $uniq;
$url = 'qa.xml';
$xml =  simplexml_load_file($url);
//$xml_ary = json_decode(json_encode($xml), true);
//var_dump($xml);
$data = get_object_vars($xml->quest);
//$data = json_decode(json_encode($xml->quest), true);
//var_dump($data);
//var_dump($xml_ary);
//
    function create_form_item($datas){
        //var_dump($datas);
        $name = $datas->attributes()->name;
        $type = $datas->attributes()->type;
        $label = $datas->label;
        //var_dump($datas);
        if ('radio' == $type) {
            $forms = nl2br($label) . '<br />' ;
            $first = true;
            foreach ($datas->datas->data as $v) {
                $attr = $v->attributes();
                $value = $attr->value;
                if($first){
                    $forms .= '<input type="radio" name="' . $name . '" value="' . $value . '" checked/>' . $v . '<br />';
                    $first = false;
                }else{
                    $forms .= '<input type="radio" name="' . $name . '" value="' . $value . '" />' . $v . '<br />';
                }
            }
            return $forms;

        } else if ('select' == $type) {
            $forms = nl2br($label) . '<br />' ;
            $forms .= '<select name="' . $name . '">';
            foreach ($datas->datas->data as $v) {
                $attr = $v->attributes();
                $value = $attr->value;
                $forms .= '<option value="' . $value . '">' . $v . '</option><br />';
            }
            $forms .= '</select>';
            return $forms;
        } else if ('textarea' == $type) {
            $placeholder = $datas->placeholder;
            $forms = nl2br($label) . '<br />' ;
            $forms .= '<textarea name="' . $name . '" cols="50" rows="5" placeholder="' . $placeholder . '"></textarea>';
            return $forms;
        }
        return '';
    }
?>

<div style="margin: 8px;">
    <p><?php echo $xml->title; ?></p>
    <p><?php echo nl2br($xml->discription); ?></p>

<hr />
    <?php if(isset($xml->ss)): ?>
    <p><?php echo $xml->ss; ?></p>
    <?php endif; ?>

    <form action="save_xml.php" method="post">
        <?php if(!$data === false): ?>
            <?php foreach($data['item'] as $val): ?>

                <?php //var_dump($val); ?>
                <div style="padding-top:8px; padding-bottom:8px;">
                <?php echo create_form_item( $val); ?>
                </div>
                <?php //echo $val->attributes()->type . "<br />===============<br />"; ?>

            <?php endforeach;?>
        <?php endif; ?>
        <input type="hidden" name="hash" value="<?php echo $uniq; ?>" />
        <input type="hidden" name="xml_path" value="qa.xml" />
        <button type="submit">送信</button>
    </form>
</div>
