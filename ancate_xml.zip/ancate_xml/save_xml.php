<?php

    session_start();
    if(!isset($_SESSION['hash']) || !isset($_POST['hash']) ){
        echo '不正アクセス';
        return;
    }else if ($_SESSION['hash'] != $_POST['hash']) {
        echo '連続禁止';
        return;
    }
    $uniq = uniqid();
    $_SESSION['hash'] = $uniq;
    $xml_path = $_POST['xml_path'];
    var_dump( $xml_path);
    unset($_POST['xml_path']);

    $xml =  simplexml_load_file($xml_path);
    $data = get_object_vars($xml->quest);
    $save_array = array();
    if(!$data === false){
        foreach($data['item'] as $val){
            $name = $val->attributes()->name;
            array_push($save_array,(string)$name);
        }
    }
    var_dump($save_array);

    $csv_array = array();
    foreach ($save_array as $value) {
       array_push($csv_array,isset($_POST[$value]) ? $_POST[$value] : "");
    }
    var_dump($csv_array);

    $file = 'anser.csv';
    if(!file_exists($file)) {
        $myfile = fopen($file, "a") or die("Unable to open file!");
        foreach($save_array as $value){
           $content = "{$value}, ";
           fwrite($myfile, $content);
        }
        fwrite($myfile, "\n");
        fclose($myfile);
    }
    $myfile = fopen($file, "a") or die("Unable to open file!");
    foreach($csv_array as $value){
       $content = "{$value}, ";
       fwrite($myfile, $content);
    }
    fwrite($myfile, "\n");
    fclose($myfile)

?>

ありがとん