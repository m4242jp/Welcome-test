package com.common.excel;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;

public class CellWrapper {
    public static Object convertValue(Cell cell){
        if(cell == null) return null;
        switch (cell.getCellTypeEnum()) {
            case  BOOLEAN:
                return cell.getBooleanCellValue();
            case NUMERIC:
                return DateUtil.isCellDateFormatted(cell) ? cell.getDateCellValue() : cell.getNumericCellValue();
            case STRING:
                return cell.getStringCellValue();
            case FORMULA:
                return convertFormulaValue(cell);
            case BLANK:
                return "";
            default:
                    break;
        }
        return null;
    }
    private static Object convertFormulaValue(Cell cell){
        if(cell == null) return null;
        switch (cell.getCachedFormulaResultTypeEnum()) {
            case  BOOLEAN:
                return cell.getBooleanCellValue();
            case NUMERIC:
                return DateUtil.isCellDateFormatted(cell) ? cell.getDateCellValue() : cell.getNumericCellValue();
            case STRING:
                return cell.getStringCellValue();
            case ERROR:
                return "error";
            default:
                break;
        }
        return null;
    }
}
