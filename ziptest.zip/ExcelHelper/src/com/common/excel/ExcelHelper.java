package com.common.excel;

import java.awt.Point;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ExcelHelper {

   private Workbook workbook;
   private String workbookPath;
   private Sheet worksheet;

   public ExcelHelper(){
   }

   /**
    * @param path
    * @FileNotFoundException 誰かが使ってる
    * @throws EncryptedDocumentException パスワードがかかったファイル
    * @throws InvalidFormatException
    * @throws IOException ファイルがないとか壊れてるとか
    */
   public ExcelHelper(String path) throws FileNotFoundException , InvalidFormatException , IOException{
       init(new File(path));
   }

   /**
    *
    * @param file
    * @FileNotFoundException 誰かが使ってる
    * @throws EncryptedDocumentException パスワードがかかったファイル
    * @throws InvalidFormatException 誰かが使ってる
    * @throws IOException ファイルがないとか壊れてるとか
    */
   public ExcelHelper(File file) throws FileNotFoundException , EncryptedDocumentException , InvalidFormatException , IOException{
       init(file);
   }

   public ExcelHelper(String path, String sheetName) throws FileNotFoundException , EncryptedDocumentException , InvalidFormatException , IOException{
      init(new File(path), sheetName);
   }


   public ExcelHelper(File file, String sheetName) throws FileNotFoundException , EncryptedDocumentException , InvalidFormatException , IOException{
       init(file, sheetName);
   }

   public ExcelHelper(String path, int sheetIndex) throws FileNotFoundException , EncryptedDocumentException , InvalidFormatException , IOException{
      init(new File(path), sheetIndex);
   }


   public ExcelHelper(File file, int sheetIndex) throws FileNotFoundException , EncryptedDocumentException , InvalidFormatException , IOException{
       init(file, sheetIndex);
   }

   private void  init(File file)  throws FileNotFoundException , EncryptedDocumentException , InvalidFormatException , IOException{
       workbook = WorkbookFactory.create(file);
       workbookPath = file.getAbsolutePath();
   }

   private void  init(File file, String sheetName)  throws FileNotFoundException , EncryptedDocumentException , InvalidFormatException , IOException{
       workbook = WorkbookFactory.create(file);
       workbookPath = file.getAbsolutePath();
       changeSheet(sheetName);
   }
   private void  init(File file, int sheetIndex)  throws FileNotFoundException , EncryptedDocumentException , InvalidFormatException , IOException{
       workbook = WorkbookFactory.create(file);
       workbookPath = file.getAbsolutePath();
       changeSheet(sheetIndex);
   }
   /**
    *
    * @param path
    * @throws EncryptedDocumentException パスワードがかかったファイル
    * @throws InvalidFormatException 誰かが使ってる
    * @throws IOException ファイルがないとか壊れてるとか
    */
   public Workbook setWorkBook(String path) throws FileNotFoundException , EncryptedDocumentException , InvalidFormatException , IOException{
      init(new File(path));
      worksheet = null;
      return workbook;
   }

   public Workbook setWorkBook(File file) throws FileNotFoundException , EncryptedDocumentException , InvalidFormatException , IOException{
       init(file);
      worksheet = null;
      return workbook;
   }
   public Workbook setWorkBook(String path, String sheetName) throws FileNotFoundException , EncryptedDocumentException , InvalidFormatException , IOException{
       init(new File(path), sheetName);
       return workbook;
    }

    public Workbook setWorkBook(File file, String sheetName) throws FileNotFoundException , EncryptedDocumentException , InvalidFormatException , IOException{
        init(file, sheetName);
       return workbook;
    }

    public Workbook setWorkBook(String path, int sheetIndex) throws FileNotFoundException , EncryptedDocumentException , InvalidFormatException , IOException{
        init(new File(path), sheetIndex);
        return workbook;
     }

     public Workbook setWorkBook(File file, int sheetIndex) throws FileNotFoundException , EncryptedDocumentException , InvalidFormatException , IOException{
         init(file, sheetIndex);
        return workbook;
     }

   public Workbook getWorkBook(){
      return workbook;
   }

   public Sheet getWookSheet(){
      return worksheet;
   }

   public String getWorkBookPath(){
      return workbookPath;
   }

   public boolean changeSheet(String sheetName){
      worksheet = getSheet(sheetName);
      return worksheet == null ? false : true ;
   }

   public boolean changeSheet(int sheetIndex){
      worksheet = getSheet(sheetIndex);
      return worksheet == null ? false : true ;
   }

   public Sheet getWorkSheet(){
      return worksheet;
   }

   public Sheet getSheet(String sheetName){
      return workbook != null ? workbook.getSheet(sheetName) : null;
   }
   public Sheet getSheet(int sheetIndex){
      return workbook != null ? workbook.getSheetAt(sheetIndex) : null;
   }

   public Row getRow(int rowIndex) {
      if(worksheet == null){
         //throw new IllegalStateException("ワークシートが設定されていません。");
         System.out.print("ワークシートが設定されていません。");
         return null;
      }
      return worksheet.getRow(rowIndex);
   }

   /*
    *
   CREATE_NULL_AS_BLANK - もし指定されたカラム（列）のセルが存在しなければ、nullを返す代わりに、セル種別が"blank"である新しいセルを作成して返す。これはNullPointerExceptionsの発生を防ぐのに便利である。
   RETURN_BLANK_AS_NULL - 指定されたセルは存在するがセル種別が"blank"である場合もnullを返す。これは"blank"セルを（"Missing Cell"と一緒くたに）無視するのに便利である。
   RETURN_NULL_AND_BLANK - 現に存在しているデータ構造に対して何も手を加えない。セルが本当に存在しないときだけnullを返し、セルが存在するが"blank"である場合はセル種別が"blank"のセルを返す。これはMissingCellPolicyを引数に取らないgetCell(int)メソッドと同じ挙動である。
    */
   public Cell getCell(int rowIndex, int columnIndex) {
      return getCell(rowIndex, columnIndex, Row.MissingCellPolicy.RETURN_NULL_AND_BLANK);
   }
   public Cell getCell(Point pointer) {
       return getCell(pointer.x, pointer.y, Row.MissingCellPolicy.RETURN_NULL_AND_BLANK);
    }

   public Cell getCell(int rowIndex, int columnIndex, Row.MissingCellPolicy policy) {
      if(worksheet == null){
         //throw new IllegalStateException("ワークシートが設定されていません。");
         System.out.print("ワークシートが設定されていません。");
         return null;
      }
      try{
         return getRow(rowIndex).getCell(columnIndex, policy);
      }catch(IllegalArgumentException e){
         //throw new IllegalArgumentException("セルの値が不正です。");
         System.out.print("セルの値が不正です。");
         return null;
      }
   }

   public Iterator<Row> getRows() {
      if(worksheet == null){
         //throw new IllegalStateException("ワークシートが設定されていません。");
         System.out.print("ワークシートが設定されていません。");
         return null;
      }
      return worksheet.rowIterator();
   }

   public Iterator<Cell> getCells(int rowIndex) {
      if(worksheet == null){
         //throw new IllegalStateException("ワークシートが設定されていません。");
         System.out.print("ワークシートが設定されていません。");
         return null;
      }
      Row row  = getRow(rowIndex);
      return row.cellIterator();
   }

   public ArrayList<Cell> getCells(int rowIndex, int startColumnIndex, int endColumnIndex) {
      ArrayList<Cell> list = new ArrayList<>();
      for(int i = startColumnIndex; i<endColumnIndex;i++){
         Cell cell = getCell(rowIndex, i, Row.MissingCellPolicy.RETURN_NULL_AND_BLANK);
         if(cell != null){
            list.add(cell);
         }
      }
      return list.size()>0 ? list : null;
   }

   public Map<Integer,ArrayList<Cell>> getCells(int startRowIndex, int endRowIndex, int startColumnIndex, int endColumnIndex){
      Map<Integer,ArrayList<Cell>>  map = new HashMap<>();
      for(int i = startRowIndex; i<endRowIndex;i++){
         ArrayList<Cell> list = new ArrayList<>();
         for(int j = startColumnIndex; j<endColumnIndex;i++){
            Cell cell = getCell(i, j, Row.MissingCellPolicy.RETURN_NULL_AND_BLANK);
            if(cell != null){
               list.add(cell);
            }
         }
         map.put(i, list);
      }
      return map.size()>0 ? map : null;
   }

   public static Object convertValue(Cell cell){
       if(cell == null) return null;
       switch (cell.getCellTypeEnum()) {
           case  BOOLEAN:
               return cell.getBooleanCellValue();
           case NUMERIC:
               return DateUtil.isCellDateFormatted(cell) ? cell.getDateCellValue() : cell.getNumericCellValue();
           case STRING:
               return cell.getStringCellValue();
           case FORMULA:
               return convertFormulaValue(cell);
           case BLANK:
               return "";
           default:
                   break;
       }
       return null;
   }
   private static Object convertFormulaValue(Cell cell){
       if(cell == null) return null;
       switch (cell.getCachedFormulaResultTypeEnum()) {
           case  BOOLEAN:
               return cell.getBooleanCellValue();
           case NUMERIC:
               return DateUtil.isCellDateFormatted(cell) ? cell.getDateCellValue() : cell.getNumericCellValue();
           case STRING:
               return cell.getStringCellValue();
           case ERROR:
               return "error";
           default:
               break;
       }
       return null;
   }
}
