package com.common.xml;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class XMLHelper {
    public static void parser(String path) throws FileNotFoundException, XMLStreamException {
        XMLInputFactory factory = XMLInputFactory.newInstance();

        BufferedInputStream stream = new BufferedInputStream(new FileInputStream(path));
        XMLStreamReader reader = factory.createXMLStreamReader(stream);

        for (; reader.hasNext(); reader.next()) {
            int eventType = reader.getEventType();


            if (eventType == XMLStreamConstants.START_ELEMENT) {
                System.out.println("Name: " + reader.getName());
                System.out.println("Local Name: " + reader.getLocalName());
                System.out.println("Prefix: " + reader.getPrefix());

                System.out.println("Attribute:");
                int count = reader.getAttributeCount();
                System.out.println("  Count: " + count);
                for (int i = 0; i < count; i++) {
                    System.out.println("  Name: " + reader.getAttributeName(i));
                    System.out.println("  Local Name: " + reader.getAttributeLocalName(i));
                    System.out.println("  Namespace: " + reader.getAttributeNamespace(i));
                    System.out.println("  Type: " + reader.getAttributeType(i));
                    System.out.println("  Value: " + reader.getAttributeValue(i));
                }

                System.out.println("Namespace:");
                System.out.println("  URI: " + reader.getNamespaceURI());
                count = reader.getNamespaceCount();
                System.out.println("  Count: " + count);
                for (int i = 0; i < count; i++) {
                    System.out.println("  Prefix: " + reader.getNamespacePrefix(i));
                    System.out.println("  URI: " + reader.getNamespaceURI(i));
                }

                System.out.println();
            }
        }

        reader.close();
        /*
        Configurations configs = new Configurations();
        try {
            if(new File(path).exists()){
                XMLConfiguration config  =  configs.xml(path);
                return config;
            }
        } catch (ConfigurationException e) {
            e.printStackTrace();
        }
        return null;
        */
    }
    public static void testNode(Element root,String nodeName){
        NodeList cliant = root.getElementsByTagName(nodeName);
        for(int i=0; i < cliant.getLength(); i++) {
            Node node = cliant.item(i);

            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element)node;
                NodeList personChildren = node.getChildNodes();

                for (int j=0; j < personChildren.getLength(); j++) {
                    Node personNode = personChildren.item(j);
                    if (personNode.getNodeType() == Node.ELEMENT_NODE) {

                        if (personNode.getNodeName().equals("age")) {
                            System.out.println("年齢：" + personNode.getTextContent());
                        } else if (personNode.getNodeName().equals("interest")) {
                            System.out.println("趣味:" + personNode.getTextContent());
                        }else{
                            System.out.println(personNode.getTextContent());
                        }

                    }
                }
                System.out.println("------------------");
            }
        }
    }
    public static void cliant(Element root){
        NodeList cliant = root.getElementsByTagName("cliant");
        for(int i=0; i < cliant.getLength(); i++) {
            Node node = cliant.item(i);

            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element)node;
                NodeList personChildren = node.getChildNodes();

                for (int j=0; j < personChildren.getLength(); j++) {
                    Node personNode = personChildren.item(j);
                    if (personNode.getNodeType() == Node.ELEMENT_NODE) {

                        if (personNode.getNodeName().equals("age")) {
                            System.out.println("年齢：" + personNode.getTextContent());
                        } else if (personNode.getNodeName().equals("interest")) {
                            System.out.println("趣味:" + personNode.getTextContent());
                        }else{
                            System.out.println(personNode.getTextContent());
                        }

                    }
                }
                System.out.println("------------------");
            }
        }
    }
    public static void domRead(String file) throws SAXException, IOException, ParserConfigurationException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder = factory.newDocumentBuilder();
        Document document = documentBuilder.parse(file);

        Element root = document.getDocumentElement();

        //ルート要素のノード名を取得する
        System.out.println("ノード名：" +root.getNodeName());

        //ルート要素の属性を取得する
        System.out.println("ルート要素の属性：" + root.getAttribute("name"));
        testNode(root,"client");
        /*
        //ルート要素の子ノードを取得する
        NodeList rootChildren = root.getChildNodes();

        System.out.println("子要素の数：" + rootChildren.getLength());
        System.out.println("------------------");

        for(int i=0; i < rootChildren.getLength(); i++) {
            Node node = rootChildren.item(i);

            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element)node;
                NodeList personChildren = node.getChildNodes();

                for (int j=0; j < personChildren.getLength(); j++) {
                    Node personNode = personChildren.item(j);
                    if (personNode.getNodeType() == Node.ELEMENT_NODE) {

                        if (personNode.getNodeName().equals("age")) {
                            System.out.println("年齢：" + personNode.getTextContent());
                        } else if (personNode.getNodeName().equals("interest")) {
                            System.out.println("趣味:" + personNode.getTextContent());
                        }else{
                            System.out.println(personNode.getTextContent());
                        }

                    }
                }
                System.out.println("------------------");
            }

        }
*/


    }
}
