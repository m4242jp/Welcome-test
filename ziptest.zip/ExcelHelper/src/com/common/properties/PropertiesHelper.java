package com.common.properties;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Locale;
import java.util.ResourceBundle;

public class PropertiesHelper {

    public static ResourceBundle loadPropertiesByUtf8(String resource) throws IOException {
        URLClassLoader urlLoader = new URLClassLoader(new URL[]{new File(resource).toURI().toURL()});
        ResourceBundle Resource
            = ResourceBundle.getBundle("configure", Locale.getDefault(), urlLoader,new UTF8Control());
        return Resource;
    }

}
