package com.exsample.order.data;

class SellOrderData extends OrderData{


    SellOrderData(String orderId, String name, String areaNo, double price, double volume) {
        super(orderId, name, areaNo, price, volume);
        // TODO 自動生成されたコンストラクター・スタブ
    }

    @Override
    public Object sendOrder() {
        String result = "sell :" + log();
        System.out.println(result);
        return result;
    }

    @Override
    public String isOrderType() {
        return "02";
    }

    @Override
    public boolean isBuy() {
        return false;
    }

}
