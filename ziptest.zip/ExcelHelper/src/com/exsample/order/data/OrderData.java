package com.exsample.order.data;

import com.exsample.Utility;

public abstract class OrderData {

    private String orderId;
    private String name;
    private String areaNo;
    private double price ;
    private double volume ;
    private  int rowIndex;

    public abstract Object sendOrder();
    public abstract String isOrderType();
    public abstract boolean isBuy();

    OrderData(String orderId ,
            String name ,
            String areaNo  ,
            double price ,
            double volume){
        this.orderId = orderId;
        this.name = name;
        this.areaNo =areaNo;
        this.price =  price;
        this.volume = volume;
        }


    public static OrderData factory(
            String orderId ,
            String name ,
            String areaNo  ,
            double price ,
            double volume
            ) {
        if(orderId != null && name != null && areaNo != null){
            if(price != 0 && volume != 0){
                if( volume > 0){
                    return new BuyOrderData(orderId,name,areaNo,price,volume);
                }else if( volume < 0){
                    return new SellOrderData(orderId,name,areaNo,price,volume * -1);
                }
            }
        }
        return null;
    }

    public void setRowIndex(int rowIndex) {
        this.rowIndex = rowIndex;
    }

    public String log(){
        Utility.log("orderId :" +  orderId + " ," + "orderType :" +  isOrderType() + " ," + "name :" +  name + " , " + "areano :" +  areaNo + " , "  + "volume :"   +  volume + "  , " + "price :" +  price );
        return "orderId :" +  orderId + " ," + "orderType :" +  isOrderType() + " ," + "name :" +  name + " , " + "areano :" +  areaNo + " , "  + "volume :"   +  volume + "  , " + "price :" +  price;
    }
}
