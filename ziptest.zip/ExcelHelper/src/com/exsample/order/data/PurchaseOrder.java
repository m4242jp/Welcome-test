package com.exsample.order.data;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.exsample.Utility;

public class PurchaseOrder {
    public Date targetDate;
    public String sepalateStart = null;
    public String sepalateEnd = null;
    public final List<OrderData> buyOrders = new ArrayList<>();
    public final List<OrderData> sellOrders = new ArrayList<>();


    public void log(){
        Utility.log("****************");
        Utility.log("sepalateStart :" + sepalateStart + " sepalateEnd :" + sepalateEnd);
        Utility.log("date :" + targetDate);

        Utility.log("Buy-----------------");
        for(OrderData d :buyOrders){
            d.log();
            d.sendOrder();
        }
        Utility.log("Sell-----------------");
        for(OrderData d :sellOrders){
            d.log();
            d.sendOrder();
        }
    }

    public boolean isOrder(){
        return buyOrders.size() > 0 || sellOrders.size() > 0;
    }


    public void addOrder(OrderData orderData) {
        if(orderData.isBuy()){
            buyOrders.add(orderData);
        }else{
            sellOrders.add(orderData);
        }
    }
    public String getTitel() {
        if(sepalateStart == null && sepalateEnd != null){
            return " ~ " + sepalateEnd ;
        } else if(sepalateStart != null && sepalateEnd == null){
            return sepalateStart + " ~ " ;
        } else if(sepalateStart != null && sepalateEnd != null){
            return sepalateStart + " ~ " + sepalateEnd;
        }
        return "注文";
    }
    public String getBuysText() {
        if(buyOrders.size() > 0){
            StringBuilder builder = new StringBuilder();
            for(OrderData o : buyOrders){
                builder.append(o.log()).append("\n");
            }
            return builder.toString();
        }
        return "ありません";
    }
    public String getSellsText() {
        if(sellOrders.size() > 0){
            StringBuilder builder = new StringBuilder();
            for(OrderData o : sellOrders){
                builder.append(o.log()).append("\n");
            }
            return builder.toString();
        }
        return "ありません";
    }

    public void sendBuy() {
        if(buyOrders.size() > 0){
            Date d = new Date();
            for(OrderData o : buyOrders){
                Utility.outupt(o.sendOrder().toString(), new File("log/log_" + d.getTime() + ".txt"));
            }
        }
    }

    public void sendSell() {
        if(sellOrders.size() > 0){
            Date d = new Date();
            for(OrderData o : sellOrders){
                Utility.outupt(o.sendOrder().toString(), new File("log/log_" + d.getTime() + ".txt"));
            }
        }
    }
}
