package com.exsample.order.data;

class BuyOrderData extends OrderData{


    BuyOrderData(String orderId, String name, String areaNo, double price, double volume) {
        super(orderId, name, areaNo, price, volume);
    }

    @Override
    public Object sendOrder() {
        String result = "buy :" + log();
        System.out.println(result);
        return result;
    }

    @Override
    public String isOrderType() {
        return "01";
    }

    @Override
    public boolean isBuy() {
        return true;
    }
}
