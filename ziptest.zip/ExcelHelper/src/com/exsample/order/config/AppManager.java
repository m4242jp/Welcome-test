package com.exsample.order.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.xml.bind.JAXB;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;

import com.common.excel.ExcelHelper;
import com.exsample.Utility;
import com.exsample.order.config.mapping.AreaMapping;
import com.exsample.order.config.mapping.CellAttribute;
import com.exsample.order.config.mapping.CellMapping;
import com.exsample.order.data.OrderData;
import com.exsample.order.data.PurchaseOrder;

public class AppManager extends Config{

    public static AppManager factory(String configXmlPath) throws IllegalStateException,FileNotFoundException , IOException{
        FileInputStream fs = new FileInputStream(configXmlPath);
        AppManager appManager = JAXB.unmarshal(fs, AppManager.class);
        fs.close();
        return appManager;
    }

    public  ArrayList<PurchaseOrder> initOrder() throws IllegalStateException{
        try{
           return   createPurchaseOrder();
        }catch(Exception e){
            e.printStackTrace();
            throw new IllegalStateException("設定不正");
        }
    }


    public ArrayList<PurchaseOrder> createPurchaseOrder(){
            ArrayList<PurchaseOrder> purchases = new ArrayList<>();
            ExcelHelper helper = new ExcelHelper();
            for(String p : app.getExcelPaths()){
                File f = new File(p);
                if( f.exists()){
                    try {
                        helper.setWorkBook(f, app.getExcelSheetName());
                    } catch (FileNotFoundException e){
                        e.printStackTrace();
                        return null;
                    } catch (EncryptedDocumentException | InvalidFormatException | IOException e) {
                        e.printStackTrace();
                        return null;
                    }
                    //エクセル情報のログ出力してるだけ
                    testExcel(helper);

                    //注文の作成********************
                    List<String> seplates = app.getSeparateIds();
                    CellMapping cellMapping = app.getCellMapping();

                    //注文日を取得
                    Date targetDate = helper.getCell(cellMapping.getTargetDateAttribute().getCellPointer()).getDateCellValue();

                    //商品IDのセルのcolumnナンバーを取得
                    CellAttribute orderAttr =  cellMapping.getOrderIdAttribute();
                    int orderStartIndex = orderAttr.getRow();
                    int orderLastIndex =  orderStartIndex+48;
                    int orderColumn =  orderAttr.getColumn();

                    //エリアごとのセル(column)のマッピングクラスを取得
                    AreaMapping[] areaMapping =  cellMapping.getAreaMappings();

                    //セパーレター（切り分け）用の値を保持するクラスを用意
                    SeplatePoint seplatePoint = new SeplatePoint();
                    seplatePoint.startIndex = orderStartIndex;
                    seplatePoint.lastIndex = orderLastIndex;
                    seplatePoint.sepalateStart = null;

                    //注文の作成
                    if(seplates != null && seplates.size() > 0){
                        for(String seplate : seplates){
                            seplatePoint.sepalateEnd =seplate;
                            PurchaseOrder purchase= createP(helper, areaMapping, orderColumn, seplatePoint);
                            if(purchase.isOrder()){
                                purchase.targetDate =  targetDate;
                                purchases.add(purchase);
                            }
                            seplatePoint.sepalateStart = seplatePoint.sepalateEnd;
                        }
                    }
                    seplatePoint.sepalateEnd =null;
                    PurchaseOrder purchase= createP(helper, areaMapping, orderColumn, seplatePoint);
                    if(purchase.isOrder()){
                        purchase.targetDate =  targetDate;
                        purchases.add(purchase);
                    }
                }
                try {
                    helper.getWorkBook().close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return purchases;
            }

            try {
                helper.getWorkBook().close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        return null;
    }

    private class SeplatePoint{
        public int startIndex;
        public int lastIndex;
        public String sepalateStart=null;
        public String sepalateEnd=null;

    }
    private PurchaseOrder createP(ExcelHelper helper, AreaMapping[] areaMapping, int orderColumn ,final SeplatePoint seplatePoint ){

        PurchaseOrder purchase= new PurchaseOrder();
        purchase.sepalateStart = seplatePoint.sepalateStart;
        Iterator< Row> rows = helper.getRows();
        while(rows.hasNext()){
            Row row = rows.next();
            if(row.getRowNum() >= seplatePoint.startIndex && row.getRowNum() < seplatePoint.lastIndex){
                String orderId = row.getCell(orderColumn).getStringCellValue();
                Utility.log("now orderId : " + orderId );
                for(AreaMapping am : areaMapping){
                    OrderData orderData = createOrderData(orderId,am,row);
                    if(orderData != null){
                        purchase.addOrder(orderData);
                    }
                }
                if(seplatePoint.sepalateEnd != null && seplatePoint.sepalateEnd.equals(orderId)){
                    seplatePoint.startIndex = row.getRowNum() + 1;
                    Utility.log("sepalate : " +  seplatePoint.sepalateEnd+ " ********************");
                    purchase.sepalateEnd = seplatePoint.sepalateEnd;
                    break;
                }
            }
        }
       return purchase;
    }


    private OrderData createOrderData(String orderId, AreaMapping am , Row row){
        Cell pc = row.getCell(am.getPriceColumn(),MissingCellPolicy.RETURN_BLANK_AS_NULL);
        Cell vc = row.getCell(am.getVolumeColumn(),MissingCellPolicy.RETURN_BLANK_AS_NULL);
        if((pc != null && pc.getCellTypeEnum().equals(CellType.NUMERIC)) && (vc != null && vc.getCellTypeEnum().equals(CellType.NUMERIC))){
            String name = am.getAreaName();
            String areaNo = am.getAreaNo();
            double price =  pc.getNumericCellValue();
            double volume = vc.getNumericCellValue();
            OrderData orderData = OrderData.factory(orderId, name, areaNo, price, volume);
            if(orderData != null){
                orderData.setRowIndex(row.getRowNum());
                return orderData;
            }
        }
        return null;
    }

    /*
public ArrayList<PurchaseOrder> createPurchaseOrder(){
            ArrayList<PurchaseOrder> purchases = new ArrayList<>();
            ExcelHelper helper = new ExcelHelper();
            for(String p : app.getExcelPaths()){
                File f = new File(p);
                if( f.exists()){
                    try {
                        helper.setWorkBook(f, app.getExcelSheetName());
                    } catch (FileNotFoundException e){
                        e.printStackTrace();
                        return null;
                    } catch (EncryptedDocumentException | InvalidFormatException | IOException e) {
                        e.printStackTrace();
                        return null;
                    }
                    testExcel(helper);

                    //注文の作成
                    List<String> seplates = app.getSeparateIds();
                    CellMapping cellMapping = app.getCellMapping();

                    Date targetDate = helper.getCell(cellMapping.getTargetDateAttribute().getCellPointer()).getDateCellValue();
                    CellAttribute orderAttr =  cellMapping.getOrderIdAttribute();
                    AreaMapping[] areaMapping =  cellMapping.getAreaMappings();
                    int orderStartIndex = orderAttr.getRow();
                    int orderLastIndex =  orderStartIndex+48;
                    int orderColumn =  orderAttr.getColumn();


                    String sepalateStart = null;
                    if(seplates != null && seplates.size() > 0){
                        for(String seplate : seplates){
                            PurchaseOrder purchase= new PurchaseOrder();
                            purchase.sepalateStart = sepalateStart;
                            purchase.targetDate =  targetDate;
                            Iterator< Row> rows = helper.getRows();
                            while(rows.hasNext()){
                                Row row = rows.next();
                                if(row.getRowNum() >= orderStartIndex && row.getRowNum() < orderLastIndex){
                                    String orderId = row.getCell(orderColumn).getStringCellValue();
                                    Utility.log("now orderId : " + orderId );
                                    for(AreaMapping am : areaMapping){
                                        OrderData orderData = createOrderData(orderId,am,row);
                                        if(orderData != null){
                                            purchase.addOrder(orderData);
                                        }
                                    }
                                    if(seplate != null && seplate.equals(orderId)){
                                        orderStartIndex = row.getRowNum() + 1;
                                        Utility.log("sepalate : " + seplate+ " ********************");
                                        purchase.sepalateEnd = seplate;
                                        sepalateStart = seplate;
                                        break;
                                    }
                                }
                            }
                            if(purchase.isOrder()){
                                purchases.add(purchase);
                            }
                        }
                    }
                    PurchaseOrder purchase= new PurchaseOrder();
                    purchase.sepalateStart = sepalateStart;
                    purchase.targetDate =  targetDate;
                    Iterator< Row> rows = helper.getRows();
                    while(rows.hasNext()){
                        Row row = rows.next();
                        if(row.getRowNum() >= orderStartIndex && row.getRowNum() < orderLastIndex){
                            String orderId = row.getCell(orderColumn).getStringCellValue();
                            Utility.log("now orderId : " + orderId );
                            for(AreaMapping am : areaMapping){
                                OrderData orderData = createOrderData(orderId,am,row);
                                if(orderData != null){
                                    purchase.addOrder(orderData);
                                }
                            }
                        }
                    }
                    if(purchase.isOrder()){
                        purchases.add(purchase);
                    }
                }
                return purchases;
            }
        return null;
    }


     */

    public void testExcel(ExcelHelper helper){
        Utility.log("**************************************");
        Utility.log("PATH :" + helper.getWorkBookPath());
        Utility.log("SHEET :" + helper.getWookSheet().getSheetName());
        Utility.log("------------");
    }
}
