package com.exsample.order.config;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;



@XmlRootElement(name="client")
public class ClientConfig {

    @XmlElement(name="account-user",nillable=false,required=true)
    private String user;

    @XmlElement(name="account-password",nillable=false,required=true)
    private String password;

    @XmlElement(name="keystore-path",nillable=false,required=true)
    private String kestore;

    @XmlElement(name="keystore-type",nillable=false,required=true)
    private String kestoreType;

    @XmlElement(name="keystore-password",nillable=false,required=true)
    private String kestorePassword;

    public String getUser() {
        return user;
    }
    /*
    @XmlElement(name="client-account-password")
    public String getPassword() {
        return password;
    }
    @XmlElement(name="client-keystore-path")
    public String getKestore() {
        return kestore;
    }
    @XmlElement(name="client-keystore-type")
    public String getKestoreType() {
        return kestoreType;
    }
    @XmlElement(name="client-keystore-password")
    public String getKestorePassword() {
        return kestorePassword;
    }
*/
    public void log() {

        System.out.println("user: " +  getUser());
        System.out.println("password: " + password);
        System.out.println("kestore: " + kestore);
        System.out.println("kestoreType: " + kestoreType);
        System.out.println("kestorePassword: " + kestorePassword);

    }
}
