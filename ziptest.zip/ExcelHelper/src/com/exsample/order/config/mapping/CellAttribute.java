package com.exsample.order.config.mapping;

import java.awt.Point;

import javax.xml.bind.annotation.XmlAttribute;

public class CellAttribute {

    @XmlAttribute(name="row",required=true)
    private int row;

    @XmlAttribute(name="column",required=true)
    private int column;

    @XmlAttribute(name="max")
    private double max;

    public Point getCellPointer(){
       return new Point(row, column);
    }
    public int getRow() {
        return row;
    }

    public int getColumn() {
        return column;
    }

    public double getMax() {
        return max;
    }

    public void log() {

        System.out.println("row: " + row);
        System.out.println("column: " + column);
        if(max > 0)System.out.println("max: " + max);
    }
}
