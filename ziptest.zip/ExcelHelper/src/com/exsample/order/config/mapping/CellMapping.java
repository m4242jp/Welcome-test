package com.exsample.order.config.mapping;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="mapping")
public class CellMapping {

    @XmlElement(name="targetdate",nillable=false,required=true)
    private CellAttribute targetDateAttribute;

    @XmlElement(name="orderid",nillable=false,required=true)
    private CellAttribute orderIdAttribute;

    @XmlElementWrapper(name="areas")
    @XmlElement(name="area",nillable=false,required=true)
    private AreaMapping[] areaMappings;

    public CellAttribute getTargetDateAttribute() {
        return targetDateAttribute;
    }

    public CellAttribute getOrderIdAttribute() {
        return orderIdAttribute;
    }

    public AreaMapping[] getAreaMappings() {
        return areaMappings;
    }



    public void log() {
        targetDateAttribute.log();
        orderIdAttribute.log();
        for(AreaMapping s : areaMappings){
            s.log();
        }
    }
}
