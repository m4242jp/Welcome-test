package com.exsample.order.config.mapping;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class AreaMapping {

    @XmlAttribute(name="name",required=true)
    private String areaName;

    @XmlAttribute(name="no",required=true)
    private String areaNo;

    @XmlElement(name="volume",nillable=false,required=true)
    private CellAttribute volumeAttribute;

    @XmlElement(name="price",nillable=false,required=true)
    private CellAttribute priceCellAttribute;

    @XmlElement(name="result",nillable=false,required=true)
    private CellAttribute resultCellAttribute;

    public String getAreaName() {
        return areaName;
    }

    public String getAreaNo() {
        return areaNo;
    }

    public int getVolumeColumn() {
        return volumeAttribute.getColumn();
    }

    public int getPriceColumn() {
        return priceCellAttribute.getColumn();
    }


    public void log() {
        System.out.println("---------------------------");
        System.out.println("areaName: " + areaName);
        System.out.println("areaNo: " + areaNo);
        System.out.println("----volume");
        volumeAttribute.log();
        System.out.println("----price");
        priceCellAttribute.log();
        System.out.println("----result");
        resultCellAttribute.log();
    }
}
