package com.exsample.order.config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import com.exsample.Utility;
import com.exsample.order.config.mapping.CellMapping;



@XmlRootElement(name="app-settings")
public class AppConfig {

    @XmlElement(name="strictmode",nillable=false,required=true)
    private boolean strictmode;

    @XmlElement(name="load-excels-sheet",nillable=false,required=true)
    private String excel_sheet_name;

    @XmlElementWrapper(name="load-excels")
    @XmlElement(name="path",nillable=false,required=true)
    private String[] load_excel_paths;

    @XmlElementWrapper(name="separate")
    @XmlElement(name="id",nillable=false,required=true)
    private String[] separate_ids;

    @XmlElement(name="mapping",nillable=false,required=true)
    private CellMapping cellMapping;

    public String getExcelSheetName(){
        return excel_sheet_name;
    }
    public String[] getExcelPaths(){
        return load_excel_paths;
    }
    public List<String> getSeparateIds(){
       Arrays.sort(separate_ids);
       List<String> list = new ArrayList<>();
       for (String s : separate_ids) {
           if (!list.contains(s)) {
               list.add(s);
           }
       }
       for (String s : list) {
           Utility.log(s);
       }
        return list;
    }

    public CellMapping getCellMapping() {
        return cellMapping;
    }

    public void log() {

        System.out.println("strictmode: " + strictmode);
        System.out.println("sheet-name:" + excel_sheet_name);
        for(String s : load_excel_paths){
            System.out.println("exs: " + s);
        }
        for(String s : separate_ids){
            System.out.println("separate: " + s);
        }

        cellMapping.log();
    }

}
