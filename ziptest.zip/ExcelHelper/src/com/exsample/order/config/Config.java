package com.exsample.order.config;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;



@XmlRootElement(name="config")
public class Config {


    @XmlElement(name="client")
    protected ClientConfig client;

    @XmlElement(name="app-settings")
    protected AppConfig app;

    public ClientConfig getClient() {
        return client;
    }
    public AppConfig getApp() {
        return app;
    }

    public void log() {
        System.out.println("client---------------------------");
        client.log();
        System.out.println("app---------------------------");
        app.log();
    }
}
