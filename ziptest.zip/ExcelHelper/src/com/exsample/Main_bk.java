package com.exsample;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.Iterator;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.xml.bind.JAXB;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import com.common.excel.CellWrapper;
import com.common.excel.ExcelHelper;
import com.exsample.order.config.Config;

public class Main_bk extends JFrame{

    public static String ex;
    public static String ex2;
    private  Config config;
    private  String configXmlPath = "config/configure.xml";
	public static void main(String[] args)  {
		try{
		      new Main_bk() ;
		}catch (Exception e){
			e.printStackTrace();
		}
	}
	public Main_bk() {
	    try{
	        config =  loadConfig();
	    }catch(Exception e){
	        e.printStackTrace();
	    }

	    try {
            ExcelHelper helper = new ExcelHelper();

            for(String s : config.getApp().getExcelPaths()){
                helper.setWorkBook(s,"sss");
                test(helper);
            }
	    } catch (FileNotFoundException e){
            e.printStackTrace();
/*
	          getContentPane().setLayout(new FlowLayout());

	          DialogWindow dlg = new DialogWindow(this);
	          setVisible(true);
	          dlg.setModal(false);

	          setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	          setTitle("ダイアログウィンドウ呼び出し元");
	          setSize(530, 200);
	          setVisible(true);*/
        } catch (EncryptedDocumentException | InvalidFormatException | IOException e) {

            e.printStackTrace();
        }
	   }
	public Config loadConfig() throws IOException{
	    String xml = configXmlPath;
	    //   XMLHelper.parser("config/configure.xml");
	    /*
        try {
            XMLHelper.domRead("config/configure.xml");
        } catch (SAXException | ParserConfigurationException e) {
            // TODO 自動生成された catch ブロック
            e.printStackTrace();
        }
        */
	    FileInputStream fs = new FileInputStream(xml);
        Config config = JAXB.unmarshal(fs, Config.class);
        fs.close();
        config.log();
        return config;
	}



	public Properties loadP(String resoucePath) throws IOException{
	    Properties properties = new Properties();
	    InputStream in = new FileInputStream(resoucePath);
	    try (Reader reader = new InputStreamReader(
	            in, "UTF-8")
	            ){
	                properties.load(reader);
	            }
	    in.close();
	    return properties;
	}

	public void test(ExcelHelper helper){
        log("**************************************");
        log("PATH :" + helper.getWorkBookPath());
        log("SHEET :" + helper.getWookSheet().getSheetName());
        log("--------------");

	    Iterator<Row> rows = helper.getRows();
        while(rows.hasNext()){
            Row row = rows.next();
            Iterator<Cell> cells  =  row.cellIterator();
            while(cells.hasNext()){
                Cell cell = cells.next();
                   log(cell.getRowIndex() + ":" + cell.getColumnIndex()  + " = " + CellWrapper.convertValue(cell));
                //   OrderData.factoryBuyOrder().sendOrder();
                   //OrderData.factorySaleOrder().sendOrder();
            }
        }
        log("**************************************");
	}
    class DialogWindow extends JDialog implements ActionListener {
    	   DialogWindow(JFrame owner) {
    	      super(owner);
    	      getContentPane().setLayout(new FlowLayout());

    	      JButton btn = new JButton("ボタン表示");
    	      btn.addActionListener(this);
    	      getContentPane().add(btn);

    	      setTitle("ダイアログウィンドウ");
    	      setSize(200, 150);
    	      setVisible(true);
    	   }
    	   public void actionPerformed(ActionEvent e) {
    	      setVisible(true);
    	   }
    	}

    public void log(Object o){
        System.out.println(o);
    }
}
