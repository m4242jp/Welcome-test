package com.exsample;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;

import com.exsample.order.config.AppManager;
import com.exsample.order.data.PurchaseOrder;

public class Main extends JFrame{

    private  AppManager appManager;
    private  String configXmlPath = "config/configure.xml";

	public static void main(String[] args)  {
		try{
		      new Main() ;
		}catch (Exception e){
			e.printStackTrace();
		}
	}
	public Main() {
	    try{
	        appManager =  AppManager.factory(configXmlPath);
	    }catch(Exception e){
	        Utility.log("処理を中断します");
	        e.printStackTrace();
	        return;
	    }
        try{
            JTabbedPane tabbedpane = new JTabbedPane();
            ArrayList<PurchaseOrder> purchases = appManager.initOrder();
            if(purchases != null){
                for(PurchaseOrder o :purchases){
                        o.log();
                        final PurchaseOrder purchase  = o;
                        JPanel tabPanel = new JPanel();
                        tabPanel.setLayout(new BoxLayout(tabPanel, BoxLayout.PAGE_AXIS));
                        JLabel label = new JLabel("注文 : " + o.targetDate);
                        JPanel oerderPanel = new JPanel();
                        oerderPanel.setLayout(new BoxLayout(oerderPanel, BoxLayout.LINE_AXIS));
                        JTextArea textArea1 = new JTextArea();
                        textArea1.setText(o.getBuysText() );
                         final JScrollPane scroll1 = new JScrollPane(textArea1);
                         JTextArea textArea2 = new JTextArea();
                         textArea2.setText(o.getSellsText());
                          final JScrollPane scroll2 = new JScrollPane(textArea2);
                          oerderPanel.add(scroll1);
                          oerderPanel.add(scroll2);
                          tabPanel.add(label);
                          tabPanel.add(oerderPanel);

                          JPanel btnPanel = new JPanel();
                          btnPanel.setLayout(new BoxLayout(btnPanel, BoxLayout.LINE_AXIS));
                          JButton btn1 = new JButton("buy");
                          btn1.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                Utility.log("buy ------------------------------------");
                                purchase.sendBuy();
                            }
                        });
                          JButton btn2 = new JButton("sell");
                          btn2.addActionListener(new ActionListener() {
                              @Override
                              public void actionPerformed(ActionEvent e) {
                                  Utility.log("sell ------------------------------------");
                                  purchase.sendSell();
                              }
                          });
                          JButton btn3 = new JButton("all");
                          btn3.addActionListener(new ActionListener() {
                              @Override
                              public void actionPerformed(ActionEvent e) {
                                  Utility.log("all ------------------------------------");
                                  purchase.sendBuy();
                                  purchase.sendSell();
                              }
                          });
                          btnPanel.add(btn1);
                          btnPanel.add(btn2);
                          btnPanel.add(btn3);
                          tabPanel.add(btnPanel);
                        tabbedpane.addTab(o.getTitel(), tabPanel);
                }
            }
            //tabbedpane.setSelectedIndex(0);
            this.setTitle("TITLE未定");
            this.add(tabbedpane);
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            this.setBounds(10, 10, 800, 600);
            this.setLocationRelativeTo(null);
            this.setVisible(true);
        }catch(Exception e){
            Utility.log("処理を中断します");
            e.printStackTrace();
            return;
        }
   }

	/*
    @Override
    public void actionPerformed(ActionEvent e) {
        String cmdName=e.getActionCommand();
        if("buy".equals(cmdName)){
           // "red"の処理
         }
         else if("sell".equals(cmdName)){
           // "blue"の処理
         }
         else if("all".equals(cmdName)){
           // "yellow"の処理
         }
    }
    */
    class DialogWindow extends JDialog implements ActionListener {
    	   DialogWindow(JFrame owner) {
    	      super(owner);
    	      getContentPane().setLayout(new FlowLayout());

    	      JButton btn = new JButton("ボタン表示");
    	      btn.addActionListener(this);
    	      getContentPane().add(btn);

    	      setTitle("ダイアログウィンドウ");
    	      setSize(200, 150);
    	      setVisible(true);
    	   }
    	   public void actionPerformed(ActionEvent e) {
    	      setVisible(true);
    	   }
    	}


}
