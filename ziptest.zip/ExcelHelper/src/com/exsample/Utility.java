package com.exsample;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Utility {

    public static void log(Object o){
        System.out.println(o);
    }

    public static void outupt(String s,File out){
            File dir = out.getParentFile();
            if(!dir.exists()){
                dir.mkdirs();
            }
        try {
            FileWriter fw = new FileWriter(out,true);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(s);
            bw.newLine();
            bw.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

}
