package asia.uniuni.view;

import java.awt.LayoutManager;

import javax.swing.JFrame;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public abstract class AbsBaseFrame extends JFrame{

    public abstract void onCreateViews();

    public AbsBaseFrame(int width, int height) {
        init(width,height,null);
    }

    public AbsBaseFrame(int width, int height , LayoutManager baseManager) {
        init(width,height,baseManager);
    }

    private void init(int width, int height , LayoutManager baseManager){
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
          } catch (ClassNotFoundException | InstantiationException
                  | IllegalAccessException | UnsupportedLookAndFeelException e) {
            e.printStackTrace();
          }

        setBounds(10, 10, width, height);
        if( baseManager != null){
            setLayout(baseManager);
        }

        initOptions();
        onCreateViews();
    }

    public void initOptions(){
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
