package asia.uniuni.view;

import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import asia.uniuni.main.Env;
import asia.uniuni.model.SimpleAncer;
import asia.uniuni.model.SimpleData;
import asia.uniuni.module.CSVAncerManager;

public class MainFrame extends AbsBaseFrame implements ActionListener, ListSelectionListener{


    private DefaultListModel<SimpleData> listModel;
    private JList<SimpleData> list;

    private DefaultListModel<SimpleAncer> listModelAncer;
    private JList<SimpleAncer> list_ancer;

    private JLabel label;
    private OnRefreshBtnClickListener listener = null;
    private final String ACTION_BTN_REFRESH = "ACTION_BTN_REFRESH";
    private final String ACTION_BTN_REFRESH2 = "ACTION_BTN_REFRESH2";

    public interface OnRefreshBtnClickListener{
        void onClickRefresh1();
        void onClickRefresh2();
    }

    public MainFrame() {
        super(Env.BASE_FRAME_WIDTH, Env.BASE_FRAME_HEIGHT, new  FlowLayout());
    }

    @Override
    public void onCreateViews() {

        JPanel list_panel = new JPanel();
        list_panel.setLayout(new BoxLayout(list_panel, BoxLayout.LINE_AXIS));

        listModel = new DefaultListModel<>();
        listModel.addElement(new SimpleData("USA","sub"));
        listModel.addElement(new SimpleData("India","sub"));
        listModel.addElement(new SimpleData("Vietnam","sub"));
        listModel.addElement(new SimpleData("Canada","sub"));
        listModel.addElement(new SimpleData("Denmark","sub"));
        listModel.addElement(new SimpleData("France","sub"));
        listModel.addElement(new SimpleData("Great Britain","sub"));
        listModel.addElement(new SimpleData("Japan","sub"));

        JScrollPane scrooll = new JScrollPane();
        list= new JList<>(listModel);
        list.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                Component renderer = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (renderer instanceof JLabel && value instanceof SimpleData) {
                    // Here value will be of the Type 'CD'
                    ((JLabel) renderer).setText(((SimpleData) value).getTitle()  + " : " + ((SimpleData) value).getSub());
                }
                return renderer;
            }
        });
        list.addListSelectionListener(this);
        scrooll.setViewportView(list);


        listModelAncer = new DefaultListModel<>();

        JScrollPane scrooll2 = new JScrollPane();
        list_ancer= new JList<>(listModelAncer);
        list_ancer.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                Component renderer = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (renderer instanceof JLabel && value instanceof SimpleAncer) {
                    ((JLabel) renderer).setText(((SimpleAncer) value).getTextarea1()
                            + " : " + ((SimpleAncer) value).getRadio1()
                            + " : " + ((SimpleAncer) value).getSelect1()
                            + " : " + ((SimpleAncer) value).getSelect2());
                }
                return renderer;
            }
        });
        list_ancer.addListSelectionListener(this);
        scrooll2.setViewportView(list_ancer);

        list_panel.add(scrooll);
        list_panel.add(scrooll2);
        add(list_panel);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));
        label = new JLabel("aaa");
        panel.add(label);

        JButton btn = new JButton("refresh");
        btn.addActionListener(this);
        btn.setActionCommand(ACTION_BTN_REFRESH);
        panel.add(btn);

        JButton btn2 = new JButton("refresh");
        btn2.addActionListener(this);
        btn2.setActionCommand(ACTION_BTN_REFRESH2);
        panel.add(btn2);

        add(panel);
    }


    public void setOnRefreshBtnClickListener(OnRefreshBtnClickListener listener){
       this.listener =  listener;
    }

    public void setLabel(String msg){
        if(label != null){
            label.setText(msg);
        }
    }

    public void addListData(SimpleData data){
        if(listModel != null){
            listModel.addElement(data);
        }
    }


    public void onClickRefresh1(){
        if(listener != null){
            listener.onClickRefresh1();
        }
    }

    public void onClickRefresh2(){
        if(listener != null){
            listener.onClickRefresh2();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();

        if (cmd.equals(ACTION_BTN_REFRESH)){
          onClickRefresh1();
        }else if (cmd.equals(ACTION_BTN_REFRESH2)){
          onClickRefresh2();
        }
    }


    @Override
    public void valueChanged(ListSelectionEvent e) {

    }

    public void refreshListAncer(){
        File f = new File("csv/anser.csv");

        if( f.exists()){
            List<String[]> d =   CSVAncerManager.opencsvToStringArray(f);
            if(d  != null){
                System.out.println("st---------");
                for(String[] a : d){
                    for(String s: a){
                        System.out.println(s);
                    }
                }
                System.out.println("---------");
            }
            listModelAncer.clear();
           List<SimpleAncer> l =   CSVAncerManager.opencsvToBean(f);
           if(l  != null){
               for(SimpleAncer a : l){
                   listModelAncer.addElement(a);
               }
           }
           System.out.println("AAAAAAA");
        }
        System.out.println(f.getAbsolutePath());
    }

    public boolean showConfirmDialog(String title, String msg){
        int option =  JOptionPane.showConfirmDialog(this, msg,
                title, JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE);
        if (option == JOptionPane.YES_OPTION){
            return true;
          }else if (option == JOptionPane.NO_OPTION){
          }else if (option == JOptionPane.CANCEL_OPTION){
          }
        return false;
    }
}
