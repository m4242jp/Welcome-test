package asia.uniuni.controller;

import asia.uniuni.model.SimpleData;
import asia.uniuni.view.MainFrame;
import asia.uniuni.view.MainFrame.OnRefreshBtnClickListener;

public class MainController implements OnRefreshBtnClickListener{

    private MainFrame view = null;
    public void init() {

    }

    public MainFrame getView(){
        if(view == null){
            view = new MainFrame();
            view.setOnRefreshBtnClickListener(this);
        }
        return view;
    }

    public void showFrame(String title){
        final MainFrame view =  getView();
        view.setTitle(title == null ? "" : title);
        if(!view.isVisible()){
            view.setVisible(true);
        }
    }

    @Override
    public void onClickRefresh1() {
        if(getView().showConfirmDialog("CSV","いいですか？")){
            getView().setLabel("ボタン1");
            getView().addListData(new SimpleData("ボタン1","add"));
            getView().refreshListAncer();
        }else{
            getView().setLabel("Cancel");
        }

    }

    @Override
    public void onClickRefresh2() {
        getView().setLabel("ボタン2");
        getView().addListData(new SimpleData("ボタン2","add"));
        getView().refreshListAncer();
    }
}
