package asia.uniuni.module;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;

import com.opencsv.CSVReader;
import com.opencsv.bean.CsvToBeanBuilder;

import asia.uniuni.model.SimpleAncer;

public class CSVAncerManager {
    private static final String[] HEADER = new String[] { "radio1","select1","select2","textarea1" };

    public static List<String[]> opencsvToStringArray(File file) {
        try {
            InputStream input=new FileInputStream(file);
            InputStreamReader ireader=new InputStreamReader(input, "SJIS");
            CSVReader reader = new CSVReader(ireader);
            try{
                List<String[]> data =  reader.readAll();
                return data;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }finally {
                try { reader.close(); } catch(IOException e) {e.printStackTrace();}
                try { ireader.close(); } catch(IOException e) {e.printStackTrace();}
                try { input.close(); } catch(IOException e) {e.printStackTrace();}
                System.out.println("String Close");
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static List<SimpleAncer> opencsvToBean(File file) {
        try {
            InputStream input=new FileInputStream(file);
            InputStreamReader ireader=new InputStreamReader(input, "SJIS");

            try{
                List<SimpleAncer> beans = new CsvToBeanBuilder<SimpleAncer>(ireader)
                        .withType(SimpleAncer.class).build().parse();
                return beans;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }finally {
                try { ireader.close(); } catch(IOException e) {e.printStackTrace();}
                try { input.close(); } catch(IOException e) {e.printStackTrace();}
                System.out.println("Bean Close");
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
