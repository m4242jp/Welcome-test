package asia.uniuni.main;

import asia.uniuni.controller.MainController;

public class ApplicationManager {
    private static ApplicationManager manager = new ApplicationManager();

    private MainController controller;
    private ApplicationManager(){
        System.out.println("インスタンスを作成しました。");
    }

    public static ApplicationManager getInstance(){
        return manager;
    }

    protected MainController getController() {
           if(controller == null){
               controller = new MainController();
           }
           return controller;
    }

    public void showFrame(String title){
        getController().showFrame(title);
    }
}
