package asia.uniuni.main;

public class Env {
    public static final String TITLE = "TITLE";
    public static final int BASE_FRAME_WIDTH = 400;
    public static final int BASE_FRAME_HEIGHT = 300;
}
