package asia.uniuni.main;

public class Application {

    public static void main(String[] args)  {
        try{
            Application app =  new Application();
            app.run();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public Application(){
    }
    public void run() {
        ApplicationManager manager = ApplicationManager.getInstance();
        manager.showFrame(Env.TITLE);
    }
}
