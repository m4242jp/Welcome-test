package asia.uniuni.widget;

import java.util.Vector;

import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListModel;

public abstract class UListView<T> extends JList<T>{
    public abstract JLabel setChildView(JLabel  renderer , T data);

    public UListView() {
        super();
        init();
    }

    public UListView(ListModel<T> dataModel) {
        super(dataModel);
        init();
    }

    public UListView(T[] listData) {
        super(listData);
        init();
    }

    public UListView(Vector<? extends T> listData) {
        super(listData);
        init();
    }

    private void init(){
        //setCellRenderer(new UListCellRenderer<T>());
    }
    /*

    private class UListCellRenderer<T> extends DefaultListCellRenderer{
              @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected,
                    boolean cellHasFocus) {
                  Component renderer = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                  if (renderer instanceof JLabel && instanceOf(value)) {
                      return setChildView((JLabel) renderer, convertInstanceOfObject(value,T));
                  }
                  return renderer;
            }
    }
    */

}
