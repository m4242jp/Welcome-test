package asia.uniuni.model;

import java.io.Serializable;

import com.opencsv.bean.CsvBindByName;

public class SimpleAncer  implements Serializable {

    @CsvBindByName
    private String radio1;

    @CsvBindByName
    private String select1;

    @CsvBindByName
    private String select2;

    @CsvBindByName
    private String textarea1;

    public String getRadio1() {
        return radio1;
    }

    public String getSelect1() {
        return select1;
    }

    public String getSelect2() {
        return select2;
    }

    public String getTextarea1() {
        return textarea1;
    }

}
