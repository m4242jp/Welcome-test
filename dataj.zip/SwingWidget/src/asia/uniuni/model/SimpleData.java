package asia.uniuni.model;

public class SimpleData {
    private String title;
    private String sub;

    public SimpleData(String title,String sub){
        this.title = title;
        this.sub = sub;
    }

    public String getTitle() {
        return title;
    }

    public String getSub() {
        return sub;
    }
}
