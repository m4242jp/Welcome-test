package application;

import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {

	       // URL fxml = getClass().getResource(getClass().getSimpleName() + ".fxml");
            URL fxml = getClass().getResource("/resouce/view/main.fxml");
	        ResourceBundle  resources   = ResourceBundle.getBundle("resouce/values/string", Locale.JAPAN );

	        FXMLLoader ldr = new FXMLLoader(fxml, resources);

	        //fxml側でロードするならいらない
	      //  ldr.setController(this);

	        // FXMLをロードする.
	        Parent root = ldr.load();
	        Scene scene = new Scene(root);

            primaryStage.setTitle("AAAAAAAA");
	        primaryStage.setScene(scene);
            primaryStage.show();
/*
		    Label label = new Label("This is JavaFX!");

			BorderPane root = new BorderPane();
			root.setCenter(label);

			Scene scene = new Scene(root,400,400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.setTitle("AAAAAAAA");
			primaryStage.show();
			*/
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}

}
