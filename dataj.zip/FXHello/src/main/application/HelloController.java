package application;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;


public class HelloController implements Initializable {
    @FXML private Button helloButton;
    @FXML private Label  helloLabel;
    @FXML private ListView<String>  listView;

    private ObservableList<String> listRecords = FXCollections.observableArrayList();

    private void fillTypeListView(){
        List<String> datas = new ArrayList<>();

        for(int i = 0; i<100; i++){
            datas.add( i + " : Data xxxxxxxxxxxxxxxxxxx ");
        }
        for(String category:datas){
            listRecords.add(category);
        }
        if(listView != null){
            listView.setItems(listRecords);
            listView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
            listView.setOnMouseClicked((MouseEvent)->{
                // 実行する処理
                Object obj = listView.getSelectionModel().getSelectedItem();
                System.out.println(obj);
                listRecords.remove(obj);
                listView.getSelectionModel().clearSelection();
            });
        }
    }

    private int cnt;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        fillTypeListView();
    }
    @FXML
    public void onHelloButtonClicked(ActionEvent event) {
        this.helloLabel.setText("clicked! : " + cnt);
        cnt++;
    }


}
