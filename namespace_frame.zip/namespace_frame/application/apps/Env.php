<?php

namespace Apps;

class Env
{
    const SESSION_NAME = '__doing';

    const USER_NAME_MAX_SIZE = 30;
    const PASSWORD_MIN_SIZE = 8;
    const PASSWORD_MAX_SIZE = 40;

    const PROJECT_PAGE_LIMIT = 25;
    const TASK_PAGE_LIMIT = 25;

    const ADMIN_PROJECT_PAGE_LIMIT = 50;

    const PROJECT_PAGE_TITLE_MAX_LENGTH = 25;
    const PROJECT_PAGE_SUMMARY_MAX_LENGTH = 2000;
    const TASK_PAGE_TITLE_MAX_LENGTH = 25;
    const TASK_PAGE_SUMMARY_MAX_LENGTH = 2000;
    const THREAD_MAX_LENGTH = 1000;




    const TASK_PAGE_SORT_TYPE = array(
        'project_name' => 'project',
          'handle_name' => 'handle',
          'category_id' => 'category',
            'task_name' => 'task',
          'schedule' => 'schedule',
          'update_date' => 'date',
          'status_id' => 'status',
         'priority_id' => 'priority'
        );
}
