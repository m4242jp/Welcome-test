<?php


class Sample
{
    public function __construct()
    {
    }


    public function call(){
        echo "Sample call!!";
    }
}
