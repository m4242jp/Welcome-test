<?php

namespace MyLibs;

use Apps\Env;

class Utility
{
    public function __construct()
    {
    }


    public function createPager($page_no,$page_count,$page_limit)
    {

        $pager = array();
        if (!$page_no || !is_numeric($page_no)) {
            $pager['page_no'] = 1;
        } else {
            $no = intval($page_no);
            $pager['page_no'] = $no < 1 ? 1 : $no;
        }
        $pager['view_count'] = $page_limit;
        $pager['record_count'] = intval($page_count);
        $pager['pages'] = ceil($pager['record_count'] / $pager['view_count']);
        $pager['offset_pages'] = $pager['page_no'] - 1;
        $pager['offset_records'] = $pager['offset_pages'] * $pager['view_count'];

        //$pager['last_offset'] = ($pager['pages'] -1) * $pager['view_count'];
        if ($pager['pages'] <= $pager['page_no']) {
            $pager['now_offset'] = $pager['page_no'] === 1 ? 0 : (($pager['pages'] - 1) * $pager['view_count']) + 1;
            $pager['now_offset_limit'] = $pager['now_offset'] + $pager['view_count'] - 1;
            $pager['start_no'] = $pager['now_offset'];
            $pager['end_no'] = $pager['record_count'];
            $pager['prev_page_no'] = $pager['page_no'] - 1; //ページが1ならfalseになる
            $pager['next_page_no'] = false;
        }else if ($pager['offset_pages'] === 0) {
            $pager['now_offset'] = 0;
            $pager['now_offset_limit'] = $pager['now_offset'] + $pager['view_count'];
            $pager['start_no'] = 1;
            $pager['end_no'] = $pager['now_offset_limit'];
            $pager['prev_page_no'] = false;
            $pager['next_page_no'] = 2;
        } else {
            $pager['now_offset'] = $pager['offset_records'] + 1;
            $pager['now_offset_limit'] = $pager['now_offset'] + $pager['view_count'] - 1;
            $pager['start_no'] = $pager['now_offset'];
            $pager['end_no'] = $pager['now_offset_limit'];
            $pager['prev_page_no'] = $pager['page_no'] - 1;
            $pager['next_page_no'] = $pager['page_no'] + 1;
        }

        return $pager;
    }

    public function createTaskSortUrl($sort='schedule',$desc=true)
    {

        $sorts = array();
        foreach (Env::TASK_PAGE_SORT_TYPE as $key => $value) {
            if($value === $sort){
                $sorts[$value] = $desc ? 'sort=' . $value . '&desc=0' : 'sort=' . $value . '&desc=1';
            }else{
                $sorts[$value] = 'sort=' . $value . '&desc=0';
            }
        }

        return $sorts;
    }


    public function makeRandStr($length = 8) {
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJLKMNOPQRSTUVWXYZ0123456789';
        $str = '';
        for ($i = 0; $i < $length; ++$i) {
            $str .= $chars[mt_rand(0, 61)];
        }
        return $str;
    }
}
