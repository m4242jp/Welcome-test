<?php

namespace Framework\Core;

abstract class Application
{

    protected $debug = false;

    protected $request;

    protected $response;

    protected $session;

    protected $db_manager;

    protected $login_action = array();

    protected $invalid_action = array();

    protected $cookie;

    // protected $router;
    public function __construct($debug = false)
    {
        $this->setDebugMode($debug);
        $this->initialize();
        $this->configure();
    }

    public function setDebugMode($debug)
    {
        if ($debug) {
            $this->debug = true;
            ini_set('display_errors', 1);
            error_reporting(- 1);
        } else {
            $this->debug = false;
            ini_set('display_errors', 0);
        }
    }

    public function initialize()
    {
        $this->request = new Request();
        $this->response = new Response();
        $this->session = new Session();
        $this->cookie = new Cookie();
        $this->db_manager = new DbManager();
        $this->router = new Router($this->registerRoutes());
    }

    public function configure()
    {}

    abstract public function getRootDir();

    abstract public function registerRoutes();

    public function isDebugMode()
    {
        return $this->debug;
    }

    public function getRequest()
    {
        return $this->request;
    }

    public function getResponse()
    {
        return $this->response;
    }

    public function getSession()
    {
        return $this->session;
    }

    public function getDbManager()
    {
        return $this->db_manager;
    }

    public function getCookie()
    {
        return $this->cookie;
    }

    public function getControllerDir()
    {
        return $this->getRootDir() . '/controllers';
    }

    public function getViewDir()
    {
        return $this->getRootDir() . '/views';
    }

    public function getModelDir()
    {
        return $this->getRootDir() . '/models';
    }

    public function getWebDir()
    {
        return $this->getRootDir() . '/web';
    }

    public function getLibDir()
    {
        return $this->getRootDir() . '/mylibs';
    }

    public function run()
    {
        try {
            $params = $this->router->resolve($this->request->getPathInfo());
            if ($params === false) {
                throw new HttpNotFoundException(
                    'No route found for ' . $this->request->getPathInfo());
            }

            $controller = $params['controller'];
            $action = $params['action'];
            $this->runAction($controller, $action, $params);
        } catch (HttpNotFoundException $e) {
            $this->render404($e);
        } catch (UnauthorizedActionException $e) {
            list ($controller, $action) = $this->login_action;
            $this->runAction($controller, $action);
        } catch (UnauthorizedAjaxActionException $e) {
            $this->renderAjaxError($e);
        } catch (InvalidUserAccessActionException $e) {
           // list ($controller, $action) = $this->invalid_action;
           // $this->runAction($controller, $action);
            $this->session->clear();
            $this->session->setAuthenticated(false);
            $this->render400($e);
        }

        $this->response->send();
    }

    // 対応するコントローラを取得する
    public function runAction($controller_name, $action, $params = array())
    {
        $controller_class = ucfirst($controller_name) . 'Controller';
        $controller = $this->findController($controller_class);

        if ($controller === false) {
            // todo-B
            throw new HttpNotFoundException($controller_class . ' controller is not found.');
        }

        $content = $controller->run($action, $params);
        $this->response->setContent($content);
    }

    // コントローラを検索する
    public function findController($controller_class)
    {
        $controller_class_for_name = 'Controllers\\' . $controller_class;
         if (! class_exists($controller_class_for_name)) {

            $controller_file = $this->getControllerDir() . '/' . $controller_class . '.php';
            if (! is_readable($controller_file)) {
                return false;
            }

        }
        return new $controller_class_for_name($this);
        /*
        if (! class_exists($controller_class)) {

            $controller_file = $this->getControllerDir() . '/' . $controller_class . '.php';
            if (! is_readable($controller_file)) {
                return false;
            } else {
                $controller_class_for_name = 'Controllers\\' . $controller_class;
                $controller = new $controller_class_for_name($this);

                //return $controller;

               require_once $controller_file;
                if (! class_exists($controller_class)) {
                    return false;
                }

            }

        }
        return new $controller_class($this);
        */
    }

    public function render404($e)
    {
        $this->response->setStatusCode(404, 'Not Found');
        $message = $this->isDebugMode() ? $e->getMessage() : 'Page not found.';
        $message = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');

        $this->response->setContent(
            <<<EOF
            <!DOCTYPE html>
            <html>
            <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width,initial-scale=1">
            <title>ERROR</title>
            </head>
            <body>
                {$message}
            </body>
            </html>
EOF
);
    }


    public function renderAjaxError($e)
    {
        $this->response->setStatusCode(404, 'Not Found');
        $message = $this->isDebugMode() ? $e->getMessage() : 'Page not found.';
        $message = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');

        $this->response->setContent(
            <<<EOF
            <!DOCTYPE html>
            <html>
            <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width,initial-scale=1">
            <title>404</title>
            </head>
            <body>
                {$message}
            </body>
            </html>
EOF
);
    }

     public function render400($e)
    {
        $this->response->setStatusCode(400 , 'Bad Request');
        $message = $this->isDebugMode() ? $e->getMessage() : 'Page not found.';
        $message = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');

        $this->response->setContent(
            <<<EOF
            <!DOCTYPE html>
            <html>
            <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width,initial-scale=1">
            <title>400</title>
            </head>
            <body>
                {$message}
            </body>
            </html>
EOF
);
    }
}