<?php

namespace Framework\Core;

class Request
{

    public function getBaseUrl()
    {
        $script_name = $_SERVER['SCRIPT_NAME'];
        $request_uri = $this->getRequestUri();

        if (0 === strpos($request_uri, $script_name)) {
            return $script_name;
        } else if (0 === strpos($request_uri, dirname($script_name))) {
            return rtrim(dirname($script_name), "/");
        }
        return '';
    }

    public function getPathInfo()
    {
        $base_url = $this->getBaseUrl();
        $request_uri = $this->getRequestUri();

        // 末尾/の除去
        if ('/' === substr($request_uri, -1)) {
            $request_uri = rtrim($request_uri,"/");
        }

        // getパラメータの除去
        if (false !== ($pos = strpos($request_uri, '?'))) {
            $request_uri = substr($request_uri, 0, $pos);
        }

        $path_info = (string) substr($request_uri, strlen($base_url));
        return $path_info;
    }

    public function isPost()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            return true;
        }
        return false;
    }

    public function getGet($name, $defalut = null)
    {
        if (isset($_GET[$name])) {
            return $_GET[$name];
        }
        return $defalut;
    }

    public function getPost($name, $defalut = null)
    {
        if (isset($_POST[$name])) {
            return $_POST[$name];
        }
        return $defalut;
    }

    public function getHost()
    {
        if (! empty($_SERVER['HTTP_HOST'])) {
            return $_SERVER['HTTP_HOST'];
        }
        return $_SERVER['SERVER_NAME'];
    }

    public function isSsl()
    {
        if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
            return true;
        }
        return false;
    }

    public function getRequestUri()
    {
        return $_SERVER['REQUEST_URI'];
    }

    public function getAccept()
    {
        return $_SERVER['HTTP_ACCEPT'];
    }

    public function getAcceptLanguage()
    {
        return $_SERVER['HTTP_ACCEPT_LANGUAGE'];
    }

    public function getUserAgent()
    {
        return $_SERVER['HTTP_USER_AGENT'];
    }
}