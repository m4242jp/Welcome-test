<?php

namespace Framework\Core;

use Exception;

class UnauthorizedActionException extends Exception
{
}