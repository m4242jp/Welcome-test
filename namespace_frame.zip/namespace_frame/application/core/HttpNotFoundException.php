<?php

namespace Framework\Core;

use Exception;

class HttpNotFoundException extends Exception
{
}