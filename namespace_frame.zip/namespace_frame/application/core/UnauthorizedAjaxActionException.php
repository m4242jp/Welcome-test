<?php

namespace Framework\Core;

use Exception;

class UnauthorizedAjaxActionException extends Exception
{
}