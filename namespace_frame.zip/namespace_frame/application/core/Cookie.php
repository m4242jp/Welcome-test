<?php

namespace Framework\Core;


class Cookie
{

    protected $cookie_expire_time;
    protected $cookie_path;
    protected $cookie_domain;


    public function __construct()
    {

     $cookie_expire_time  = time() + 3600 * 24 * 7;
     $cookie_path  = '/';
     $cookie_domain  = $_SERVER['SERVER_NAME'];
    }

    public function set($name, $value)
    {
        setcookie($name, $value, $this->cookie_expire_time,$this->cookie_path ,$this->cookie_domain);
    }

    public function get($name, $default = null)
    {
        if (isset($_COOKIE[$name])) {
            return $_COOKIE[$name];
        }
        return $default;
    }

    public function remove($name)
    {
        setcookie($name, '', time() - 1800);
    }


/*
    public function checkAuthToken($token)
    {
        $code = $this->get('verification');
        return !$code !== false && password_verify($this->createVerificationCode($token),$code);
    }

    public function generateAuthToken($key)
    {
        return password_hash(hash('sha512', $key, true), PASSWORD_DEFAULT);
    }
*/
}