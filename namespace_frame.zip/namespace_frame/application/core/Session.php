<?php

namespace Framework\Core;

use Apps\Env;

class Session
{

    protected static $sessionStarted = false;

    protected static $sessionIdRegenerated = false;

    public function __construct()
    {
        if (! self::$sessionStarted) {
            header('X-FRAME-OPTIONS: SAMEORIGIN');

            session_name(Env::SESSION_NAME);
            session_start();

            //クライアントにキャッシュさせない
            header('Expires:-1');
            header('Cache-Control:');
            header('Pragma:');
            self::$sessionStarted = true;
        }
    }

    public function set($name, $value)
    {
        $_SESSION[$name] = $value;
    }

    public function get($name, $default = null)
    {
        if (isset($_SESSION[$name])) {
            return $_SESSION[$name];
        }
        return $default;
    }

    public function remove($name)
    {
        unset($_SESSION[$name]);
    }

    public function clear()
    {
        $_SESSION = array();
    }

    public function regenerate($destroy = true)
    {
        if (! self::$sessionIdRegenerated) {
            session_regenerate_id($destroy);

            self::$sessionIdRegenerated = true;
        }
    }

    public function setAuthenticated($bool)
    {
        $this->set('_authenticated', (bool) $bool);

        $this->set('_verification', $this->createVerificationCode());

        $this->regenerate();
    }

    public function isAuthAndVerification()
    {
        return $this->isAuthenticated() && $this->isVerification();
    }

    public function isAuthenticated()
    {
        return $this->get('_authenticated', false);
    }

    public function isVerification()
    {
        return $this->get('_verification', null) === $this->createVerificationCode();
    }

    public function createVerificationCode()
    {
        $string = str_replace(array(
            " ",
            "　"
        ), "",
            $_SERVER['REMOTE_ADDR'] . $_SERVER['HTTP_USER_AGENT']);
        return sha1($string);
    }


    public function getLoginName($default = null)
    {
        if (isset($_SESSION['user']) && isset($_SESSION['user']['show_name'])) {
            return $_SESSION['user']['show_name'];
        }
        return $default;
    }
    public function isAdministratorLevel($default = false)
    {
        if (isset($_SESSION['user']) && isset($_SESSION['user']['admin'])) {
            return $_SESSION['user']['admin'];
        }
        return $default;
    }
    public function isDeveloperLevel($default = false)
    {
        if (isset($_SESSION['user']) && isset($_SESSION['user']['develop'])) {
            return $_SESSION['user']['develop'];
        }
        return $default;
    }
    public function isManagerLevel($default = false)
    {
        if (isset($_SESSION['user']) && isset($_SESSION['user']['manage'])) {
            return $_SESSION['user']['manage'];
        }
        return $default;
    }
    public function setToasts($toasts)
    {
        $this->set('toasts',$toasts);
    }
    public function getToasts()
    {
        if(isset($_SESSION['toasts'])){
            $tmp_t = $this->get('toasts');
            $this->remove('toasts');
            return  $tmp_t;
        }
        return null;
    }

}