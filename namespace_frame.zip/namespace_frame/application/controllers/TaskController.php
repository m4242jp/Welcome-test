<?php

namespace Controllers;

use Framework\Core\Controller;
use MyLibs\Utility;
use Apps\Env;

class TaskController extends Controller
{
    protected $auth_actions = array(
        'index',
        'newTask',
        'postNewTask',
        'upNewTask',
        'detail',
        'edit',
        'editUpdate',
        'editSave',
        'removeTask',
        'statusChange',
        'postthread',
        'changeThread'

        );

    public function checkDatetimeFormat($date)
    {
        list($Y, $m, $d) = explode('-', $date);
        if (checkdate($m, $d, $Y) === true) {
            return true;
        } else {
            return false;
        }
          //return $datetime === date("Y-m-d H:i:s", strtotime($datetime));
    }

    public function equalDatetime($date1, $date2, $format = 'Y-m-d')
    {

        if (!$date1) {
            return !$date2 ? true : false;
        } else {
            if (!$date2) {
                return false;
            }
            return $date1->format($format) === $date2->format($format);
        }
    }

    public function indexAction($params)
    {
        $user = $this->session->get('user');
        if (! $user) {
            return $this->forward404();
        }
        //プロジェクトがなければホームへ
        if (! isset($params['project_no'])) {
            return $this->redirect('/');
        }
        $project_repository = $this->db_manager->get('Project');
        $project = $project_repository->fetchByProjectId($params['project_no']);
        if (! $project) {
            return $this->redirect('/');
        }
        //参加中チェック　マネージャー権限以上は閲覧は可能
        $isMember = $project_repository->isJoinProjectUser($project['project_id'], $user['user_id']);
        if (!$isMember && !$this->session->isManagerLevel()) {
            return $this->redirect('/readingerror');
        }

        $task_page_no = $this->request->getGet('tno','1');
        $task_page_sort = $this->request->getGet('sort','schedule');
        $task_page_desc = $this->request->getGet('desc',true);
        $task_repository = $this->db_manager->get('Task');
        $util = new Utility();
        $tasks_count = $task_repository->fetchCountAllTaskByProjectId($project['project_id']);
        $tasks_pager = $util->createPager($task_page_no,$tasks_count['count'],Env::TASK_PAGE_LIMIT);
        $tasks = $task_repository->fetchAllTaskByProjectId($project['project_id'],$tasks_pager['offset_records'],$tasks_pager['view_count'],!$task_page_sort ? 'schedule' : $task_page_sort,$task_page_desc);



        //var_dump($tasks_pager);
        //$tasks = $this->db_manager->get('Task')->fetchAllByProjectId($params['project_no']);
        $isJoinManage = $project_repository->isJoinProjectMangeUser($project['project_id'], $user['user_id']);
        $join_users = $project_repository->fetchAllJoinUserByProjectId($project['project_id']);
        $task_sort_url = $util->createTaskSortUrl($task_page_sort,$task_page_desc);

        return $this->render(
            array(
                'project' => $project,
                'isJoinManage' => $isJoinManage,
                'tasks_pager' => $tasks_pager,
                'tasks' => $tasks,
                'join_users' => $join_users,
                'task_sort_url'=> $task_sort_url,
                'task_sort'=> $task_page_sort,
                'task_desc'=> $task_page_desc,
                'task_title' => '',
                'task_summary' => '',
                'schedule' => '',
                'handle_user_id' => '',
                'isMember' => $isMember,
                'admin' => $this->session->isAdministratorLevel()
            )
        );
    }

    public function newTaskAction($params)
    {

         $user = $this->session->get('user');
        if (! $user) {
            return $this->forward404();
        }
        //プロジェクトがなければホームへ
        if (! isset($params['project_no'])) {
            return $this->redirect('/');
        }
        $project_repository = $this->db_manager->get('Project');
        $project = $project_repository->fetchByProjectId($params['project_no']);
        if (! $project) {
            return $this->redirect('/');
        }
        //参加中チェック
        if (! $project_repository->isJoinProjectUser($project['project_id'], $user['user_id']) && !$this->session->isAdministratorLevel()) {
            return $this->redirect('/readingerror');
        }


        $task_title = $this->request->getPost('task_title', '');
        $task_summary = $this->request->getPost('task_summary', '');
        $schedule = $this->request->getPost('schedule', '');
        $handle_user_id = $this->request->getPost('handle_user_id', '');
        $priority_id = $this->request->getPost('priority_id', '3');
        $category_id = $this->request->getPost('category_id', '10');

        $join_users = $project_repository->fetchAllJoinUserByProjectId($project['project_id']);
        $isJoinManage = $project_repository->isJoinProjectMangeUser($project['project_id'], $user['user_id']);
        $task_repository = $this->db_manager->get('Task');
        $categorys = $task_repository->fetchAllTaskCategory();
        $prioritys = $task_repository->fetchAllTaskPriority();

        return $this->render(
            array(
                'project' => $project,
                'isJoinManage' => $isJoinManage,
                'join_users' => $join_users,
                'prioritys' => $prioritys,
                'categorys' => $categorys,

                'task_title' => $task_title,
                'task_summary' => $task_summary,
                'schedule' => $schedule,
                'handle_user_id' => $handle_user_id,
                        'priority_id' => $priority_id,
                        'category_id' => $category_id,
                '_token' => $this->generateCsrfToken('tasks/post'),
            ),
            'new_task'
        );
    }

    public function postNewTaskAction($params)
    {
        if (! $this->request->isPost()) {
            return $this->forward404();
        }

        $token = $this->request->getPost('_token');
        if (! $this->checkCsrfToken('tasks/post', $token)) {
            return $this->redirect('/prj/' . $params['project_no']. '/tasks');
        }

        if (! isset($params['project_no'])) {
            return $this->redirect('/');
        }

        $user = $this->session->get('user');
        if (! $user) {
            return $this->forward404();
        }

        $project_repository = $this->db_manager->get('Project');
        $project = $project_repository->fetchByProjectId($params['project_no']);
        if (! $project) {
            return $this->redirect('/');
        }
        //参加中チェック
        if (! $project_repository->isJoinProjectUser($project['project_id'], $user['user_id']) && !$this->session->isAdministratorLevel()) {
            return $this->redirect('/readingerror');
        }


        $errors = array();
        $task_repository = $this->db_manager->get('Task');
        $task_title = $this->request->getPost('task_title');
        $task_summary = $this->request->getPost('task_summary');
        $schedule = $this->request->getPost('schedule');
        $handle_user_id = $this->request->getPost('handle_user_id');
        $priority_id = $this->request->getPost('priority_id');
        $category_id = $this->request->getPost('category_id');
        $handle_user_name = '未設定';
        $schedule_date = null;
        $handle_id = null;
        $priority = null;
        $category = null;


        if (!strlen($task_title)) {
            $errors[] = 'タイトルを入力してください';
        } elseif (mb_strlen($task_title) > Env::TASK_PAGE_TITLE_MAX_LENGTH) {
            $errors[] = 'タイトルは' . Env::TASK_PAGE_TITLE_MAX_LENGTH . '文字以内で入力してください';
        }
        if (! strlen($task_summary)) {
            $errors[] = '内容を入力してください';
        } else if (mb_strlen($task_summary)-substr_count($task_summary, "\n") > Env::TASK_PAGE_SUMMARY_MAX_LENGTH) {
            $errors[] = '内容は' . Env::TASK_PAGE_SUMMARY_MAX_LENGTH . '文字以内で入力してください';
        }


        if (! strlen($category_id)) {
            $errors[] = '分類を選択してください';
        } else {
            $category = $task_repository->fetchByCategoryId($category_id) ;
            if (!$category) {
                $errors[] = '分類を選択してください';
            }
        }

        if (!strlen($priority_id)) {
            $priority_id = '3';
        } else {
            $priority = $task_repository->fetchByPriorityId($priority_id);
            if (!$priority) {
                $errors[] = '優先度を選択してください';
            }
        }

        if (strlen($schedule)) {
            $schedule_date = DateTime::createFromFormat('Y-m-d', $schedule);
            $now_time = new DateTime();
            if (!$schedule_date || !$this->checkDatetimeFormat($schedule_date->format("Y-m-d"))) {
                $errors[] = '日付の形式が正しくないようです再度選択してください';
            } else if ($now_time > $schedule_date) {
                $errors[] = '過去の日付は選択できません';
            }
        }

        if (strlen($handle_user_id)) {
            $handle_user = $this->db_manager->get('Account')->fetchByUserId($handle_user_id);
            if (! $handle_user) {
                $errors[] = '担当できるユーザーが見つかりません';
            } else {
                $handle_user_name = $handle_user['show_name'];
            }
        }



        if (count($errors) === 0) {
                return $this->render(
                    array(
                        'project' => $project,
                        'task_title' => $task_title,
                        'task_summary' => $task_summary,
                        'schedule' => $schedule,
                        'handle_user_id' => $handle_user_id,
                        'handle_user_name' => $handle_user_name,
                        'priority_id' => $priority_id,
                        'priority_name' => $priority['priority_name'],
                        'category_id' => $category_id,
                        'category_name' => $category['category_name'],
                        '_token' => $this->generateCsrfToken('tasks/post'),
                    ),
                    'new_task_confirm'
                );
        }

        $join_users = $project_repository->fetchAllJoinUserByProjectId($project['project_id']);
        $isJoinManage = $project_repository->isJoinProjectMangeUser($project['project_id'], $user['user_id']);
        $categorys = $task_repository->fetchAllTaskCategory();
        $prioritys = $task_repository->fetchAllTaskPriority();

        return $this->render(
            array(
                'project' => $project,
                'join_users' => $join_users,
                'prioritys' => $prioritys,
                'categorys' => $categorys,
                'isJoinManage' => $isJoinManage,
                'errors' => $errors,
                'task_title' => $task_title,
                'task_summary' => $task_summary,
                'schedule' => $schedule,
                'handle_user_id' => $handle_user_id,
                        'priority_id' => $priority_id,
                        'category_id' => $category_id,
                '_token' => $this->generateCsrfToken('tasks/post'),
            ),
            'new_task'
        );
    }

    public function upNewTaskAction($params)
    {
        if (! $this->request->isPost()) {
            return $this->forward404();
        }

        $token = $this->request->getPost('_token');
        if (! $this->checkCsrfToken('tasks/post', $token)) {
            return $this->redirect('/prj/' . $project['project_id']. '/tasks');
        }

        if (! isset($params['project_no'])) {
            return $this->redirect('/');
        }

        $user = $this->session->get('user');
        if (! $user) {
            return $this->forward404();
        }

        $project_repository = $this->db_manager->get('Project');
        $project = $project_repository->fetchByProjectId($params['project_no']);
        if (! $project) {
            return $this->redirect('/');
        }
        //参加中チェック
        if (! $project_repository->isJoinProjectUser($project['project_id'], $user['user_id']) && !$this->session->isAdministratorLevel()) {
            return $this->redirect('/readingerror');
        }


        $errors = array();
        $task_repository = $this->db_manager->get('Task');
        $task_title = $this->request->getPost('task_title');
        $task_summary = $this->request->getPost('task_summary');
        $schedule = $this->request->getPost('schedule');
        $handle_user_id = $this->request->getPost('handle_user_id');
        $priority_id = $this->request->getPost('priority_id');
        $category_id = $this->request->getPost('category_id');
        $schedule_date = null;
        $handle_id = null;


        if (!strlen($task_title)) {
            $errors[] = 'タイトルを入力してください';
        } elseif (mb_strlen($task_title) > Env::TASK_PAGE_TITLE_MAX_LENGTH) {
            $errors[] = 'タイトルは' . Env::TASK_PAGE_TITLE_MAX_LENGTH . '文字以内で入力してください';
        }
        if (! strlen($task_summary)) {
            $errors[] = '内容を入力してください';
        } else if (mb_strlen($task_summary)-substr_count($task_summary, "\n") > Env::TASK_PAGE_SUMMARY_MAX_LENGTH) {
            $errors[] = '内容は' . Env::TASK_PAGE_SUMMARY_MAX_LENGTH . '文字以内で入力してください';
        }

        if (! strlen($category_id) || !$task_repository->fetchByCategoryId($category_id)) {
            $errors[] = '分類を選択してください';
        }

        if (!strlen($priority_id)) {
            $priority_id = '3';
        } else if (!$task_repository->fetchByPriorityId($priority_id)) {
            $errors[] = '優先度を選択してください';
        }

        if (strlen($schedule)) {
            $schedule_date = DateTime::createFromFormat('Y-m-d', $schedule);
            $now_time = new DateTime();
            if (!$schedule_date || !$this->checkDatetimeFormat($schedule_date->format("Y-m-d"))) {
                $errors[] = '日付の形式が正しくないようです再度選択してください';
            } else if ($now_time > $schedule_date) {
                $errors[] = '過去の日付は選択できません';
            }
        }

        if (strlen($handle_user_id)) {
            if (! $this->db_manager->get('Account')->fetchByUserId($handle_user_id)) {
                $errors[] = '担当できるユーザーが見つかりません';
            }
        }


        if (count($errors) === 0) {
              $user = $this->session->get('user');
              $this->db_manager->get('Task')->insert(
                  $project['project_id'],
                  $task_title,
                  $task_summary,
                  $user['user_id'],
                  $category_id,
                  $priority_id,
                  $schedule_date,
                  $handle_user_id
              );
              $this->session->setToasts(array($task_title . 'を登録しました'));
              return $this->redirect('/prj/' . $params['project_no']. '/tasks');
        }

        $tasks = $this->db_manager->get('Task')->fetchAllByProjectId($project['project_id']);
        $join_users = $project_repository->fetchAllJoinUserByProjectId($project['project_id']);
        $isJoinManage = $project_repository->isJoinProjectMangeUser($project['project_id'], $user['user_id']);
        $categorys = $task_repository->fetchAllTaskCategory();
        $prioritys = $task_repository->fetchAllTaskPriority();

        return $this->render(
            array(
                'project' => $project,
                'tasks' => $tasks,
                'join_users' => $join_users,
                'prioritys' => $prioritys,
                'categorys' => $categorys,
                'isJoinManage' => $isJoinManage,
                'errors' => $errors,
                'task_title' => $task_title,
                'task_summary' => $task_summary,
                'schedule' => $schedule,
                'handle_user_id' => $handle_user_id,
                '_token' => $this->generateCsrfToken('tasks/post'),
            ),
            'new_task'
        );
    }



    public function detailAction($params)
    {

        $user = $this->session->get('user');
        if (! $user) {
            return $this->forward404();
        }

        //プロジェクトがなければホームへ
        if (! isset($params['project_no']) || ! isset($params['task_no'])) {
            return $this->redirect('/');
        }

        $project_repository = $this->db_manager->get('Project');
        $project = $project_repository->fetchByProjectId($params['project_no']);
        if (! $project) {
            return $this->redirect('/');
        }
        //参加中チェック　マネージャー権限以上は閲覧は可能
        $isMember = $project_repository->isJoinProjectUser($project['project_id'], $user['user_id']);
        if (!$isMember && !$this->session->isManagerLevel()) {
            return $this->redirect('/');
        }
        $task_repository = $this->db_manager->get('Task');
        $task = $task_repository->fetchByTaskId($params['task_no']);

        if (! $task) {
            return $this->redirect('/prj/' . $project['project_id']);
        }

        $threads = $task_repository->fetchAllTaskThreadByTaskId($task['task_id'], $user['user_id']);
        $join_users = $project_repository->fetchAllJoinUserByProjectId($project['project_id']);
        $isJoinManage =  $task['create_user_id'] ===  $user['user_id']  || $project_repository->isJoinProjectMangeUser($project['project_id'], $user['user_id']);
        $task_statuses = $task_repository->fetchAllTaskStatus();
        $prioritys = $task_repository->fetchAllTaskPriority();

        return $this->render(
            array(
                'project' => $project,
                'task' => $task,
                'threads' => $threads,
                'join_users' => $join_users,
                'isJoinManage' => $isJoinManage,
                'task_statuses' => $task_statuses,
                'prioritys' => $prioritys,
                'schedule' => $task['schedule'],
                'handle_user_id' => $task['handle_user_id'],
                'status_id' => $task['status_id'],
                'priority_id' => $task['priority_id'],
                'thread_body' => '',
                'is_active_info' => false,
                'is_active_thread' => false,
                'isMember' => $isMember,
                'admin' => $this->session->isAdministratorLevel(),
                '_token' => $this->generateCsrfToken('tasks/threadpost'),
            )
        );
    }

    public function editAction($params)
    {

         $user = $this->session->get('user');
        if (! $user) {
            return $this->forward404();
        }
        //プロジェクトがなければホームへ
        if (! isset($params['project_no'])) {
            return $this->redirect('/');
        }
        $project_repository = $this->db_manager->get('Project');
        $project = $project_repository->fetchByProjectId($params['project_no']);
        if (! $project) {
            return $this->redirect('/');
        }
        //参加中チェック
        if (! $project_repository->isJoinProjectUser($project['project_id'], $user['user_id'])  && !$this->session->isAdministratorLevel()) {
            return $this->redirect('/readingerror');
        }

        $task_repository = $this->db_manager->get('Task');
        $task = $task_repository->fetchByTaskId($params['task_no']);

        if (! $task) {
            return $this->redirect('/prj/' . $project['project_id']);
        }

        $task_title = $this->request->getPost('task_title', $task['task_name']);
        $task_summary = $this->request->getPost('task_summary', $task['task_summary']);
        $category_id = $this->request->getPost('category_id', $task['category_id']);

        $join_users = $project_repository->fetchAllJoinUserByProjectId($project['project_id']);
        $isJoinManage = $project_repository->isJoinProjectMangeUser($project['project_id'], $user['user_id']);
        $categorys = $task_repository->fetchAllTaskCategory();

        return $this->render(
            array(
                'project' => $project,
                'task' => $task,
                'isJoinManage' => $isJoinManage,
                'join_users' => $join_users,
                'task_title' => $task_title,
                'task_summary' => $task_summary,
                'category_id' => $category_id,
                'categorys' => $categorys,
                'is_removed' => $task['create_user_id'] === $user['user_id'] ||  $isJoinManage || $this->session->isAdministratorLevel(),
                '_token' => $this->generateCsrfToken('tasks/edit'),
            ),
            'edit_task'
        );
    }

    public function editUpdateAction($params)
    {

        if (! $this->request->isPost()) {
            return $this->forward404();
        }

         $user = $this->session->get('user');
        if (! $user) {
            return $this->forward404();
        }


        $token = $this->request->getPost('_token');
        if (! $this->checkCsrfToken('tasks/edit', $token)) {
            return $this->redirect('/prj/' . $params['project_no'] . '/tasks/' . $params['task_no']);
        }


        //プロジェクトがなければホームへ
        if (! isset($params['project_no'])) {
            return $this->redirect('/');
        }
        $project_repository = $this->db_manager->get('Project');
        $project = $project_repository->fetchByProjectId($params['project_no']);
        if (! $project) {
            return $this->redirect('/');
        }

        //参加中チェック
        if (! $project_repository->isJoinProjectUser($project['project_id'], $user['user_id']) && !$this->session->isAdministratorLevel()) {
            return $this->redirect('/readingerror');
        }

        $task_repository = $this->db_manager->get('Task');
        $task = $task_repository->fetchByTaskId($params['task_no']);

        if (! $task) {
            return $this->redirect('/prj/' . $project['project_id']);
        }

        $errors = array();
        $action = $this->request->getPost('action');
        $task_title = $this->request->getPost('task_title');
        $task_summary = $this->request->getPost('task_summary');
        $category_id = $this->request->getPost('category_id');

        $join_users = $project_repository->fetchAllJoinUserByProjectId($project['project_id']);
        $isJoinManage = $project_repository->isJoinProjectMangeUser($project['project_id'], $user['user_id']);
        $categorys = $task_repository->fetchAllTaskCategory();

        switch ($action) {
            case 'update':

                if (!strlen($task_title)) {
                    $errors[] = 'タイトルを入力してください';
                } elseif (mb_strlen($task_title) > Env::TASK_PAGE_TITLE_MAX_LENGTH) {
                    $errors[] = 'タイトルは' . Env::TASK_PAGE_TITLE_MAX_LENGTH . '文字以内で入力してください';
                }
                if (! strlen($task_summary)) {
                    $errors[] = '内容を入力してください';
                } else if (mb_strlen($task_summary)-substr_count($task_summary, "\n") > Env::TASK_PAGE_SUMMARY_MAX_LENGTH) {
                    $errors[] = '内容は' . Env::TASK_PAGE_SUMMARY_MAX_LENGTH . '文字以内で入力してください';
                }
                if (! strlen($category_id)) {
                    $errors[] = '分類を選択してください';
                } else {
                    $category = $task_repository->fetchByCategoryId($category_id) ;
                    if (!$category) {
                        $errors[] = '分類を選択してください';
                    }
                }

                if ($task_title === $task['task_name'] && $task_summary === $task['task_summary'] && $category_id === $task['category_id']) {
                    $errors[] = '変更箇所がありません';
                }
                return $this->render(
                    array(
                        'project' => $project,
                        'task' => $task,
                        'isJoinManage' => $isJoinManage,
                        'join_users' => $join_users,
                        'categorys' => $categorys,
                        'errors' => $errors,
                        'task_title' => $task_title,
                        'task_summary' => $task_summary,
                        'category_name' => isset($category) ?  $category['category_name'] :'',
                        'category_id' => $category_id,
                        'is_removed' => $task['create_user_id'] === $user['user_id'] ||  $isJoinManage || $this->session->isAdministratorLevel(),
                        '_token' => $this->generateCsrfToken('tasks/edit'),
                    ),
                    count($errors) === 0 ? 'edit_task_confirm' : 'edit_task'
                );
                break;
            case 'remove':
                    //管理者で参加中か作成者以外は不正
                if (!$project_repository->isJoinProjectMangeUser($project['project_id'], $user['user_id']) && $task['create_user_id'] !== $user['user_id'] && !$this->session->isAdministratorLevel()) {
                    $this->session->setToasts(array('削除権限がありません'));
                    return $this->redirect('/prj/' . $project['project_id']. '/tasks');
                }

                return $this->render(
                    array(
                        'project' => $project,
                        'task' => $task,
                        'isJoinManage' => $isJoinManage,
                        'join_users' => $join_users,
                        'task_title' => $task['task_name'],
                        'task_summary' => $task['task_summary'],
                        'category_name' => $task['category_name'],
                        'is_removed' => $task['create_user_id'] === $user['user_id'] ||  $isJoinManage || $this->session->isAdministratorLevel(),
                        '_token' => $this->generateCsrfToken('tasks/edit'),
                        ),
                    'remove_task_confirm'
                );
                break;
        }
        return $this->redirect('/');
    }

    public function editSaveAction($params)
    {

        if (! $this->request->isPost()) {
            return $this->forward404();
        }

         $user = $this->session->get('user');
        if (! $user) {
            return $this->forward404();
        }


        $token = $this->request->getPost('_token');
        if (! $this->checkCsrfToken('tasks/edit', $token)) {
            return $this->redirect('/prj/' . $params['project_no'] . '/tasks/' . $params['task_no']);
        }


        //プロジェクトがなければホームへ
        if (! isset($params['project_no'])) {
            return $this->redirect('/');
        }
        $project_repository = $this->db_manager->get('Project');
        $project = $project_repository->fetchByProjectId($params['project_no']);
        if (! $project) {
            return $this->redirect('/');
        }

        //参加中チェック
        if (! $project_repository->isJoinProjectUser($project['project_id'], $user['user_id']) && !$this->session->isAdministratorLevel()) {
            return $this->redirect('/readingerror');
        }

        $task_repository = $this->db_manager->get('Task');
        $task = $task_repository->fetchByTaskId($params['task_no']);

        if (! $task) {
            return $this->redirect('prj/' . $project['project_id']);
        }

        $errors = array();
        $task_title = $this->request->getPost('task_title');
        $task_summary = $this->request->getPost('task_summary');
        $category_id = $this->request->getPost('category_id');


        if (!strlen($task_title)) {
            $errors[] = 'タイトルを入力してください';
        } elseif (mb_strlen($task_title) > Env::TASK_PAGE_TITLE_MAX_LENGTH) {
            $errors[] = 'タイトルは' . Env::TASK_PAGE_TITLE_MAX_LENGTH . '文字以内で入力してください';
        }
        if (! strlen($task_summary)) {
            $errors[] = '内容を入力してください';
        } else if (mb_strlen($task_summary)-substr_count($task_summary, "\n") > Env::TASK_PAGE_SUMMARY_MAX_LENGTH) {
            $errors[] = '内容は' . Env::TASK_PAGE_SUMMARY_MAX_LENGTH . '文字以内で入力してください';
        }

        if (! strlen($category_id) || !$task_repository->fetchByCategoryId($category_id)) {
            $errors[] = '分類を選択してください';
        }
        if ($task_title === $task['task_name'] && $task_summary === $task['task_summary'] && $category_id === $task['category_id']) {
            $errors[] = '変更箇所がありませんでした';
        }


        if (count($errors) === 0) {
              $task_repository->updateTaskDetail(
                  $task['task_id'],
                  $task_title,
                  $task_summary,
                  $category_id
              );
              $task_repository->insertThread($task['task_id'], '内容の編集を行いました', $user['user_id'], true);
              $this->session->setToasts(array('内容を更新しました'));
              return $this->redirect('/prj/' . $params['project_no']. '/tasks/' . $task['task_id']);
        }

        $join_users = $project_repository->fetchAllJoinUserByProjectId($project['project_id']);
        $isJoinManage = $project_repository->isJoinProjectMangeUser($project['project_id'], $user['user_id']);
        $categorys = $task_repository->fetchAllTaskCategory();

        return $this->render(
            array(
                'project' => $project,
                'task' => $task,
                'isJoinManage' => $isJoinManage,
                'join_users' => $join_users,
                        'categorys' => $categorys,
                'errors' => $errors,
                'task_title' => $task_title,
                'task_summary' => $task_summary,
                        'category_id' => $category_id,
                'is_removed' => $task['create_user_id'] === $user['user_id'] ||  $isJoinManage || $this->session->isAdministratorLevel(),
                '_token' => $this->generateCsrfToken('tasks/edit'),
            ),
            'edit_task'
        );
    }


    public function removeTaskAction($params)
    {

        if (! $this->request->isPost()) {
            return $this->forward404();
        }

         $user = $this->session->get('user');
        if (! $user) {
            return $this->forward404();
        }


        $token = $this->request->getPost('_token');
        if (! $this->checkCsrfToken('tasks/edit', $token)) {
            return $this->redirect('/prj/' . $params['project_no'] . '/tasks/' . $params['task_no']);
        }


        //プロジェクトがなければホームへ
        if (! isset($params['project_no'])) {
            return $this->redirect('/');
        }
        $project_repository = $this->db_manager->get('Project');
        $project = $project_repository->fetchByProjectId($params['project_no']);
        if (! $project) {
            return $this->redirect('/');
        }

        $task_repository = $this->db_manager->get('Task');
        $task = $task_repository->fetchByTaskId($params['task_no']);

        if (! $task) {
            return $this->redirect('/prj/' . $project['project_id']);
        }

        //管理者で参加中か作成者以外は不正
        if (!$project_repository->isJoinProjectMangeUser($project['project_id'], $user['user_id']) && $task['create_user_id'] !== $user['user_id']  && !$this->session->isAdministratorLevel()) {
            $this->session->setToasts(array('削除権限がありません'));
            return $this->redirect('/prj/' . $project['project_id']. '/tasks');
        }


        $task_repository->removeTask($task['task_id']);
        $this->session->setToasts(array($task['task_name']."を削除しましたよ"));
        return $this->redirect('/prj/' . $params['project_no']. '/tasks');
    }

    public function statusChangeAction($params)
    {

        if (! $this->request->isPost()) {
            return $this->forward404();
        }

        $token = $this->request->getPost('_token');
        if (! $this->checkCsrfToken('tasks/threadpost', $token)) {
            return $this->redirect('/prj/' . $params['project_no'] . '/tasks/' . $params['task_no']);
        }

        $user = $this->session->get('user');
        if (! $user) {
            return $this->forward404();
        }

        //プロジェクトがなければホームへ　プロジェクトチェックは冗長だけどいったんいれる
        if (! isset($params['project_no']) || ! isset($params['task_no'])) {
            return $this->redirect('/');
        }
        $project_repository = $this->db_manager->get('Project');
        $project = $project_repository->fetchByProjectId($params['project_no']);
        if (! $project) {
            return $this->redirect('/');
        }
        //参加中チェック
        if (! $project_repository->isJoinProjectUser($project['project_id'], $user['user_id']) && !$this->session->isAdministratorLevel()) {
            return $this->redirect('/readingerror');
        }

        $task_repository = $this->db_manager->get('Task');
        $task = $task_repository->fetchByTaskId($params['task_no']);

        if (! $task) {
            return $this->redirect('/prj/' . $project['project_id']);
        }


        $errors = array();
        $priority_id = $this->request->getPost('priority_id');
        $handle_user_id = $this->request->getPost('handle_user_id');
        $schedule = $this->request->getPost('schedule');
        $status_id = $this->request->getPost('status');
        $new_schedule_date = null;

        if (strlen($schedule)) {
            $new_schedule_date = DateTime::createFromFormat('Y-m-d', $schedule);
            $now_time = new DateTime();
            if (!$new_schedule_date || !$this->checkDatetimeFormat($new_schedule_date->format("Y-m-d"))) {
                $errors[] = '日付の形式が正しくないようです再度選択してください';
            } else if ($now_time > $new_schedule_date) {
                $errors[] = '過去の日付は選択できません';
            }
        }
        $new_handle_user=null;
        if (strlen($handle_user_id)) {
            $new_handle_user = $this->db_manager->get('Account')->fetchByUserId($handle_user_id);
            if (! $new_handle_user) {
                 $errors[] = '担当できるユーザーが見つかりません';
            }
        }
        $new_status = false;
        if (strlen($status_id)) {
            $new_status = $task_repository->fetchByStatusId($status_id);
            if (! $new_status) {
                 $errors[] = 'ステイタスが不正です';
            }
        }

        $new_priority_id = false;
        if (strlen($priority_id)) {
            $new_priority_id = $task_repository->fetchByPriorityId($priority_id);
            if (!$new_priority_id) {
                $errors[] = '優先度が不正です';
            }
        }

        if (count($errors) === 0) {
            $updates = array();
            $user = $this->session->get('user');
            $old_schedule_date = !$task['schedule'] ? null : date_create($task['schedule']);

            if (!$this->equalDatetime($new_schedule_date, $old_schedule_date)) {
                $task_repository->updateSchedule($task['task_id'], !$new_schedule_date ? null : $new_schedule_date);
                $old_schedule_msg = !$old_schedule_date ? '未設定' : $old_schedule_date->format('Y-m-d');
                $new_schedule_msg = !$new_schedule_date ? '未設定' : $new_schedule_date->format('Y-m-d');
                $updates[] = 'スケジュールが変更されました ' . $old_schedule_msg . '->' . $new_schedule_msg;
            }
            if (!$new_handle_user) {
                if ($task['handle_user_id']) {
                     $task_repository->updateHandleUserId($task['task_id'], null);
                     $old_handle_user = $this->db_manager->get('Account')->fetchByUserId($task['handle_user_id']);
                    if (!$new_handle_user) {
                          $updates[] = '担当者が変更されました ' . $old_handle_user['show_name']. '->未設定';
                    } else {
                          $updates[] = '担当者が変更されました ' . $old_handle_user['show_name']. '->' . $new_handle_user['show_name'];
                    }
                }
            } else {
                if (!$task['handle_user_id'] ||  $task['handle_user_id'] !== $new_handle_user['user_id']) {
                     $task_repository->updateHandleUserId($task['task_id'], $new_handle_user['user_id']);
                     $old_handle_user = $this->db_manager->get('Account')->fetchByUserId($task['handle_user_id']);
                    if (!$old_handle_user) {
                          $updates[] = '担当者が変更されました 未設定'. '->' . $new_handle_user['show_name'];
                    } else {
                          $updates[] = '担当者が変更されました ' . $old_handle_user['show_name']. '->' . $new_handle_user['show_name'];
                    }
                }
            }

            if ($new_status) {
                if ($task['status_id'] !== $new_status['status_id']) {
                    $task_repository->updateStatus($task['task_id'], $new_status['status_id']);
                    $old_status = $task_repository->fetchByStatusId($task['status_id']);
                    if (!$old_status) {
                        $updates[] = 'ステイタスが変更されました 未設定'. '->' . $new_status['status_name'];
                    } else {
                        $updates[] = 'ステイタスが変更されました ' . $old_status['status_name']. '->' . $new_status['status_name'];
                    }
                }
            }
            if ($new_priority_id) {
                if ($task['priority_id'] !== $new_priority_id['priority_id']) {
                    $task_repository->updatePriority($task['task_id'], $new_priority_id['priority_id']);
                    $old_priority = $task_repository->fetchByPriorityId($task['priority_id']);
                    if (!$old_priority) {
                        $updates[] = 'ステイタスが変更されました 未設定'. '->' . $new_priority_id['priority_name'];
                    } else {
                        $updates[] = 'ステイタスが変更されました ' . $old_priority['priority_name']. '->' . $new_priority_id['priority_name'];
                    }
                }
            }
            foreach ($updates as $value) {
                $task_repository->insertThread($task['task_id'], $value, $user['user_id'], true);
            }
            if (count($updates) !== 0) {
                $this->session->setToasts(array('情報を更新しました'));
                return $this->redirect('/prj/' . $project['project_id'] . '/tasks/' . $task['task_id']);
            } else {
                $this->session->setToasts(array('更新内容はありません'));
            }
        }

        $threads = $task_repository->fetchAllTaskThreadByTaskId($task['task_id'], $user['user_id'], $this->application->isDebugMode());
        $join_users = $project_repository->fetchAllJoinUserByProjectId($project['project_id']);
        $isJoinManage = $project_repository->isJoinProjectMangeUser($project['project_id'], $user['user_id']);
        $task_statuses = $task_repository->fetchAllTaskStatus();
        $prioritys = $task_repository->fetchAllTaskPriority();



        return $this->render(
            array(
                'project' => $project,
                'task' => $task,
                'threads' => $threads,
                'join_users' => $join_users,
                'isJoinManage' => $isJoinManage,
                'task_statuses' => $task_statuses,
                'prioritys' => $prioritys,
                'errors' => $errors,
                'thread_body' => '',
                'priority_id' => $priority_id,
                'schedule' => $schedule,
                'handle_user_id' => $handle_user_id,
                'status_id' => $status_id,
                'is_active_info' => true,
                'is_active_thread' => false,
                '_token' => $this->generateCsrfToken('tasks/threadpost'),
            ),
            'detail'
        );
    }
    public function postthreadAction($params)
    {

        if (! $this->request->isPost()) {
            return $this->forward404();
        }

        $token = $this->request->getPost('_token');
        if (! $this->checkCsrfToken('tasks/threadpost', $token)) {
            return $this->redirect('/prj/' . $params['project_no'] . '/tasks/' . $params['task_no']);
        }

        $user = $this->session->get('user');
        if (! $user) {
            return $this->forward404();
        }

        //プロジェクトがなければホームへ　プロジェクトチェックは冗長だけどいったんいれる
        if (! isset($params['project_no']) || ! isset($params['task_no'])) {
            return $this->redirect('/');
        }
        $project_repository = $this->db_manager->get('Project');
        $project = $project_repository->fetchByProjectId($params['project_no']);
        if (! $project) {
            return $this->redirect('/');
        }

        //参加中チェック
        if (! $project_repository->isJoinProjectUser($project['project_id'], $user['user_id']) && !$this->session->isAdministratorLevel()) {
            return $this->redirect('/readingerror');
        }

        $task_repository = $this->db_manager->get('Task');
        $task = $task_repository->fetchByTaskId($params['task_no']);

        if (! $task) {
            return $this->redirect('/prj/' . $project['project_id']);
        }


        $errors = array();
        $thread_body = $this->request->getPost('thread_body');
        $handle_user_id = $this->request->getPost('handle_user_id');
        $status_id = $this->request->getPost('status');


        if (strlen($thread_body)) {
            if (mb_strlen($thread_body)-substr_count($thread_body, "\n") > Env::THREAD_MAX_LENGTH) {
               $errors[] = Env::THREAD_MAX_LENGTH . '文字以内で入力してください';
            }
        }
        /*
        if (! strlen($thread_body)) {
            $errors[] = 'スレッドの内容を入力してください';
        } else if (mb_strlen($thread_body)-substr_count($thread_body, "\n") > 1000) {
            $errors[] = 'スレッドは1000文字以内で入力してください';
        }
        */

        $new_handle_user=null;
        if (strlen($handle_user_id)) {
            $new_handle_user = $this->db_manager->get('Account')->fetchByUserId($handle_user_id);
            if (! $new_handle_user) {
                 $errors[] = '担当できるユーザーが見つかりません';
            }
        }
        $new_status = false;
        if (strlen($status_id)) {
            $new_status = $task_repository->fetchByStatusId($status_id);
            if (! $new_status) {
                 $errors[] = 'ステイタスが不正です';
            }
        }


        if (count($errors) === 0) {
              $user = $this->session->get('user');
              $result = array();
              if (strlen($thread_body)) {
                    $task_repository->insertThread($task['task_id'], $thread_body, $user['user_id']);
                    $result[] = 'メッセージを書き込みました';
              }
              //$this->session->setToasts(array($task['task_name'] . 'のスレッドに投稿しました'));


            $cangeStatus=false;
            if ($new_status) {
                if ($task['status_id'] !== $new_status['status_id']) {
                    $task_repository->updateStatus($task['task_id'], $new_status['status_id']);
                    $old_status = $task_repository->fetchByStatusId($task['status_id']);
                    if (!$old_status) {
                        $task_repository->insertThread($task['task_id'],
                            'ステイタスが変更されました 未設定'. '->' . $new_status['status_name'],
                            $user['user_id'], true);
                    } else {
                        $task_repository->insertThread($task['task_id'],
                            'ステイタスが変更されました ' . $old_status['status_name']. '->' . $new_status['status_name'],
                            $user['user_id'], true);
                    }
                    $cangeStatus=true;
                }
            }
            if (!$new_handle_user) {
                if ($task['handle_user_id']) {
                     $task_repository->updateHandleUserId($task['task_id'], null);
                     $old_handle_user = $this->db_manager->get('Account')->fetchByUserId($task['handle_user_id']);
                    if (!$new_handle_user) {
                        $task_repository->insertThread($task['task_id'],
                            '担当者が変更されました ' . $old_handle_user['show_name']. '->未設定',
                            $user['user_id'], true);
                    } else {
                        $task_repository->insertThread($task['task_id'],
                            '担当者が変更されました ' . $old_handle_user['show_name']. '->' . $new_handle_user['show_name'],
                            $user['user_id'], true);
                    }
                    $cangeStatus=true;
                }
            } else {
                if (!$task['handle_user_id'] ||  $task['handle_user_id'] !== $new_handle_user['user_id']) {
                     $task_repository->updateHandleUserId($task['task_id'], $new_handle_user['user_id']);
                     $old_handle_user = $this->db_manager->get('Account')->fetchByUserId($task['handle_user_id']);
                    if (!$old_handle_user) {
                        $task_repository->insertThread($task['task_id'],
                            '担当者が変更されました 未設定'. '->' . $new_handle_user['show_name'],
                            $user['user_id'], true);
                    } else {
                        $task_repository->insertThread($task['task_id'],
                            '担当者が変更されました ' . $old_handle_user['show_name']. '->' . $new_handle_user['show_name'],
                            $user['user_id'], true);
                    }
                    $cangeStatus=true;
                }
            }
            if($cangeStatus){
                $result[] = '情報を更新しました';
            }

            if (count($result) !== 0) {
                $this->session->setToasts($result);
            } else {
                $this->session->setToasts(array('更新内容がありません'));
            }

            return $this->redirect('/prj/' . $project['project_id'] . '/tasks/' . $task['task_id']);
        }

        $threads = $task_repository->fetchAllTaskThreadByTaskId($task['task_id'], $user['user_id'], $this->application->isDebugMode());
        $join_users = $project_repository->fetchAllJoinUserByProjectId($project['project_id']);
        $isJoinManage = $project_repository->isJoinProjectMangeUser($project['project_id'], $user['user_id']);
        $task_statuses = $task_repository->fetchAllTaskStatus();
        $prioritys = $task_repository->fetchAllTaskPriority();

        return $this->render(
            array(
                'project' => $project,
                'task' => $task,
                'threads' => $threads,
                'join_users' => $join_users,
                'prioritys' => $prioritys,
                'isJoinManage' => $isJoinManage,
                'errors' => $errors,
                'task_statuses' => $task_statuses,
                'schedule' => $task['schedule'],
                'handle_user_id' => $handle_user_id,
                'priority_id' => $task['priority_id'],
                'status_id' => $status_id,
                'thread_body' => $thread_body,
                'is_active_info' => false,
                'is_active_thread' => true,
                '_token' => $this->generateCsrfToken('tasks/threadpost'),
            ),
            'detail'
        );
    }


    public function changeThreadAction($params)
    {

        if (! $this->request->isPost()) {
            return $this->forward404();
        }

        $token = $this->request->getPost('_token');
        if (! $this->checkCsrfToken('tasks/threadpost', $token)) {
            return $this->redirect('/prj/' . $params['project_no'] . '/tasks/' . $params['task_no']);
        }

        $user = $this->session->get('user');
        if (! $user) {
            return $this->forward404();
        }

        //プロジェクトがなければホームへ　プロジェクトチェックは冗長だけどいったんいれる
        if (! isset($params['project_no']) || ! isset($params['task_no'])) {
            return $this->redirect('/');
        }
        $project_repository = $this->db_manager->get('Project');
        $project = $project_repository->fetchByProjectId($params['project_no']);
        if (! $project) {
            return $this->redirect('/');
        }

        //参加中チェック
        if (! $project_repository->isJoinProjectUser($project['project_id'], $user['user_id']) && !$this->session->isAdministratorLevel()) {
            return $this->redirect('/readingerror');
        }

        $task_repository = $this->db_manager->get('Task');
        $task = $task_repository->fetchByTaskId($params['task_no']);

        if (! $task) {
            return $this->redirect('/prj/' . $project['project_id']);
        }


        $errors = array();
        $action = $this->request->getPost('action');
        $thread_id = $this->request->getPost('_thread');
        $thread_body = $this->request->getPost('thread_body');
        $thread = $task_repository->fetchThreadByTaskAndThreadId($task['task_id'], $thread_id);

        switch ($action) {
            case 'update':
                if (! $thread) {
                    $errors[] = 'メッセージが存在しません';
                } else if ($thread['create_user_id'] !== $user['user_id']) {
                    $errors[] = '投稿者本人以外は削除できません';
                } else if (! strlen($thread_body)) {
                    $errors[] = 'メッセージは空白にはできません';
                } else if (mb_strlen($thread_body)-substr_count($thread_body, "\n") > Env::THREAD_MAX_LENGTH) {
                    $errors[] = Env::THREAD_MAX_LENGTH . '文字以内で入力してください';
                } else if ($thread['thread_body'] === $thread_body) {
                    $errors[] = '変更点がないため更新を行いませんでした';
                }
                if (count($errors) === 0) {
                      $task_repository->updateThreadByThreadId($thread['thread_id'], $thread_body);
                      $this->session->setToasts(array('メッセージの内容を変更しました'));
                } else {
                    $this->session->setToasts($errors);
                }
                break;

            case 'remove':
                if (! $thread) {
                    $errors[] = 'メッセージが存在しません';
                } else if ($thread['create_user_id'] !== $user['user_id']) {
                    $errors[] = '投稿者本人以外は削除できません';
                }
                if (count($errors) === 0) {
                      $task_repository->removeThreadByThreadId($thread['thread_id']);
                      $this->session->setToasts(array('メッセージを削除しました'));
                } else {
                    $this->session->setToasts($errors);
                }
                break;
        }


        return $this->redirect('/prj/' . $project['project_id'] . '/tasks/' . $task['task_id']);
    }
}
