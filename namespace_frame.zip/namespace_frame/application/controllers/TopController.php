<?php

namespace Controllers;

use Framework\Core\Controller;

class TopController extends Controller
{
    protected $auth_actions = array(
        );


    public function indexAction($params)
    {
        //require_once $this->application->getLibDir() . "/Sample.php";
        //$test = new \Sample();
        //$test->call();
        return $this->render(
            array(

            )
        );
    }
}
