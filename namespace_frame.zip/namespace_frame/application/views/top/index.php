<?php $this->setLayoutVar('title', "TEST");?>
<div>
<?php

       var_dump($lib_url);
       require_once $lib_url . "/Sample.php";
        $test = new \Sample();
        $test->call();
        ?>
</div>