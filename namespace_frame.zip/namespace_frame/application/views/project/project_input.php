<div class="input-field col s12 margin-bottom-20">
    <input type="text" id="project_name" name="project_name" value="<?php echo $this->escape($project_name); ?>" class="validate"  data-length="<?php echo Env::PROJECT_PAGE_TITLE_MAX_LENGTH; ?>"/>
    <label for="project_name">プロジェクトタイトル 最大<?php echo Env::PROJECT_PAGE_TITLE_MAX_LENGTH; ?>文字（必須）</label>
</div>
<div class="input-field col s12  margin-bottom-20">
    <textarea id="project_summary" name="project_summary" class="materialize-textarea character_counter validate" data-length="<?php echo Env::PROJECT_PAGE_SUMMARY_MAX_LENGTH; ?>" rows="10"><?php echo $this->escape($project_summary); ?></textarea>
    <label for="project_summary">簡単な説明 最大<?php echo Env::PROJECT_PAGE_SUMMARY_MAX_LENGTH; ?>文字（必須）</label>
</div>