<?php $this->setLayoutVar('title', '権限がありません');?>
<div class="col s12 ">
    <div id="new_project" class="section">
        <div class="toolbar-content max-width valign-wrapper margin-bottom20">
            <h1 class="page-title truncate"><strong>この操作を行う権限がありません</strong></h1>
        </div>
        <div class="max-width">
            <p>権限については該当プロジェクトの管理者に確認をしてください。</p>
        </div>
    </div>
</div>