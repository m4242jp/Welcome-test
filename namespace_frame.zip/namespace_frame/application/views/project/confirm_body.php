<div class="toolbar-content max-width card-panel  valign-wrapper">
    <h1 class="page-title truncate"><strong><?php echo $this->escape($title); ?></strong></h1>
</div>
<div class="toolbar-content max-width margin-bottom20">
    <p><?php echo $this->escape($summary); ?></p>
</div>
<div class="max-width card-panel">
    <p>プロジェクトタイトル</p>
    <p class="margin-bottom20"><?php echo $this->escape($project_name); ?></p>
    <p class="divider"></p>
    <p>説明</p>
    <p class="break"><?php echo nl2br($this->escape($project_summary)); ?></p>
</div>