<?php $this->setLayoutVar('title', '参加者 - ' . $this->escape($project['project_name']));?>
<?php $this->setLayoutVar('isTabSwipe', false);?>
<?php $this->setLayoutVar('breadcrumbs', array(array(
'url'=> $base_url . '/prj/' . $this->escape($project['project_id']),
'title'=>$this->escape($project['project_name'])
)));?>
<div class="col s12">
  <div id="edit_jpin" class="section">
    <div class="toolbar-content max-width card-panel  valign-wrapper">
      <h1 class="page-title truncate"><strong>プロジェクト参加者</strong></h1>
    </div>
    <div>
      <ul id="tabs" class="tabs">
        <li class="tab col s3"><a class="active" href="#members">メンバー</a></li>
        <li class="tab col s3"><a href="#manage-members">管理者</a></li>
        <li class="tab col s3"><a href="#no-members">未参加</a></li>
      </ul>
    </div>
    <div class="margin-bottom-20">
      <p>現在担当中の課題がある方は削除できません。<br />
      管理者を全員解除する事はできません。</p>
    </div>
    <div class="margin-vertical-32">
      <form action="<?php echo $base_url; ?>/prj/joins/<?php echo $this->escape($project['project_id']); ?>/joinchange" method="post">
        <input type="hidden" name="_token" value="<?php echo $this->escape($_token); ?>" />
        <div id="members" class="col s12">
          <p>参加者</p>
          <div class="row">
            <?php foreach ($users as $user): ?>
            <?php if ($user['joined'] && !$user['join_manage']): ?>
            <div class="col s6 m4 l2 padding8 margin-bottom-20">
              <input type="checkbox" id="members<?php echo $this->escape($user['user_id']); ?>" name="members[]" value="<?php echo $this->escape($user['user_id']); ?>"/>
              <label for="members<?php echo $this->escape($user['user_id']); ?>"><?php echo $this->escape($user['show_name']); ?></label>
            </div>
            <?php endif; ?>
            <?php endforeach; ?>
          </div>
          <div>
            <button type='submit' class="btn" name='action' value='members_up'>管理者に変更</button>
            <button type='submit' class="btn" name='action' value='members_remove'>削除</button>
          </div>
        </div>
        <div id="manage-members" class="col s12">
          <p>参加者（管理者）</p>
          <div class="row">
            <?php foreach ($users as $user): ?>
            <?php if ($user['joined'] && $user['join_manage']): ?>
            <div class="col s6 m4 l2 padding8 margin-bottom-20">
              <input type="checkbox" id="manage_members<?php echo $this->escape($user['user_id']); ?>" name="manage_members[]" value="<?php echo $this->escape($user['user_id']); ?>"/>
              <label for="manage_members<?php echo $this->escape($user['user_id']); ?>"><?php echo $this->escape($user['show_name']); ?></label>
            </div>
            <?php endif; ?>
            <?php endforeach; ?>
          </div>
          <div class="margin-top-8">
            <button type='submit' class="btn" name='action' value='manage_members_down'>メンバーに戻す</button>
            <button type='submit' class="btn" name='action' value='manage_members_remove'>削除</button>
          </div>
        </div>
        <div id="no-members" class="col s12">
          <p>未参加</p>
          <div class="row">
            <?php foreach ($users as $user): ?>
            <?php if (!$user['joined']): ?>
            <div class="col s6 m4 l2 padding8 margin-bottom-20">
              <input type="checkbox" id="no_members<?php echo $this->escape($user['user_id']); ?>" name="no_members[]" value="<?php echo $this->escape($user['user_id']); ?>"/>
              <label for="no_members<?php echo $this->escape($user['user_id']); ?>"><?php echo $this->escape($user['show_name']); ?></label>
            </div>
            <?php endif; ?>
            <?php endforeach; ?>
          </div>
          <div class="margin-top-8">
            <button type='submit' class="btn" name='action' value='no_members_add'>追加</button>
            <button type='submit' class="btn" name='action' value='no_members_add_manage'>管理者で追加</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>