<?php $this->setLayoutVar('title', 'プロジェクト作成');?>
<?php if(isset($errors) && count($errors)>0): ?>
<?php $this->setLayoutVar('errors', $errors);?>
<?php endif;?>
<div class="col s12 ">
    <div id="new_project" class="section">
        <div class="toolbar-content max-width card-panel  valign-wrapper margin-bottom20">
            <h1 class="page-title truncate"><strong>新しいプロジェクトの作成</strong></h1>
        </div>
        <form action="<?php echo $base_url; ?>/prj/new/confirm" method="post">
            <input type="hidden" name="_token"
            value="<?php echo $this->escape($_token); ?>" />
            <?php echo $this->render('project/project_input',array(
            'project_name' => $project_name,
            'project_summary' => $project_summary
            )); ?>
            <div class="right">
                <button type="submit" value="作成" class="btn-large">作成</button>
            </div>
        </form>
    </div>
</div>