<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <meta content="#0d47a1" name="theme-color">
        <title>
        <?php if (isset($title)): echo $this->escape($title) . '-'; endif;?>
        TODO
        </title>
        <?php
        // 最後には削除
        function echo_filedate($filename) {
            $d=new DateTime();
        echo $d->format('YmdHis');
        }

        ?>
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href="/myblog/application/web/css/materialize.min.css" type="text/css" rel="stylesheet" media="screen,projection"/>
         <link href="/myblog/application/web/css/theme.css?date=<?php echo_filedate("/myblog/application/web/css/theme.css"); ?>" type="text/css" rel="stylesheet" media="screen,projection"/>
   </head>
    <body class="<?php echo $session->isAuthAndVerification() ? 'app-base' : 'header-back-color' ;?>">
        <?php if($session->isAuthAndVerification()):?>
        <?php echo $this->render('header',array(
        'login_name'=>!is_null($session->getLoginName()) ? $session->getLoginName() : 'ゲスト',
        'admin'=>$session->isAdministratorLevel(),
        'develop'=>$session->isDeveloperLevel(),
        'manager'=>$session->isManagerLevel(),
        'navigations' => isset($navigations) ? $navigations : null,
        'breadcrumbs'=> isset($breadcrumbs) ? $breadcrumbs : null
        )); ?>
        <?php endif; ?>
        <div id="content-main" class="main-container">
            <div class="row">
                <div class="section">
                    <div class="twopanel-container" >
                        <?php echo $_content; ?>
                    </div>
                </div>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
        <script src="/myblog/application/web/js/materialize.js"></script>
        <script src="/myblog/application/web/js/init.js"></script>
        <?php if (isset($isReadMore) && $isReadMore): ?>
        <script src="/myblog/application/web/js/readmore.min.js"></script>
        <?php endif;?>
        <script type="text/javascript">
        $(document).ready(function(){
        //$('.modal').modal();
        $('select').material_select();
        $('.tooltipped').tooltip({delay: 50});
        $('.collapsible').collapsible();
        $('.materialize-textarea').trigger('autoresize');
        $('input.character_counter').characterCounter();

        jQuery( function($) {
            $('tbody tr[data-url]').addClass('clickable').click( function() {
            window.location = $(this).attr('data-url');

            }).find('a').hover( function() {
                $(this).parents('tr').unbind('click');
            }, function() {
                $(this).parents('tr').click( function() {
                if('_blank' === $(this).attr('data-target')){
                window.open($(this).attr('data-url'),'_blank');
                }else{
                window.location = $(this).attr('data-url');
                }
            });
            });
        });
         jQuery( function($) {
            $('thead th').addClass('clickable').click( function() {
            }).find('a').hover( function() {
                $(this).parents('tr').unbind('click');
            });
        });



        <?php if (isset($isTabSwipe) && $isTabSwipe): ?>
        $('ul.tabs').tabs({'swipeable': true});
        <?php endif;?>

        <?php if (isset($isReadMore) && $isReadMore): ?>
        $('.readmore').readmore({
        speed: 300,
        collapsedHeight: 300,
        moreLink: '<a href="#" class="readmore-btn">続きを読む</a>',
        lessLink: '<a href="#" class="readmore-btn">閉じる</a>',
        });
        $('.readmore_min').readmore({
        speed: 300,
        collapsedHeight: 180,
        moreLink: '<a href="#" class="readmore-btn">続きを読む</a>',
        lessLink: '<a href="#" class="readmore-btn">閉じる</a>',
        });
        $('.readmore_big').readmore({
        speed: 300,
        collapsedHeight: 600,
        moreLink: '<a href="#" class="readmore-btn">続きを読む</a>',
        lessLink: '<a href="#" class="readmore-btn">閉じる</a>',
        });
        <?php endif;?>
        <?php if (isset($isThread) && $isThread): ?>
        $('#modalEditableThread').modal({
        ready: function(modal, trigger) {
        modal.find('form[id="modalEditableThread"]').attr('action', trigger.data('url'));
        modal.find('input[name="_thread"]').val(trigger.data('id'));
        var ta = modal.find('textarea[name="thread_body"]');
        ta.val(trigger.data('thread'));
        Materialize.updateTextFields();
        ta.trigger('autoresize');
        },
        complete: function(modal, trigger) {
        modal.find('form[id="modalEditableThread"]').attr('action','#');
        modal.find('input[name="_thread"]').val('');
        modal.find('textarea[name="thread_body"]').val('');
        Materialize.updateTextFields();
        }
        });
        $('#modalRemoveThread').modal({
        ready: function(modal, trigger) {
        modal.find('form[id="modalRemoveFrom"]').attr('action', trigger.data('url'));
        modal.find('input[name="_thread"]').val(trigger.data('id'));
        modal.find('div[name="confirm_thread_body"]').html(trigger.data('thread'));
        },
        complete: function(modal, trigger) {
        console.log(modal);
        modal.find('form[id="modalEditableThread"]').attr('action','#');
        modal.find('input[name="_thread"]').val('');
        modal.find('div[name="confirm_thread_body"]').html('');
        Materialize.updateTextFields();
        }
        });
        <?php endif;?>
        $('.datepicker').pickadate({
        monthsFull:  ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"],
        monthsShort: ['1 /', '2 /', '3 /', '4 /', '5 /', '6 /', '7 /', '8 /', '9 /', '10 /', '11 /', '12 /'],
        weekdaysFull: ["日曜日", "月曜日", "火曜日", "水曜日", "木曜日", "金曜日", "土曜日"],
        weekdaysShort:  ["日", "月", "火", "水", "木", "金", "土"],
        weekdaysLetter: ["日", "月", "火", "水", "木", "金", "土"],
        labelMonthNext: "翌月",
        labelMonthPrev: "前月",
        labelMonthSelect: "月を選択",
        labelYearSelect: "年を選択",
        today: "今日",
        clear: "クリア",
        close: "閉じる",
        format: "yyyy-mm-dd",
        });
        <?php if (isset($toasts) && count($toasts) > 0): ?>
        <?php foreach ($toasts as $toast): ?>
        Materialize.toast('<?php echo $this->escape($toast); ?>', 2000);
        <?php endforeach;?>
        <?php endif; ?>
        <?php if (isset($errors) && count($errors) > 0): ?>
        <?php foreach ($errors as $error): ?>
        Materialize.toast('<?php echo $this->escape($error); ?>', 2000);
        <?php endforeach;?>
        <?php endif; ?>
        });
        </script>
    </body>
</html>