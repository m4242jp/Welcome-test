<?php $this->setLayoutVar('title', '不正なアクセス');?>

<div class="col s12 card">
<div class="card-content">
    <div class="margin-vertical-20">
        不正なアクセスです。
        <?php echo $this->escape($message); ?>
    </div>
    <div>
        <a href="<?php echo $base_url;?>/" class="btn">トップへ</a>
    </div>
</div>
</div>