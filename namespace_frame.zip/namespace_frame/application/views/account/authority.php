<?php $this->setLayoutVar('title', 'ユーザー情報') ?>
<?php $this->setLayoutVar('breadcrumbs', array(array(
'url'=> $base_url . '/manage/users',
'title'=>'ユーザー一覧'
)));?>
<?php if(isset($errors) && count($errors)>0): ?>
<?php $this->setLayoutVar('errors', $errors);?>
<?php endif;?>
<div class="col s12 ">
    <div id="content" class="section">
        <div class="toolbar-content max-width card-panel  valign-wrapper">
            <h1 class="page-title"><strong>ユーザー情報</strong></h1>
        </div>
        <div class="margin-bottom-20">
            <p class="label">ID</p>
            <p><?php echo $this->escape($user['user_name']); ?></p>
            <p class="label">ユーザ名</p>
            <p><?php echo $this->escape(!is_null($user['show_name']) ? $user['show_name'] : 'ユーザー名が未設定です'); ?></p>
            <p class="label">権限</p>
            <p><?php echo $this->escape($user['authority_name']); ?></p>
        </div>
        <p class="divider"></p>
        <div>
            <form action="<?php echo $base_url; ?>/account/authoritypost/<?php echo $this->escape($user['user_name']);?>" method="post">
                <input type="hidden" name="_token" value="<?php echo $this->escape($_token); ?>" />
                <div class="col s12 margin-bottom-8">
                    <label class="col s12">権限</label>
                    <div class="input-field inline">
                        <select name="authority">
                            <?php foreach ($authoritys as $authority): ?>
                            <option value="<?php echo $this->escape($authority['authority_level']); ?>"
                                <?php echo $this->escape($authority['authority_level'] === $user['authority_level'] ? 'selected = "selected"' : '' ); ?>
                            ><?php echo $this->escape($authority['authority_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="col s12">
                    <button type="submit" class="btn" id="submit">更新</button>
                </div>
            </form>
        </div>
    </div>
</div>