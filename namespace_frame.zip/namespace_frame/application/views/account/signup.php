<?php $this->setLayoutVar('title', 'アカウント登録') ?>
<?php if(isset($errors) && count($errors)>0): ?>
<?php $this->setLayoutVar('errors', $errors);?>
<?php endif;?>
<div class="col s12 ">
    <div id="content" class="section">
        <div class="toolbar-content max-width card-panel  valign-wrapper">
            <h1 class="page-title"><strong>アカウント登録</strong></h1>
        </div>
        <div class="margin-bottom-20">
            <form action="<?php echo $base_url; ?>/account/signup/register" method="post">
                <input type="hidden" name="_token" value="<?php echo $this->escape($_token); ?>" />
                <div class="col s12">
                    <div class="input-field margin-bottom20 inline">
                        <input type="text" id="user_name" name="user_name" value="<?php echo $this->escape($user_name); ?>" data-length="20" />
                        <label for="user_name">ユーザID</label>
                    </div>
                </div>
                <div class="col s12">
                    <div class="input-field margin-bottom20 inline">
                        <input type="text" id="show_name" name="show_name" value="<?php echo $this->escape($show_name); ?>" data-length="20" />
                        <label for="show_name">表示名</label>
                    </div>
                </div>
                <div class="col s12">
                    <div class="input-field margin-bottom20 inline">
                        <input type="password" id="password" name="password" value="<?php echo $this->escape($password); ?>" data-length="30" />
                        <label for="password">パスワード</label>
                    </div>
                </div>
                <div class="col s12 margin-bottom-8">
                    <label class="col s12">権限</label>
                    <div class="input-field inline">
                        <select name="authority">
                            <?php foreach ($authoritys as $authority): ?>
                            <option value="<?php echo $this->escape($authority['authority_level']); ?>"><?php echo $this->escape($authority['authority_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="col s12">
                    <button type="submit" class="btn" id="submit">登録</button>
                </div>
            </div>
        </form>
    </div>
</div>