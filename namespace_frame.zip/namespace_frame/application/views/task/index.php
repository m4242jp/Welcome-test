<?php $this->setLayoutVar('title', $this->escape($project['project_name']));?>
<?php $this->setLayoutVar('isReadMore', true);?>
<?php
$navigations = array();
if ($isMember || $isJoinManage || $admin):
$navigations[] = array(
'url'=> $base_url . '/prj/' . $this->escape($project['project_id']) . '/newtask',
'title'=>'新しいタスク'
);
endif;
if ($isJoinManage || $admin):
$navigations[] =array(
'url'=> $base_url . '/prj/joins/' . $this->escape($project['project_id']),
'title'=>'参加者の編集'
);
endif;
$this->setLayoutVar('navigations',$navigations);
$project_create_date = $this->escapeDate($project['create_date'],'Y-m-d H:i');
$project_update_date = $this->escapeDate($project['update_date'],'Y-m-d H:i');
$base_page_nation_url = $base_url . '/prj/' . $this->escape($project['project_id']) . '?';
$now_task_page_no = 'tno=' . $this->escape($tasks_pager['page_no']);
$now_task_sort = 'sort=' . $this->escape($task_sort). '&desc=' . $this->escape($task_desc);
$task_desc_mark = $task_desc ? '<span class="label">&nbsp;▼<span>' : '<span class="label">&nbsp;▲<span>';?>
    <div class="col s12 m12 l9 ">
        <div id="project_content">
            <div class="col max-width ">
                <h1 class="page-title"><strong><b><?php echo $this->escape($project['project_name']); ?></b></strong></h1>
            </div>
            <ul id="tabs" class="tabs" style="overflow:hidden;">
                <li class="tab col s3"><a class="active" href="#task_page">タスク一覧</a></li>
                <li class="tab col s3"><a href="#info_page">説明</a></li>
            </ul>
            <div id="info_page" class="section">
                <div class="card">
                    <div class="card-content">
                        <div><span class="readmore break"><?php echo nl2br($this->escape($project['project_summary'],true)); ?></span></div>
                        <div class="row no-margin-bottom">
                            <div class="col right right-align">
                                <?php if ($isJoinManage || $admin): ?>
                                <span><a href="<?php echo $base_url;?>/prj/edit/<?php echo $this->escape($project['project_id']);?>">
                                内容の編集</a></span><br />
                                <?php endif; ?>
                                <span><?php echo $project_create_date ?></span>
                                <?php if($project_create_date !== $project_update_date): ?>
                                <span class="grey-text darken-1" style="font-size: 80%; ">更新：<?php echo $project_update_date ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="task_page">
                <div id="project_tasks" class="section">
                    <div class="row no-margin-bottom">
                        <div class="col s12 right">
                            <?php echo $this->render('task/task_list_header',array(
                            "pager" => $tasks_pager,
                            'page_url' => $base_page_nation_url,
                            'param_name' => 'tno',
                            'get_param_before' => '',
                            'get_param_after' => '&' . $now_task_sort .'#project_tasks'
                            )); ?>
                        </div>
                    </div>
                    <?php if (count($tasks) > 0): ?>
                    <div class="responsive-wrapper margin-bottom-8">
                        <table class="bordered highlight responsive-table-s text-size-sub border-panel">
                            <thead>
                                <tr>
                                    <th><a class="black-text" href="<?php echo $this->escape($base_page_nation_url); ?><?php echo $this->escape($now_task_page_no); ?>&<?php echo $this->escape($task_sort_url['category']); ?>#project_tasks">分類<?php echo $task_sort === 'category' ? $task_desc_mark : ''; ?></a></th>
                                    <th><a class="black-text" href="<?php echo $this->escape($base_page_nation_url); ?><?php echo $this->escape($now_task_page_no); ?>&<?php echo $this->escape($task_sort_url['priority']); ?>#project_tasks">優先<?php echo $task_sort === 'priority' ? $task_desc_mark: ''; ?></a></th>
                                    <th><a class="black-text" href="<?php echo $this->escape($base_page_nation_url); ?><?php echo $this->escape($now_task_page_no); ?>&<?php echo $this->escape($task_sort_url['task']); ?>#project_tasks">タスク名<?php echo $task_sort === 'task' ? $task_desc_mark : ''; ?></a></th>
                                    <th><a class="black-text" href="<?php echo $this->escape($base_page_nation_url); ?><?php echo $this->escape($now_task_page_no); ?>&<?php echo $this->escape($task_sort_url['status']); ?>#project_tasks">状態<?php echo $task_sort === 'status' ? $task_desc_mark : ''; ?></a></th>
                                    <th><a class="black-text" href="<?php echo $this->escape($base_page_nation_url); ?><?php echo $this->escape($now_task_page_no); ?>&<?php echo $this->escape($task_sort_url['handle']); ?>#project_tasks">担当<?php echo $task_sort === 'handle' ? $task_desc_mark : ''; ?></a></th>
                                    <th><a class="black-text" href="<?php echo $this->escape($base_page_nation_url); ?><?php echo $this->escape($now_task_page_no); ?>&<?php echo $this->escape($task_sort_url['schedule']); ?>#project_tasks">スケジュール<?php echo $task_sort === 'schedule' ? $task_desc_mark : ''; ?></a></th>
                                    <th><a class="black-text" href="<?php echo $this->escape($base_page_nation_url); ?><?php echo $this->escape($now_task_page_no); ?>&<?php echo $this->escape($task_sort_url['date']); ?>#project_tasks">更新日<?php echo $task_sort === 'date' ? $task_desc_mark : ''; ?></a></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($tasks as $task): ?>
                                <?php echo $this->render('task/task',array('task'=>$task, "isShowProjectName" => false)); ?>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="margin-bottom-20 min-height200">登録されたタスクはありません。</div>
                    <?php endif; ?>


                    <?php if ($isMember || $isJoinManage || $admin): ?>
                    <div class="col s12 m12  hide-on-large-only">
                        <span class="right">
                            <a class="btn" href="<?php echo $base_url;?>/prj/<?php echo $this->escape($project['project_id']);?>/newtask">
                            新しいタスク</a></li>
                        </span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="col s12 m12 l3">
        <div id="users" class="section">
            <div class="row margin-bottom-8 valign-wrapper">
                <div class="col s12">
                    <span class="page-title"><strong><b>参加ユーザー</b></strong></span>
                </div>
            </div>
            <div class="margin-bottom-8">
                <?php echo $this->render('task/join_user_list',array(
                "project_id" => $project['project_id'],
                'join_users' => $join_users
                )); ?>
            </div>
            <?php if ($isJoinManage || $admin): ?>
            <div class="col s12 m12  hide-on-large-only">
                <span class="right">
                    <a class="btn" href="<?php echo $base_url;?>/prj/joins/<?php echo $this->escape($project['project_id']);?>">
                    参加者の編集</a></li></span>
                </div>
                <?php endif; ?>
            </div>
        </div>