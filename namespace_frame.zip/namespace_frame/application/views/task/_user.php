<div class="user">
    <div class="user_content">
        <a href="<?php echo $base_url;?>/user/<?php echo $this->escape($user['user_name']);?>"><?php echo $this->escape($user['show_name']); ?></a>
    </div>
</div>