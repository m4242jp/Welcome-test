<?php
$category_class='orange white-text';
$status_class='orange white-text';
switch ($task['category_id']){
    case '1':;
    $category_class = 'green white-text';
    break;
    case '2':
    $category_class = 'red white-text';
    break;
    case '3':
    $category_class = 'blue white-text';
    break;
}
switch ($task['status_id']){
    case '1':
    $status_class = 'light-blue white-text';
    break;
    case '2':
    $status_class = 'green white-text';
    break;
    case '10':
    $status_class = 'red white-text';
    break;
}
?>
<tr data-url="<?php echo $base_url;?>/prj/<?php echo $this->escape($task['project_id']);?>/tasks/<?php echo $this->escape($task['task_id']);?>">
    <td>
        <span class="padding-2 nowrap <?php echo $category_class ?>"><?php echo $this->escape($task['category_name']); ?></span>
    </td>
    <td>
        <span class="padding-2 nowrap"><?php echo $this->escape($task['priority_name']); ?></span>
    </td>
    <td>
        <a href="<?php echo $base_url;?>/prj/<?php echo $this->escape($task['project_id']);?>/tasks/<?php echo $this->escape($task['task_id']);?>">
            <?php echo $this->escape($task['task_name']); ?>
        </a>
    </td>
    <td>
        <span class="padding-2 nowrap <?php echo $status_class ?>"><?php echo $this->escape($task['status_name']); ?></span>
    </td>
    <?php if (!$isShowProjectName): ?>
    <td><?php echo $this->escape(is_null($task['handle_name']) ? '未設定' :$task['handle_name'] ); ?></td>
    <?php endif; ?>
    <td><?php echo $this->escapeDate($task['schedule']); ?></td>
    <td><?php echo $this->escapeDate($task['update_date'],'Y-m-d H:i'); ?></td>
    <?php if ($isShowProjectName): ?>
    <td>
        <a href="<?php echo $base_url;?>/prj/<?php echo $this->escape($task['project_id']);?>">
            <?php echo $this->escape($task['project_name']); ?>
        </a>
    </td>
    <?php endif; ?>
</tr>