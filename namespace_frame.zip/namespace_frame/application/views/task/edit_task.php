<?php $this->setLayoutVar('title', '編集-' . $task['task_name']);?>
<?php $this->setLayoutVar('breadcrumbs', array(array(
'url'=> $base_url . '/prj/' . $this->escape($project['project_id'] . '/tasks' ),
'title'=>$this->escape($project['project_name'])
),array(
'url'=> $base_url . '/prj/' . $this->escape($project['project_id'] . '/tasks/' . $task['task_id'] ),
'title'=>$this->escape($task['task_name'])
)));?>
<?php if(isset($errors) && count($errors)>0): ?>
<?php $this->setLayoutVar('errors', $errors);?>
<?php endif;?>
<div class="col s12 ">
    <div id="new_task" class="section">
        <div class="toolbar-content max-width card-panel  valign-wrapper margin-bottom20">
            <h1 class="page-title truncate"><strong>タスクの編集</strong></h1>
        </div>
        <form action="<?php echo $base_url; ?>/prj/<?php echo $this->escape($project['project_id']); ?>/tasks/<?php echo $this->escape($task['task_id']); ?>/editupdate" method="post">
            <input type="hidden" name="_token"
            value="<?php echo $this->escape($_token); ?>" />
            <?php echo $this->render('task/task_input',array(
            'task_title' => $task_title,
            'task_summary' => $task_summary,
            'category_id' => $category_id,
            'priority_id' => '',
            'schedule' => '',
            'handle_user_id'=> '',
            'join_users' => '',
            'prioritys' => array(),
            'categorys' => $categorys,
            'isExtraForm' => false
            )); ?>
            <div>
                <button type="submit" name="action" value="update" class="btn-large right">更新</button>
                <button type="submit" name="action" value="remove" class="btn-large">削除</button>
            </div>
        </form>
    </div>
</div>