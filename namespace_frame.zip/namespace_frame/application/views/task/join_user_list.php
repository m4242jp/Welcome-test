
    <?php if (count($join_users) > 0): ?>
    <div class="responsive-wrapper">
        <table class="bordered highlight responsive-table-s text-size-sub border-panel margin-bottom-6">
            <tbody>
                <?php foreach ($join_users as $user): ?>
                <tr data-url="<?php echo $base_url;?>/account/user/<?php echo $this->escape($user['user_name']);?>">
                    <td>
                        <a href="<?php echo $base_url;?>/account/user/<?php echo $this->escape($user['user_name']);?>">
                        <?php echo $this->escape($user['show_name']); ?></a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <p>■参加ユーザーはいません</p>
    <?php endif; ?>
