<?php $this->setLayoutVar('title', '編集-' . $task['task_name']);?>
<?php $this->setLayoutVar('breadcrumbs', array(array(
'url'=> $base_url . '/prj/' . $this->escape($project['project_id'] . '/tasks' ),
'title'=>$this->escape($project['project_name'])
),array(
'url'=> $base_url . '/prj/' . $this->escape($project['project_id'] . '/tasks/' . $task['task_id'] ),
'title'=>$this->escape($task['task_name'])
)));?>
<?php if(isset($errors) && count($errors)>0): ?>
<?php $this->setLayoutVar('errors', $errors);?>
<?php endif;?>
<div class="col s12 ">
    <div id="edit_task" class="section">
        <?php echo $this->render('task/confirm_body',array(
        'title' => 'タスクの編集',
        'summary' => '以下の内容で更新します。問題ないですか？',
        'task_title' => $task_title,
        'task_summary' => $task_summary,
        'category_name' => $category_name,
        'schedule' => '',
        'handle_user_name' => '',
        'isExtraForm' => false
        )); ?>
        <div id="confirm_panel">
            <form name="confirm_form" action="<?php echo $base_url; ?>/prj/<?php echo $this->escape($project['project_id']); ?>/tasks/<?php echo $this->escape($task['task_id']); ?>/editsave" method="post">
                <input type="hidden" name="_token"
                value="<?php echo $this->escape($_token); ?>" />
                <input type="hidden" name="task_title"
                value="<?php echo $this->escape($task_title); ?>" />
                <input type="hidden" name="task_summary"
                value="<?php echo $this->escape($task_summary); ?>" />
                <input type="hidden" name="category_id"
                value="<?php echo $this->escape($category_id); ?>" />
                <button type="submit" class="btn-large right" id="submit">更新</button>
                <button type="submit" class="btn-large" onclick="confirm_form.action='<?php echo $base_url; ?>/prj/<?php echo $this->escape($project['project_id']); ?>/tasks/<?php echo $this->escape($task['task_id']); ?>/edit';return true;">戻る</button>
            </form>
        </div>
    </div>
</div>