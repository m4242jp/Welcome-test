<?php $this->setLayoutVar('title', '削除済タスク') ?>
<?php $this->setLayoutVar('breadcrumbs', array(array(
'url'=> $base_url . '/manage/projects',
'title'=>'プロジェクト一覧'
)));?>
<?php if(isset($errors) && count($errors)>0): ?>
<?php $this->setLayoutVar('errors', $errors);?>
<?php endif;?>
<?php
$base_page_nation_url = $base_url . '/manage/projects/' . $this->escape($project_id) . '?';
$now_task_page_no = 'tno=' . $this->escape($tasks_pager['page_no']);
$now_task_sort = 'sort=' . $this->escape($task_sort). '&desc=' . $this->escape($task_desc);
$task_desc_mark = $task_desc ? '<span class="label">&nbsp;▼<span>' : '<span class="label">&nbsp;▲<span>';?>
<div class="col s12 ">
    <div id="content" class="section">
        <div class="toolbar-content max-width card-panel  valign-wrapper">
            <h1 class="page-title"><strong>削除済タスク</strong></h1>
        </div>
        <?php if($session->isDeveloperLevel()):?>

            <div id="task_page">
                <div id="project_tasks" class="section">
                    <div class="row no-margin-bottom">
                        <div class="col s12 right">
                            <?php echo $this->render('task/task_list_header',array(
                            "pager" => $tasks_pager,
                            'page_url' => $base_page_nation_url,
                            'param_name' => 'tno',
                            'get_param_before' => '',
                            'get_param_after' => '&' . $now_task_sort .'#project_tasks'
                            )); ?>
                        </div>
                    </div>
                    <?php if (count($tasks) > 0): ?>
                    <div class="responsive-wrapper margin-bottom-8">
                        <table class="bordered highlight responsive-table-s text-size-sub border-panel">
                            <thead>
                                <tr>
                                    <th><a class="black-text" href="<?php echo $this->escape($base_page_nation_url); ?><?php echo $this->escape($now_task_page_no); ?>&<?php echo $this->escape($task_sort_url['category']); ?>#project_tasks">分類<?php echo $task_sort === 'category' ? $task_desc_mark : ''; ?></a></th>
                                    <th><a class="black-text" href="<?php echo $this->escape($base_page_nation_url); ?><?php echo $this->escape($now_task_page_no); ?>&<?php echo $this->escape($task_sort_url['task']); ?>#project_tasks">タスク名<?php echo $task_sort === 'task' ? $task_desc_mark : ''; ?></a></th>
                                    <th><a class="black-text" href="<?php echo $this->escape($base_page_nation_url); ?><?php echo $this->escape($now_task_page_no); ?>&<?php echo $this->escape($task_sort_url['project']); ?>#project_tasks">プロジェクト<?php echo $task_sort === 'status' ? $task_desc_mark : ''; ?></a></th>
                                    <th>有効化</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($tasks as $task): ?>
                            <?php echo $this->render('admin/task',array('task'=>$task)); ?>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="margin-bottom-20 min-height200">登録されたタスクはありません。</div>
                    <?php endif; ?>
                </div>
            </div>




        <?php else: ?>
            <div id="not_auth">
                閲覧権限がありません。
            </div>
        <?php endif; ?>
    </div>
</div>