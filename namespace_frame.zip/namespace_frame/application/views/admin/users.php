<?php $this->setLayoutVar('title', 'ユーザー一覧') ?>
<?php if(isset($errors) && count($errors)>0): ?>
<?php $this->setLayoutVar('errors', $errors);?>
<?php endif;?>
<div class="col s12 ">
    <div id="content" class="section">
        <div class="toolbar-content max-width card-panel  valign-wrapper">
            <h1 class="page-title"><strong>ユーザー一覧</strong></h1>
        </div>
        <div>
            <p>未参加のプロジェクトは閲覧のみ可能です。</p>
        <?php if($session->isDeveloperLevel()):?>
            <p>ユーザーの削除は担当を全て解除しないとできません。</p>
        <?php endif; ?>
        </div>

        <div id="users">
            <?php foreach ($users as $user): ?>
            <?php if(!$user['user_removed'] || $session->isDeveloperLevel()):?>
            <?php echo $this->render('admin/user',array('user'=>$user)); ?>
            <?php endif; ?>
            <?php endforeach; ?>
        </div>
    </div>
</div>