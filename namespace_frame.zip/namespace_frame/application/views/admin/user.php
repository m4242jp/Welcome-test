<div class="col s6 m4 l4 padding8">
    <div class="card">
        <div class="card-content">
            <span class="label">名前</span>
            <p><a href="<?php echo $base_url;?>/account/user/<?php echo $this->escape($user['user_name']);?>"><?php echo $this->escape($user['show_name']);?></a></p>
            <span class="label">担当中（稼働中/全て）</span>
            <p><?php echo $this->escape(!$user['work_handle_count'] ? '0' : $user['work_handle_count']);?> / <?php echo $this->escape(!$user['all_handle_count'] ? '0' : $user['all_handle_count']);?> 件</p>
            <?php if($session->isDeveloperLevel()):?>
            <span class="label">ID</span>
            <p><?php echo $this->escape($user['user_name']);?> <?php echo $this->escape($user['user_removed'] ? '（退会）' : ''); ?></p>
            <span class="label">権限</span>
            <p><?php echo $this->escape($user['authority_name']);?> </p><br />
            <div>
                <?php if(!$user['user_removed']): ?>
                <span><a href="<?php echo $base_url?>/account/authority/<?php echo $this->escape($user['user_name']); ?>">編集</a></span>&nbsp;
                <?php if(!$user['work_handle_count']): ?>
                <span><a href="<?php echo $base_url?>/account/remove/<?php echo $this->escape($user['user_name']); ?>">削除</a></span>
                <?php endif; ?>
                <?php else: ?>
                <span><a href="<?php echo $base_url?>/account/restoration/<?php echo $this->escape($user['user_name']); ?>">復活</a></span>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>