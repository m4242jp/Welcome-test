<?php


use Framework\Core\Application;
use Framework\Core\View;

class TodoApplication extends Application
{
    protected $login_action = array(
        'account',
        'login',
    );

    protected $invalid_action = array(
        'account',
        'invalid',
    );


    public function getRootDir()
    {
        return dirname(__FILE__);
    }

    public function registerRoutes()
    {
        //chromeの特定URLバグのためprojectのURLをprjに
        return array(
            '/' => array(
                //'controller' => 'project',
                //'action' => 'index',
                'controller' => 'top',
                'action' => 'index',
            ),
            '/prj' => array(
                'controller' => 'project',
                'action' => 'index',
            ),
            '/prj/sendtest' => array(
                'controller' => 'project',
                'action' => 'sendtest',
            ),
            '/prj/new' => array(
                'controller' => 'project',
                'action' => 'new',
            ),
            '/prj/new/confirm' => array(
                'controller' => 'project',
                'action' => 'confirm',
            ),
            '/prj/new/post' => array(
                'controller' => 'project',
                'action' => 'post',
            ),
            '/prj/edit/:project_no' => array(
                'controller' => 'project',
                'action' => 'edit',
            ),
            '/prj/edit/:project_no/confirm/detail' => array(
                'controller' => 'project',
                'action' => 'update_confirm_detail',
            ),
            '/prj/edit/:project_no/post/detail' => array(
                'controller' => 'project',
                'action' => 'update_post_detail',
            ),
            '/prj/edit/:project_no/post/remove' => array(
                'controller' => 'project',
                'action' => 'update_post_remove',
            ),
            '/prj/joins/:project_no' => array(
                'controller' => 'project',
                'action' => 'joins',
            ),
            '/prj/joins/:project_no/:action' => array(
                'controller' => 'project'
            ),
            '/prj/joins/:project_no/post/auth' => array(
                'controller' => 'project',
                'action' => 'update_post_joins',
            ),
            '/prj/joins/:project_no/post/join' => array(
                'controller' => 'project',
                'action' => 'update_post_joins',
            ),

            '/prj/:project_no' => array(
                'controller' => 'task',
                'action' => 'index',
            ),
            '/prj/:project_no/tasks' => array(
                'controller' => 'task',
                'action' => 'index',
            ),
            '/prj/:project_no/newtask' => array(
                'controller' => 'task',
                'action' => 'newTask',
            ),
            '/prj/:project_no/newtask/post' => array(
                'controller' => 'task',
                'action' => 'postNewTask',
            ),
            '/prj/:project_no/newtask/up' => array(
                'controller' => 'task',
                'action' => 'upNewTask',
            ),


            '/prj/:project_no/tasks/:task_no' => array(
                'controller' => 'task',
                'action' => 'detail',
            ),
            '/prj/:project_no/tasks/:task_no/:action' => array(
                'controller' => 'task',
            ),
            '/readingerror' => array(
                'controller' => 'project',
                'action' => 'notReadingAuthority',
            ),


            '/account' => array(
                'controller' => 'account',
                'action' => 'index',
            ),
            '/account/login/auth' => array(
                'controller' => 'account',
                'action' => 'auth',
            ),
            '/account/signup/:action' => array(
                'controller' => 'account',
            ),
            '/account/edit/post' => array(
                'controller' => 'account',
                'action' => 'editpost',
            ),
            '/account/:action' => array(
                'controller' => 'account',
            ),
            '/account/:action/:user_name' => array(
                'controller' => 'account',
            ),

            '/manage/projects' => array(
                'controller' => 'admin',
                'action' => 'projects',
            ),
            '/manage/projects/:project_no' => array(
                'controller' => 'admin',
                'action' => 'hiddenTasks',
            ),
            '/manage/action/:action/:type/:no' => array(
                'controller' => 'admin',
            ),
            '/manage/action/:action/:type/:no/:no2' => array(
                'controller' => 'admin',
            ),
            '/manage/users' => array(
                'controller' => 'admin',
                'action' => 'users'
            )
        );
    }

    public function configure()
    {
        $this->db_manager->connect(
            'master',
            array(
                'dsn' => 'mysql:dbname=mini_todo;host=localhost',
                'user' => 'miwa',
                'password' => 'miwa4242',
            )
        );
    }

    public function render404($e)
    {
        $this->response->setStatusCode(404, 'Not Found');
        $message = $this->isDebugMode() ? $e->getMessage() : 'Page not found.';
        $message = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
        $this->renderHelper($message);
    }

    public function render400($e)
    {
        $this->response->setStatusCode(400, 'Bad Request');
        $message = '不正なアクセスが検出されました';
        $message = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
        $this->renderHelper($message, '400');
    }

    private function renderHelper($message, $layout = '404')
    {
        $defaults = array(
          'request' => $this->request,
          'base_url' => $this->request->getBaseUrl(),
          'session' => $this->session,
          'message' => $message,
        );

        $view = new View($this->getViewDir(), $defaults);
        $this->response->setContent($view->render($layout, $defaults, 'base'));
    }
}
