<?php

namespace Models;

use Framework\Core\DbRepository;
use Apps\Env;
use PDO;

class TaskRepository extends DbRepository
{

/**
 * タスクに入れる
 * @param  [type] $project_id     [description]
 * @param  [type] $task_name      [description]
 * @param  [type] $task_summary   [description]
 * @param  [type] $schedule       [description]
 * @param  [type] $handle_user_id [description]
 * @return [type]                 [description]
 */
    public function insert($project_id, $task_name, $task_summary, $create_user_id, $category_id, $priority_id, datetime $schedule = null, $handle_user_id = null)
    {

            $sql = '
                   INSERT INTO project_task (project_id,task_name,task_summary,create_user_id,category_id,priority_id,schedule,handle_user_id)
                   VALUES( :project_id , :task_name, :task_summary, :create_user_id,:category_id,:priority_id, :schedule, :handle_user_id)
                   ';

            $stmt = $this->execute(
                $sql,
                array(
                    ':project_id' => $project_id,
                    ':task_name' => $task_name,
                    ':task_summary' => $task_summary,
                    ':create_user_id' => $create_user_id,
                    ':category_id' => $category_id,
                    ':priority_id' => $priority_id,
                    ':schedule' => is_null($schedule) ? null : $schedule->format('Y-m-d H:i:s'),
                    ':handle_user_id' => $handle_user_id
                )
            );
    }



    public function updateTaskDetail($task_id, $task_name, $task_summary, $category_id)
    {
        /*
        $sql = '
                   UPDATE project_task
                   SET
                    task_name = :task_name , task_summary = :task_summary ,
                    schedule = :schedule , handle_user_id = :handle_user_id WHERE id = :task_id';

        $stmt = $this->execute(
            $sql,
            array(
                    ':task_id' => $task_id,
                    ':task_name' => $task_name,
                    ':task_summary' => $task_summary,
                    ':schedule' => is_null($schedule) ? null : $schedule->format('Y-m-d H:i:s'),
                    ':handle_user_id' => is_null($handle_user_id) ? null : $handle_user_id
            )
        );
        */
        $sql = '
                   UPDATE project_task
                   SET
                    task_name = :task_name , task_summary = :task_summary , category_id = :category_id  WHERE id = :task_id';

        $stmt = $this->execute(
            $sql,
            array(
                    ':task_id' => $task_id,
                    ':task_name' => $task_name,
                    ':task_summary' => $task_summary,
                    ':category_id' => $category_id
            )
        );
    }

    public function updateHandleUserId($task_id, $handle_user_id)
    {

        $sql = '
                   UPDATE project_task SET handle_user_id = :handle_user_id WHERE id = :task_id';

        $stmt = $this->execute(
            $sql,
            array(
                    ':task_id' => $task_id,
                    ':handle_user_id' => is_null($handle_user_id) ? null : $handle_user_id
            )
        );
    }
    public function updateSchedule($task_id, $schedule)
    {

        $sql = '
                   UPDATE project_task SET schedule = :schedule WHERE id = :task_id';

        $stmt = $this->execute(
            $sql,
            array(
                    ':task_id' => $task_id,
                    ':schedule' => is_null($schedule) ? null : $schedule->format('Y-m-d H:i:s')
            )
        );
    }
    /**
     * ステイタスを変更　id1(完了)を指定すると担当者もはずれる
     * @param  [type] $task_id   [description]
     * @param  [type] $status_id [description]
     * @return [type]            [description]
     */
    public function updateStatus($task_id, $status_id)
    {
        if($status_id === '1'){
          $sql = 'UPDATE project_task SET status_id = :status_id , handle_user_id =  null WHERE id = :task_id';
        }else{
          $sql = 'UPDATE project_task SET status_id = :status_id WHERE id = :task_id';
        }

        $stmt = $this->execute(
            $sql,
            array(
                    ':task_id' => $task_id,
                    ':status_id' => $status_id
            )
        );
    }

    public function updatePriority($task_id, $priority_id)
    {

        $sql = 'UPDATE project_task SET priority_id = :priority_id WHERE id = :task_id';
        $stmt = $this->execute(
            $sql,
            array(
                    ':task_id' => $task_id,
                    ':priority_id' => $priority_id
            )
        );
    }

    public function removeTask($task_id)
    {

            $sql = '
                   UPDATE project_task SET removed = true WHERE id = :task_id';

        $stmt = $this->execute(
            $sql,
            array(
                ':task_id' => $task_id
            )
        );
    }
    public function restoreTask($task_id)
    {

            $sql = '
                   UPDATE project_task SET removed = false WHERE id = :task_id';

        $stmt = $this->execute(
            $sql,
            array(
                ':task_id' => $task_id
            )
        );
    }

    /**
     * タスク
     * @param  $task_id
     * @return array
     */
    public function fetchByTaskId($task_id)
    {
        //結果的にLEFT JOINが一番早かった・・・
        $sql =  "SELECT p.project_name , p.id as project_id,
            t.id as task_id, t.task_name, t.task_summary, t.status_id, t.schedule,
            t.create_date, t.update_date,
            s.status_name , t.create_user_id, t.category_id,c.category_name, t.priority_id,pr.priority_name,
            u.user_name as creater_user_name, u.show_name as creater_show_name,
            handle_user_id , uu.id as handle_id , u.removed as user_removed ,
            (case when uu.show_name is not null then uu.show_name ELSE '未設定' END) as handle_name,
            (case when s.status_id = 1 then true ELSE false END) as finished
            FROM
            project_task t
            LEFT JOIN project p ON t.project_id = p.id
            LEFT JOIN project_task_status s ON t.status_id = s.status_id
            LEFT JOIN project_task_category c ON t.category_id = c.category_id
            LEFT JOIN project_task_priority pr ON t.priority_id = pr.priority_id
            LEFT JOIN account u ON t.create_user_id = u.id
            LEFT JOIN account uu ON t.handle_user_id = uu.id
            WHERE t.id = :task_id AND p.removed = false AND t.removed = false";


        return $this->fetch($sql, array(
            ':task_id' => $task_id
        ));
    }

    /*
     * 削除タスクの取得
     * @param  $task_id
     * @return array
     */
    public function fetchRemovedByTaskId($task_id)
    {
        $sql =  "SELECT
            t.id as task_id,t.project_id, t.task_name, t.task_summary, t.status_id, t.schedule,
            t.create_date, t.update_date,t.removed as task_removed , t.category_id, t.priority_id,c.category_name,
            t.create_user_id
            FROM
            project_task t
            LEFT JOIN project_task_category c ON t.category_id = c.category_id
            WHERE t.id = :task_id AND t.removed = true";


        return $this->fetch($sql, array(
            ':task_id' => $task_id
        ));
    }


    /**
     * タスク用のステイタス
     * @return array
     */
    public function fetchAllTaskStatus()
    {
        $sql =  "SELECT s.status_id, s.status_name
            FROM project_task_status s
            ORDER BY s.status_id DESC";


        return $this->fetchAll($sql, array());
    }

    /**
     * タスク用のステイタスが存在するか確認
     * @return array
     */
    public function fetchByStatusId($status_id)
    {
        $sql =  "SELECT s.status_id, s.status_name
            FROM project_task_status s
            WHERE s.status_id = :status_id";


        return $this->fetch($sql, array(
            ':status_id' => $status_id
            ));
    }


    /**
     * タスク用のカテゴリ
     * @return array
     */
    public function fetchAllTaskCategory()
    {
        $sql =  "SELECT c.category_id, c.category_name
            FROM project_task_category c
            ORDER BY c.category_id ASC";


        return $this->fetchAll($sql, array());
    }

    /**
     * タスク用のカテゴリが存在するか確認
     * @return array
     */
    public function fetchByCategoryId($category_id)
    {
        $sql =  "SELECT c.category_id, c.category_name
            FROM project_task_category c
            WHERE c.category_id = :category_id";


        return $this->fetch($sql, array(
            ':category_id' => $category_id
            ));
    }

    /**
     * タスク用のカテゴリ
     * @return array
     */
    public function fetchAllTaskPriority()
    {
        $sql =  "SELECT p.priority_id, p.priority_name
            FROM project_task_priority p
            ORDER BY p.priority_id DESC";


        return $this->fetchAll($sql, array());
    }

    /**
     * タスク用のカテゴリが存在するか確認
     * @return array
     */
    public function fetchByPriorityId($priority_id)
    {
        $sql =  "SELECT p.priority_id, p.priority_name
            FROM project_task_priority p
            WHERE p.priority_id = :priority_id";


        return $this->fetch($sql, array(
            ':priority_id' => $priority_id
            ));
    }

/**
 * スレッドに入れる
 * @param  [type] $task_id     [description]
 * @param  [type] $thread_body [description]
 * @param  [type] $user_id     [description]
 * @return [type]              [description]
 */
    public function insertThread($task_id, $thread_body, $user_id, $system = false)
    {

            $sql = '
                   INSERT INTO project_task_thread (task_id,thread_body,create_user_id,system)
                   VALUES( :task_id , :thread_body, :user_id, :system)
                   ';

            $stmt = $this->execute(
                $sql,
                array(
                    ':task_id' => $task_id,
                    ':thread_body' => $thread_body,
                    ':user_id' => $user_id,
                    ':system' => $system
                )
            );
    }

    /**
     * スレッドの内容更新
     * @param  [type] $thread_id [description]
     * @return [type]            [description]
     */
    public function updateThreadByThreadId($thread_id,$thread_body)
    {

            $sql = '
                   UPDATE project_task_thread SET thread_body = :thread_body WHERE id = :thread_id
                   ';

            $stmt = $this->execute(
                $sql,
                array(
                    ':thread_id' => $thread_id,
                    ':thread_body' => $thread_body
                )
            );
    }
    /**
     * スレッドの削除
     * @param  [type] $thread_id [description]
     * @return [type]            [description]
     */
    public function removeThreadByThreadId($thread_id)
    {

            $sql = '
                   DELETE FROM project_task_thread WHERE id = :thread_id
                   ';

            $stmt = $this->execute(
                $sql,
                array(
                    ':thread_id' => $thread_id
                )
            );
    }

    /**
     * v
     * 該当タスクのスレッド一覧 ユーザーが作成したのはmycreateがtrue
     * @param  [type]  $task_id  [description]
     * @param  [type]  $user_id  [description]
     * @param  boolean $isSystem [description]
     * @return [type]            [description]
     */
    public function fetchAllTaskThreadByTaskId($task_id,$user_id,$isSystem=true)
    {


            $sql =  "SELECT t.id as thread_id,
                t.task_id, t.thread_body, t.system, t.create_date, t.update_date,
                u.user_name as creater_user_name, u.show_name as creater_show_name,
                (case when t.create_user_id = :user_id then true ELSE false END) as mycreate
                FROM project_task_thread t
                LEFT JOIN account u ON t.create_user_id = u.id
                WHERE t.task_id = :task_id
                ORDER BY  t.create_date DESC";
        if(!$isSystem){
            $sql =  "SELECT t.id as thread_id,
            t.task_id, t.thread_body, t.system, t.create_date, t.update_date,
            u.user_name as creater_user_name, u.show_name as creater_show_name,
            (case when t.create_user_id = :user_id then true ELSE false END) as mycreate
            FROM project_task_thread t
            LEFT JOIN account u ON t.create_user_id = u.id
            WHERE t.task_id = :task_id AND t.system = false
            ORDER BY  t.create_date DESC";
        }

        return $this->fetchAll($sql, array(
            ':task_id' => $task_id,
            ':user_id' => $user_id
        ));
    }

    /**
     * タスクにスレッドが存在しているか
     * @param  [type] $task_id   [description]
     * @param  [type] $thread_id [description]
     * @return [type]            [description]
     */
    public function fetchThreadByTaskAndThreadId($task_id,$thread_id)
    {

        $sql = "SELECT t.id as thread_id,t.thread_body,
            t.task_id, t.create_user_id
            FROM project_task_thread t
            WHERE t.id = :thread_id AND  t.task_id = :task_id AND t.system = false";


        return $this->fetch($sql, array(
            ':thread_id' => $thread_id,
            ':task_id' => $task_id
        ));
    }



    /**
     * 該当プロジェクトの担当ユーザーIDの一覧
     * @param  $project_id
     * @return array
     */
    public function fetchAllHandleTaskUserByProjectId($project_id)
    {
        //結果的にLEFT JOINが一番早かった・・・
        $sql =  "SELECT distinct t.handle_user_id
            FROM
            project_task t
            LEFT JOIN project p ON t.project_id = p.id
            WHERE t.project_id = :project_id AND p.removed = false AND t.removed = false";


        return $this->fetchAll($sql, array(
            ':project_id' => $project_id
        ));
    }



    /**
     *以下から改修したＳＱＬ
     *fetch系はこちらを
     *
     **************************************************************/

     /**
     * ユーザーの担当プロジェクト数
     * トップページやユーザーページ向け
     * @return [array] [count]
     */
    public function fetchCountHandleAllTaskByUserId($user_id)
    {
       /* $sql = 'SELECT COUNT(t.id) as count
                FROM
                project_task t,project p
                where t.handle_user_id = :user_id AND t.removed = false AND p.removed = false AND p.id = t.project_id';*/
            $sql = 'SELECT count(t.id) as count
                FROM project_task t,project p
             where t.project_id = p.id AND p.removed=false AND t.handle_user_id = :user_id AND t.removed = false';

        return $this->fetch($sql, array(
            ':user_id' => $user_id
            ));
    }

     /**
     * ユーザーが参加しているプロジェクト一覧
     * トップページやユーザーページ向け
     * @param  $user_id
     * @param  integer $offset     [description]
     * @param  integer $limit      [description]
     * @return array
     */
    public function fetchAllHandleAllTaskByUserId($user_id,$offset=0,$limit=25,$sort='schedule',$desc=true)
    {

            $sortType = array_search($sort,Env::TASK_PAGE_SORT_TYPE);
            if(!$sortType){
                $sql_sort = $desc ? ' ORDER BY schedule desc' : ' ORDER BY schedule asc ';
                $sortType = 'schedule';
            }else{
                $sql_sort = $desc ? ' ORDER BY '.$sortType. ' desc' : ' ORDER BY '.$sortType. ' asc ';
            }
        /*
        $sql = 'SELECT p.project_name , p.id as project_id,
            t.id as task_id, t.task_name, t.task_summary, t.status_id, t.schedule,
            t.create_date, t.update_date,
            s.status_name , t.create_user_id, t.category_id,c.category_name, t.priority_id,pr.priority_name,
            u.user_name as creater_user_name, u.show_name as creater_show_name, u.removed as user_removed,
            handle_user_id , uu.id as handle_id , uu.show_name as handle_name
            FROM
            (SELECT id , project_id , task_name , task_summary ,
                status_id , schedule , create_date , update_date ,
             create_user_id , category_id , priority_id ,handle_user_id
                FROM
                project_task
                where handle_user_id = :user_id AND removed = false LIMIT :offset , :offset_limit) as t
            LEFT JOIN project p ON t.project_id = p.id
            LEFT JOIN project_task_status s ON t.status_id = s.status_id
            LEFT JOIN project_task_category c ON t.category_id = c.category_id
            LEFT JOIN project_task_priority pr ON t.priority_id = pr.priority_id
            LEFT JOIN account u ON t.create_user_id = u.id
            LEFT JOIN account uu ON t.handle_user_id = uu.id
            WHERE p.removed = false';

            */
           /*************************************************************
            $sortType = array_search($sort,Env::TASK_PAGE_SORT_TYPE);
            if(!$sortType){
                $sql_sort = $desc ? ' ORDER BY schedule desc' : ' ORDER BY schedule asc';
            }else{
                $sql_sort = $desc ? ' ORDER BY '.$sortType. ' desc' : ' ORDER BY '.$sortType. ' asc';
            }
            $sql = 'SELECT p.project_name , p.id as project_id,
            t.id as task_id, t.task_name, t.task_summary, t.status_id, t.schedule,
            t.create_date, t.update_date,
            s.status_name , t.create_user_id, t.category_id,c.category_name, t.priority_id,pr.priority_name,
            u.user_name as creater_user_name, u.show_name as creater_show_name, u.removed as user_removed,
            handle_user_id , uu.id as handle_id , uu.show_name as handle_name
            FROM
            (SELECT id , project_id , task_name , task_summary ,
                status_id , schedule , create_date , update_date ,
             create_user_id , category_id , priority_id ,handle_user_id,removed
                FROM
                project_task ' . $sql_sort . ') as t
            LEFT JOIN project p ON t.project_id = p.id
            LEFT JOIN project_task_status s ON t.status_id = s.status_id
            LEFT JOIN project_task_category c ON t.category_id = c.category_id
            LEFT JOIN project_task_priority pr ON t.priority_id = pr.priority_id
            LEFT JOIN account u ON t.create_user_id = u.id
            LEFT JOIN account uu ON t.handle_user_id = uu.id
            WHERE handle_user_id = :user_id AND p.removed = false AND t.removed = false  ' . $sql_sort . ' LIMIT :offset , :offset_limit';
*/
            if($sort === 'handle'){
                $sql_sort = $desc ? ' desc ' : ' asc ';
                $sql = 'SELECT td.project_name , t.project_id,
                t.id as task_id, t.task_name, t.task_summary, t.status_id, t.schedule,
                t.create_date, t.update_date,
                s.status_name , t.create_user_id, t.category_id,c.category_name, t.priority_id,pr.priority_name,
                t.handle_user_id
                FROM (SELECT t.id ,t.project_name , uu.show_name
                FROM (SELECT t.id ,p.project_name,t.handle_user_id
                FROM project_task t,project p
                 where t.project_id = p.id AND p.removed=false AND t.handle_user_id = :user_id AND t.removed = false) as t
                LEFT JOIN account uu ON t.handle_user_id = uu.id
                order by uu.show_name ' . $sql_sort . ' LIMIT :offset , :offset_limit) as td
                LEFT JOIN project_task t ON t.id = td.id
                LEFT JOIN project_task_status s ON t.status_id = s.status_id
                LEFT JOIN project_task_category c ON t.category_id = c.category_id
                LEFT JOIN project_task_priority pr ON t.priority_id = pr.priority_id
                order by td.show_name ' . $sql_sort;

            }else if($sort === 'project'){

                $sql_sort = $desc ? ' desc ' : ' asc ';
                $sql = 'SELECT td.project_name , t.project_id,
                t.id as task_id, t.task_name, t.task_summary, t.status_id, t.schedule,
                t.create_date, t.update_date,
                s.status_name , t.create_user_id, t.category_id,c.category_name, t.priority_id,pr.priority_name,
                t.handle_user_id
                FROM(SELECT t.id,t.project_name
                FROM (SELECT t.id ,p.project_name
                FROM project_task t,project p
                 where t.project_id = p.id AND p.removed=false AND t.handle_user_id = :user_id AND t.removed = false) as t
                 order by t.project_name ' . $sql_sort . ' LIMIT :offset , :offset_limit) as td
                LEFT JOIN project_task t ON t.id = td.id
                LEFT JOIN project_task_status s ON t.status_id = s.status_id
                LEFT JOIN project_task_category c ON t.category_id = c.category_id
                LEFT JOIN project_task_priority pr ON t.priority_id = pr.priority_id
                order by td.project_name ' . $sql_sort ;
            }else{
                $sql = 'SELECT p.project_name , p.id as project_id,
                t.id as task_id, t.task_name, t.task_summary, t.status_id, t.schedule,
                t.create_date, t.update_date,
                s.status_name , t.create_user_id, t.category_id,c.category_name, t.priority_id,pr.priority_name,
                t.handle_user_id
                FROM(SELECT t.id
                FROM (SELECT t.id ,t.' .  $sortType . '
                FROM project_task t,project p
                 where t.project_id = p.id AND p.removed=false AND t.handle_user_id = :user_id AND t.removed = false) as t
                 ' . $sql_sort . ' LIMIT :offset , :offset_limit) as td
                LEFT JOIN project_task t ON t.id = td.id
                LEFT JOIN project p ON p.id = t.project_id
                LEFT JOIN project_task_status s ON t.status_id = s.status_id
                LEFT JOIN project_task_category c ON t.category_id = c.category_id
                LEFT JOIN project_task_priority pr ON t.priority_id = pr.priority_id ' . $sql_sort ;
            }

        $stmt = $this->con->prepare($sql);
        $stmt->bindValue(':user_id', $user_id);
        $stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
        $stmt->bindValue(':offset_limit', (int)$limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

     /**
     * プロジェクト詳細向け　全件タスク数
     * @return [array] [count]
     */
    public function fetchCountAllTaskByProjectId($project_id,$removed = false)
    {
        $sql = 'SELECT COUNT(id) as count
                FROM
                project_task
                where project_id = :project_id AND removed = :removed';

        return $this->fetch($sql, array(
            ':project_id' => $project_id,
            ':removed' => $removed
            ));
    }


    /**
     * プロジェクト詳細向け　全件タスク
     * @param  [type]  $project_id [description]
     * @param  integer $offset     [description]
     * @param  integer $limit      [description]
     * @return [type]              [description]
     */
    public function fetchAllTaskByProjectId($project_id,$offset=0,$limit=25,$sort='schedule',$desc=true,$removed = false)
    {

            $sortType = array_search($sort,Env::TASK_PAGE_SORT_TYPE);


            if($sort === 'handle'){
                $sql_sort = $desc ? ' desc ' : ' asc ';
                $sql = 'SELECT p.project_name , p.id as project_id,
                t.id as task_id, t.task_name, t.task_summary, t.status_id, t.schedule,
                t.create_date, t.update_date,
                s.status_name , t.create_user_id, t.category_id,c.category_name, t.priority_id,pr.priority_name,
                u.user_name as creater_user_name, u.show_name as creater_show_name, u.removed as user_removed,
                t.handle_user_id ,  td.handle_name
                FROM (SELECT t.id,u.show_name as handle_name
                    FROM
                      (SELECT t.id ,t.handle_user_id
                       FROM project_task t
                    where t.project_id = :project_id AND t.removed = :removed ) as t
                       LEFT JOIN account u ON t.handle_user_id = u.id order by u.show_name ' . $sql_sort . ' LIMIT :offset , :offset_limit) as td
                LEFT JOIN project_task t ON t.id = td.id
                LEFT JOIN project p ON p.id = t.project_id
                LEFT JOIN project_task_status s ON t.status_id = s.status_id
                LEFT JOIN project_task_category c ON t.category_id = c.category_id
                LEFT JOIN project_task_priority pr ON t.priority_id = pr.priority_id
                LEFT JOIN account u ON t.create_user_id = u.id order by p.project_name ' . $sql_sort;


            }else if($sort === 'project'){
                $sql_sort = $desc ? ' desc ' : ' asc ';
                $sql = 'SELECT td.project_name , t.project_id,
                td.id as task_id, t.task_name, t.task_summary, t.status_id, t.schedule,
                t.create_date, t.update_date,
                s.status_name , t.create_user_id, t.category_id,c.category_name, t.priority_id,pr.priority_name,
                u.user_name as creater_user_name, u.show_name as creater_show_name, u.removed as user_removed,
                handle_user_id , uu.id as handle_id , uu.show_name as handle_name
                FROM (SELECT t.id,t.project_name
                    FROM
                      (SELECT t.id ,p.project_name
                          FROM
                          project_task t,project p
                    where t.project_id = :project_id AND t.removed = :removed AND t.project_id = p.id)
                     as t order by p.project_name ' . $sql_sort . ' LIMIT :offset , :offset_limit) as td
                LEFT JOIN project_task t ON t.id = td.id
                LEFT JOIN project_task_status s ON t.status_id = s.status_id
                LEFT JOIN project_task_category c ON t.category_id = c.category_id
                LEFT JOIN project_task_priority pr ON t.priority_id = pr.priority_id
                LEFT JOIN account u ON t.create_user_id = u.id
                LEFT JOIN account uu ON t.handle_user_id = uu.id order by p.project_name ' . $sql_sort;

            }else{
                if(!$sortType){
                    $sql_sort = $desc ? ' ORDER BY schedule desc' : ' ORDER BY schedule asc ';
                    $sortType = 'schedule';
                }else{
                    $sql_sort = $desc ? ' ORDER BY '.$sortType. ' desc' : ' ORDER BY '.$sortType. ' asc ';
                }
                $sql = 'SELECT p.project_name , p.id as project_id,
                t.id as task_id, t.task_name, t.task_summary, t.status_id, t.schedule,
                t.create_date, t.update_date,
                s.status_name , t.create_user_id, t.category_id,c.category_name, t.priority_id,pr.priority_name,
                u.user_name as creater_user_name, u.show_name as creater_show_name, u.removed as user_removed,
                handle_user_id , uu.id as handle_id , uu.show_name as handle_name
                FROM (SELECT t.id
                    FROM (SELECT t.id ,t.' . $sortType . ' FROM project_task t
                    where t.project_id = :project_id AND t.removed = :removed )
                    as t ' . $sql_sort . ' LIMIT :offset , :offset_limit) as td
                LEFT JOIN project_task t ON t.id = td.id
                LEFT JOIN project p ON p.id = t.project_id
                LEFT JOIN project_task_status s ON t.status_id = s.status_id
                LEFT JOIN project_task_category c ON t.category_id = c.category_id
                LEFT JOIN project_task_priority pr ON t.priority_id = pr.priority_id
                LEFT JOIN account u ON t.create_user_id = u.id
                LEFT JOIN account uu ON t.handle_user_id = uu.id ' . $sql_sort;
            }
            /*
*/
                $stmt = $this->con->prepare($sql);
                $stmt->bindValue(':project_id', $project_id);
                $stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
                $stmt->bindValue(':offset_limit', (int)$limit, PDO::PARAM_INT);
                $stmt->bindValue(':removed', $removed);
                $stmt->execute();
                return $stmt->fetchAll(PDO::FETCH_ASSOC);



    }



}
