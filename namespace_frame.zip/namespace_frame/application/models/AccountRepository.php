<?php

namespace Models;

use Framework\Core\DbRepository;
use Apps\Env;
use PDO;

class AccountRepository extends DbRepository
{
    public function insert($user_name, $password, $show_name, $authority_level)
    {
        //$solt = 'SecretKey';
        $password = $this->hashPassword($password);

        $sql = '
               INSERT INTO account (user_name , password ,show_name, authority_level)
               VALUES(:user_name, :password , :show_name, :authority_level)
               ';

        $stmt = $this->execute(
            $sql,
            array(
            ':user_name' => $user_name,
            ':password' => $password,
            ':show_name' => $show_name,
            ':authority_level' => $authority_level,
            )
        );
    }

    public function updateProfile($user_name, $show_name, $password, $password_change = false)
    {
        if ($password_change) {
            //$solt = 'SecretKey';
            $password = $this->hashPassword($password);
            $sql = '
                   UPDATE account SET show_name = :show_name,
                   password = :password WHERE user_name = :user_name';

            $stmt = $this->execute(
                $sql,
                array(
                ':user_name' => $user_name,
                ':show_name' => $show_name,
                ':password' => $password,
                )
            );
        } else {
            $sql = '
                   UPDATE account SET show_name = :show_name WHERE user_name = :user_name';
            $stmt = $this->execute(
                $sql,
                array(
                ':user_name' => $user_name,
                ':show_name' => $show_name,
                )
            );
        }
    }

    public function updateAuthority($user_name, $authority_level)
    {
        $sql = '
                   UPDATE account SET authority_level = :authority_level WHERE user_name = :user_name';

        $stmt = $this->execute(
            $sql,
            array(
            ':user_name' => $user_name,
            ':authority_level' => $authority_level,
            )
        );
    }

    public function removeByUser($user_name)
    {
        /*
        $sql = '
           DELETE FROM account WHERE user_name = :user_name
           ';
        */
        $sql = '
                   UPDATE account SET removed = true WHERE user_name = :user_name';
        $stmt = $this->execute(
            $sql,
            array(
            ':user_name' => $user_name,
            )
        );
    }

    public function restorationByUser($user_name)
    {
        /*
        $sql = '
           DELETE FROM account WHERE user_name = :user_name
           ';
        */
        $sql = '
                   UPDATE account SET removed = false WHERE user_name = :user_name';
        $stmt = $this->execute(
            $sql,
            array(
            ':user_name' => $user_name,
            )
        );
    }

//, $solt = 'SecretKey')
    public function hashPassword($password)
    {
        return password_hash(hash('sha512', $password, true), PASSWORD_DEFAULT);
          //  return sha1($password.$solt);
    }
    public function createUserSeesionData($user)
    {
        if(!$user){
            return false;
        }
        $sessionUser = array();
        $sessionUser['user_id'] = $user['user_id'];
        $sessionUser['user_name'] = $user['user_name'];
        $sessionUser['show_name'] = $user['show_name'];
        $sessionUser['user_removed'] = $user['user_removed'];
        $sessionUser['admin'] = $user['admin'];
        $sessionUser['develop'] = $user['develop'];
        $sessionUser['manage'] = $user['manage'];
        $sessionUser['authority_level'] = $user['authority_level'];
        $sessionUser['authority_name'] = $user['authority_name'];

        return $sessionUser;
      //  return sha1($password.$solt);
    }

    /**
     * アカウント情報の取得.退会ユーザーは含まない.
     *
     * @param
     *            $user_name
     */
    public function fetchByUserName($user_name, $removed = false)
    {
        // $sql = "SELECT * FROM account WHERE user_name = :user_name";
        $sql = 'SELECT u.id as user_id, u.password, u.user_name, u.show_name , u.removed as user_removed ,
                        (case  when a.authority_level = 1  THEN true ELSE false END) as admin,
                        (case  when a.authority_level <= 2  THEN true ELSE false END) as develop,
                        (case  when a.authority_level <= 4  THEN true ELSE false END) as manage,
                        a.authority_level , a.authority_name
                        FROM account u  INNER JOIN account_authority a
                        ON a.authority_level = u.authority_level WHERE u.user_name = :user_name AND  u.removed = :removed';

        return $this->fetch($sql, array(
            ':user_name' => $user_name,
            ':removed' => $removed,
        ));
    }

    /**
     * アカウント情報の取得.退会ユーザーは含まない.
     *
     * @param
     *            $user_name
     */
    public function fetchByUserId($user_id)
    {
        // $sql = "SELECT * FROM account WHERE user_name = :user_name";
        $sql = 'SELECT u.id as user_id, u.user_name, u.show_name , u.removed as user_removed ,
                        (case  when a.authority_level = 1  THEN true ELSE false END) as admin,
                        (case  when a.authority_level <= 2  THEN true ELSE false END) as develop,
                        (case  when a.authority_level <= 4  THEN true ELSE false END) as manage,
                        a.authority_level , a.authority_name
                        FROM account u  INNER JOIN account_authority a
                        ON a.authority_level = u.authority_level WHERE u.id = :user_id AND  u.removed = false';

        return $this->fetch($sql, array(
            ':user_id' => $user_id,
        ));
    }
    /**
     * すでに登録されていればfalse.
     *
     * @param
     *            $user_name
     */
    public function isUniqueUserName($user_name)
    {
        $sql = 'SELECT COUNT(id) as count FROM account WHERE user_name = :user_name';
        $row = $this->fetch($sql, array(
            ':user_name' => $user_name,
        ));

        // SQLの実行結果は文字列型なので文字列で比較
        if ($row['count'] === '0') {
            return true;
        }

        return false;
    }

    /**
     * 登録ユーザー 退会ユーザーは含まない.
     *
     * @return [type] [description]
     */
    public function fetchAllByUser()
    {
        // $sql = "SELECT * FROM account WHERE user_name = :user_name";
        $sql = 'SELECT u.id as user_id, u.user_name, u.show_name , u.removed as user_removed ,
                        (case  when a.authority_level = 1  THEN true ELSE false END) as admin,
                        (case  when a.authority_level <= 2  THEN true ELSE false END) as develop,
                        (case  when a.authority_level <= 4  THEN true ELSE false END) as manage,
                        a.authority_level , a.authority_name
                    FROM account u
                    INNER JOIN account_authority a
                    ON a.authority_level = u.authority_level
                    WHERE u.removed = false
                    ORDER BY u.user_name ASC';

        return $this->fetchAll($sql, array());
    }

    /**
     * 登録ユーザー＋担当しているタスク数(handle_count) 退会ユーザーも含む
     *
     * @return [type] [description]
     */
    public function fetchAllWithHandleTaskByUser()
    {
        // $sql = "SELECT * FROM account WHERE user_name = :user_name";
        $sql = 'SELECT u.id as user_id, u.user_name, u.show_name , u.removed as user_removed,
                        (case  when a.authority_level = 1  THEN true ELSE false END) as admin,
                        (case  when a.authority_level <= 2  THEN true ELSE false END) as develop,
                        (case  when a.authority_level <= 4  THEN true ELSE false END) as manage,
                        ttb.work_count as work_handle_count,
                        ttb.all_count as all_handle_count,
                        a.authority_level , a.authority_name
                    FROM account u
                    INNER JOIN account_authority a
                    ON a.authority_level = u.authority_level
                    LEFT JOIN (SELECT  t.handle_user_id ,count(*) as all_count,
count(case when t.status_id <> 1 then t.id else NULL end) as work_count
                                FROM
                                project_task t
                                LEFT JOIN project p ON t.project_id = p.id
                                WHERE p.removed = false AND t.removed = false
                                GROUP BY t.handle_user_id) as ttb on ttb.handle_user_id = u.id
                    ORDER BY u.user_name ASC';

        return $this->fetchAll($sql, array());
    }
    /**
     * 権限リスト　管理者権限はadminをtrue.
     *
     * @return [type] [description]
     */
    public function fetchAllByAuthority($admin = false)
    {
        $sql = !$admin ? 'SELECT * FROM account_authority WHERE authority_level > 1 ORDER BY authority_level DESC'
                        : 'SELECT * FROM account_authority ORDER BY authority_level DESC';

        return $this->fetchAll($sql, array());
    }
}
